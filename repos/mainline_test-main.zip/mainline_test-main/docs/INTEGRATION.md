# Service Integration Guide

How Evoke, Bolt Gateway, and Manifast work together.

## Overview

The stack implements a layered architecture where each service has a specific role:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              BROWSER / CLIENT                                │
└─────────────────────────────────────┬───────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  EVOKE (Port 3000)                                                          │
│  ─────────────────                                                          │
│  Role: API Client                                                           │
│  • Handles CORS for browser requests                                        │
│  • Serves JavaScript client library                                         │
│  • Proxies API requests to Bolt Gateway                                     │
│  • Adds X-Client-ID header                                                  │
└─────────────────────────────────────┬───────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  BOLT GATEWAY (Port 8088)                                                   │
│  ────────────────────────                                                   │
│  Role: API Gateway                                                          │
│  • Routes requests to backend services                                      │
│  • Adds X-Forwarded-By: bolt-gateway header                                 │
│  • Provides /health endpoint                                                │
│  • Can validate X-Client-ID from known clients                              │
└─────────────────────────────────────┬───────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  MANIFAST (Internal Only)                                                   │
│  ────────────────────────                                                   │
│  Role: Backend API                                                          │
│  • Validates X-Forwarded-By header                                          │
│  • Rejects direct access (403 Forbidden)                                    │
│  • Processes API requests                                                   │
│  • Health endpoints exempt from gateway validation                          │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Request Flow

### Step-by-Step

```
1. Browser makes request to Evoke
   GET http://evoke:3000/api/users

2. Evoke adds client identification and proxies to Bolt
   GET http://bolt-gateway:8088/api/users
   Headers:
     X-Client-ID: evoke

3. Bolt adds gateway identification and proxies to Manifast
   GET http://manifast:8000/api/users
   Headers:
     X-Client-ID: evoke
     X-Forwarded-By: bolt-gateway

4. Manifast validates headers and processes request
   ✓ X-Forwarded-By = "bolt-gateway" → Request allowed
   ✗ X-Forwarded-By missing → 403 Forbidden

5. Response flows back through the chain
   Manifast → Bolt → Evoke → Browser
```

### Sequence Diagram

```
Browser          Evoke           Bolt Gateway       Manifast
   │               │                  │                │
   │──GET /api/───▶│                  │                │
   │               │──GET /api/──────▶│                │
   │               │  X-Client-ID     │                │
   │               │                  │──GET /api/────▶│
   │               │                  │  X-Client-ID   │
   │               │                  │  X-Forwarded-By│
   │               │                  │                │
   │               │                  │◀───200 OK──────│
   │               │◀───200 OK────────│                │
   │◀───200 OK─────│                  │                │
   │               │                  │                │
```

## Service Responsibilities

### Evoke

| Responsibility | Implementation |
|----------------|----------------|
| CORS handling | `Access-Control-Allow-*` headers on all responses |
| Client library | Serves `/dist/evoke.js` for browser usage |
| Health endpoint | `GET /health` returns service status |
| Client identification | Adds `X-Client-ID: evoke` to requests |
| Request proxying | Forwards `/api/*` to Bolt Gateway |

### Bolt Gateway

| Responsibility | Implementation |
|----------------|----------------|
| Request routing | Built-in routes for `/api/*`, `/health` |
| Gateway identification | Adds `X-Forwarded-By: bolt-gateway` to all proxied requests |
| Health endpoint | `GET /health` returns gateway status |
| Client validation | Optionally validates `X-Client-ID` header |
| Backend abstraction | Clients only know about gateway, not backend |

### Manifast

| Responsibility | Implementation |
|----------------|----------------|
| Gateway validation | Requires `X-Forwarded-By: bolt-gateway` header |
| Direct access prevention | Returns 403 for requests without gateway header |
| Health endpoints | `/health/live` and `/health/ready` exempt from validation |
| Business logic | Processes API requests |

## Security Model

### Defense in Depth

```
Layer 1: Network Isolation
├── Manifast has no public port
├── Only Bolt can reach Manifast
└── Docker network provides isolation

Layer 2: Header Validation
├── Manifast checks X-Forwarded-By header
├── Rejects requests without valid gateway header
└── Optional: Validates shared secret

Layer 3: Client Identification
├── Evoke adds X-Client-ID header
├── Bolt can validate known clients
└── Enables per-client rate limiting/logging
```

### Why Each Layer Matters

| Attack Vector | Protection |
|---------------|------------|
| Direct access to Manifast | Network isolation (no public port) |
| Bypass gateway from internal network | Header validation |
| Unknown/malicious clients | Client ID validation |
| Header spoofing | Network isolation + optional shared secret |

## Health Check Strategy

Each service provides health endpoints for different purposes:

```
Service         Endpoint            Purpose
───────         ────────            ───────
Evoke           /health             Container orchestration
Bolt Gateway    /health             Container orchestration
Manifast        /health/live        Liveness probe (is process running?)
Manifast        /health/ready       Readiness probe (can accept traffic?)
```

### Health Check Flow for Integration Testing

```
Test Harness checks:

1. Evoke health (direct)
   GET /evoke/health
   └── Verifies Evoke is running

2. Bolt health (through Evoke)
   GET /evoke/api/health/live
   └── Request reaches Bolt if Evoke works
   └── Verifies Evoke → Bolt path

3. Manifast health (through full flow)
   GET /evoke/api/health/ready
   └── Request reaches Manifast if Bolt works
   └── Verifies Evoke → Bolt → Manifast path
```

## Configuration

### Environment Variables

**Evoke:**
```env
# Gateway connection settings
BOLT_GATEWAY_HOST=bolt-gateway
BOLT_GATEWAY_PORT=80
API_PATH_PREFIX=/api
```

**Bolt Gateway:**
```env
# Backend routing
BACKEND_1_HOST=manifast
BACKEND_1_PORT=8000
# Let Manifast handle CORS
CORS_PASSTHROUGH=true
# Optional shared secret for extra security
BOLT_GATEWAY_SECRET=<shared-secret>
```

**Manifast:**
```env
# Gateway validation (enforced)
BOLT_GATEWAY_ENABLED=true
BOLT_GATEWAY_HEADER=X-Forwarded-By
BOLT_GATEWAY_VALUE=bolt-gateway
# Optional shared secret (must match Bolt)
BOLT_GATEWAY_SECRET=<shared-secret>
```

### Docker Network

All services connect to the same Docker network:

```yaml
networks:
  integration-network:
    driver: bridge
    name: mainline-integration
```

## Common Patterns

### Adding a New API Endpoint

1. Implement in Manifast (`/api/new-endpoint`)
2. No changes needed in Bolt (auto-routed via `/api/*`)
3. No changes needed in Evoke (auto-proxied)
4. Test through the flow

### Adding a New Service

1. Add service to `docker-compose.yml`
2. Connect to `integration-network`
3. Add routing in Bolt Gateway if needed
4. Validate gateway header in new service

### Debugging Request Flow

```bash
# Check if Evoke can reach Bolt
docker compose exec evoke curl http://bolt-gateway:80/health

# Check if Bolt can reach Manifast
docker compose exec bolt-gateway curl http://manifast:8000/health/live

# Check headers being passed
docker compose logs manifast | grep "X-Forwarded-By"
```

## Troubleshooting

| Symptom | Likely Cause | Solution |
|---------|--------------|----------|
| CORS errors in browser | Evoke not adding headers | Check Evoke nginx config |
| 403 from Manifast | Missing gateway header | Check Bolt is adding X-Forwarded-By |
| 502 Bad Gateway | Backend unreachable | Check Manifast is healthy |
| Connection refused | Service not running | Check `docker compose ps` |

## Quick Start

### Prerequisites

- Docker and Docker Compose installed
- Access to the container registry (ghcr.io/tj-hand)

### Setup Steps

```bash
# 1. Clone the repository
git clone https://github.com/tj-hand/mainline_test.git
cd mainline_test

# 2. Create environment file from template
cp .env.example .env

# 3. (Optional) Edit .env to customize ports or settings
# Default ports: Evoke=3000, Bolt=8088, Test Harness=3001

# 4. Start all services
docker compose up -d

# 5. Verify all services are healthy
docker compose ps

# 6. Open Test Harness to verify integration
# http://localhost:3001
```

### Verify Integration

Use the Test Harness UI or run these commands:

```bash
# Check individual service health
curl http://localhost:3000/health          # Evoke
curl http://localhost:8088/health          # Bolt Gateway

# Test full request flow (Evoke → Bolt → Manifast)
curl http://localhost:3000/api/health/live
curl http://localhost:3000/api/health/ready

# Expected: 200 OK responses with JSON health status
```

### Container Image Versions

Set these in your `.env` file to pin specific versions:

```env
MANIFAST_VERSION=latest    # or specific tag like v1.0.0
BOLT_VERSION=latest
EVOKE_VERSION=nginx        # nginx-based image
```
