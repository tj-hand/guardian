# Architecture Alignment Plan

## Overview

The Mainline Integration Test Harness is designed to test the flow:

```
[Test Harness] → [Evoke Client] → [Bolt Gateway :8088] → [Manifast API :8000]
```

**Current Problem:** The Test Harness bypasses Evoke and goes directly to Bolt for most requests. Additionally, each service is missing critical functionality that should be its responsibility.

**Goal:** Each component should:
1. Handle its own concerns (CORS, health checks, validation)
2. Only accept requests from its adjacent upstream component
3. Be self-contained (no configuration hacks in other repos)

---

## Gap Analysis by Component

### 1. EVOKE (API Client Library)

**Current State:**
- Serves as a static frontend container
- No CORS headers configured
- No health check endpoint that returns JSON
- No client identification header

**Required Changes:**

| # | Requirement | Priority | Description |
|---|-------------|----------|-------------|
| E1 | Add CORS headers | HIGH | Evoke's nginx must add `Access-Control-Allow-Origin`, `Access-Control-Allow-Methods`, `Access-Control-Allow-Headers` to all responses |
| E2 | Add `/health` endpoint | HIGH | Return JSON: `{"status":"healthy","service":"evoke","version":"x.x.x"}` |
| E3 | Add `/api/health` proxy | MEDIUM | Proxy health checks to Bolt so Test Harness can check full flow via Evoke |
| E4 | Add `X-Client-ID` header | MEDIUM | All requests from Evoke to Bolt should include `X-Client-ID: evoke` header |
| E5 | Export JS client library | HIGH | Serve `/dist/evoke.js` or `/evoke-client.js` that can be imported by Test Harness |

**Team Action Required:**
```
Repository: tj-hand/evoke
Issue Title: [INFRA] Add CORS, health endpoint, and client identification
Labels: infrastructure, integration
```

---

### 2. BOLT GATEWAY (API Gateway)

**Current State:**
- Routes are defined in `mainline_test/config/nginx/manifast-routes.conf` (WRONG!)
- No origin validation (accepts requests from anyone)
- Health endpoint defined externally
- CORS passthrough enabled but not properly configured

**Required Changes:**

| # | Requirement | Priority | Description |
|---|-------------|----------|-------------|
| B1 | Move routes to Bolt repo | HIGH | `manifast-routes.conf` should live in Bolt Gateway repo, not mainline_test |
| B2 | Built-in `/health` endpoint | HIGH | Gateway should have its own health endpoint returning `{"status":"healthy","service":"bolt-gateway"}` |
| B3 | Validate `X-Client-ID` header | MEDIUM | Optionally validate that requests come from known clients (Evoke) |
| B4 | Add `X-Forwarded-By` header | HIGH | All proxied requests to Manifast must include `X-Forwarded-By: bolt-gateway` |
| B5 | CORS configuration | MEDIUM | Either handle CORS at gateway level OR ensure passthrough works correctly |

**Team Action Required:**
```
Repository: tj-hand/bolt-gateway
Issue Title: [INFRA] Internalize routes and add origin validation
Labels: infrastructure, security, integration
```

---

### 3. MANIFAST API (Backend)

**Current State:**
- Directly exposed on port 8000 (can be accessed bypassing Bolt)
- Has gateway validation but it's optional
- CORS headers configured but may conflict with gateway

**Required Changes:**

| # | Requirement | Priority | Description |
|---|-------------|----------|-------------|
| M1 | Internal-only exposure | HIGH | In production, Manifast should NOT be exposed publicly. Only Bolt should reach it. |
| M2 | Strict gateway validation | HIGH | Reject ALL requests that don't have valid `X-Forwarded-By: bolt-gateway` header |
| M3 | Validate gateway secret | MEDIUM | Verify `BOLT_GATEWAY_SECRET` in headers for additional security |
| M4 | Remove public CORS | LOW | If Bolt handles CORS, Manifast doesn't need to (avoid conflicts) |

**Team Action Required:**
```
Repository: tj-hand/manifast
Issue Title: [SECURITY] Enforce gateway-only access
Labels: security, infrastructure, integration
```

---

### 4. MAINLINE TEST HARNESS (This Repo)

**Current State:**
- Bypasses Evoke for most requests
- Contains Bolt Gateway routes (shouldn't be here)
- Has CORS hacks to make Evoke work
- Directly tests Bolt and Manifast

**Required Changes:**

| # | Requirement | Priority | Description |
|---|-------------|----------|-------------|
| T1 | Remove `manifast-routes.conf` | HIGH | Once Bolt internalizes routes, remove from this repo |
| T2 | All requests via Evoke | HIGH | Test Harness should ONLY use Evoke client for API requests |
| T3 | Remove CORS hacks | MEDIUM | Once Evoke handles CORS, remove proxy hacks from nginx.conf |
| T4 | Status checks via Evoke | MEDIUM | Check Manifast and Bolt status through Evoke, not directly |
| T5 | Simplify docker-compose | LOW | Remove direct port exposure for Manifast (8000) in test environment |

---

## Implementation Order

### Phase 1: Service Self-Containment (Parallel Work)

```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│     EVOKE       │  │      BOLT       │  │    MANIFAST     │
│                 │  │                 │  │                 │
│ E1: Add CORS    │  │ B1: Move routes │  │ M2: Strict      │
│ E2: Add /health │  │ B2: Add /health │  │     validation  │
│ E5: Export JS   │  │ B4: Add header  │  │                 │
└─────────────────┘  └─────────────────┘  └─────────────────┘
        │                    │                    │
        └────────────────────┴────────────────────┘
                             │
                             ▼
                    All teams complete
```

### Phase 2: Security Hardening

```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│     EVOKE       │  │      BOLT       │  │    MANIFAST     │
│                 │  │                 │  │                 │
│ E4: Add client  │  │ B3: Validate    │  │ M1: Internal    │
│     ID header   │  │     client ID   │  │     only        │
└─────────────────┘  └─────────────────┘  └─────────────────┘
```

### Phase 3: Test Harness Simplification

```
┌─────────────────────────────────────────────────────────────┐
│                    MAINLINE TEST                             │
│                                                              │
│ T1: Remove manifast-routes.conf                             │
│ T2: Refactor to use only Evoke client                       │
│ T3: Remove CORS hacks                                        │
│ T4: Update status checks                                     │
└─────────────────────────────────────────────────────────────┘
```

---

## Request Flow After Implementation

### Health Check Flow
```
Browser                    Test Harness              Evoke                 Bolt                  Manifast
   │                            │                      │                     │                       │
   │──GET /evoke/health────────▶│                      │                     │                       │
   │                            │──proxy──────────────▶│                     │                       │
   │                            │◀─────────────────────│ 200 OK              │                       │
   │◀───────────────────────────│                      │                     │                       │
   │                            │                      │                     │                       │
   │──evokeClient.health()─────▶│                      │                     │                       │
   │                            │──/evoke/api/health──▶│                     │                       │
   │                            │                      │──X-Client-ID:evoke─▶│                       │
   │                            │                      │                     │──X-Forwarded-By:bolt─▶│
   │                            │                      │                     │◀──────────────────────│
   │                            │                      │◀────────────────────│                       │
   │                            │◀─────────────────────│                     │                       │
   │◀───────────────────────────│                      │                     │                       │
```

### API Request Flow
```
Browser                    Test Harness              Evoke                 Bolt                  Manifast
   │                            │                      │                     │                       │
   │──evokeClient.get('/api/')─▶│                      │                     │                       │
   │                            │──/evoke/api/────────▶│                     │                       │
   │                            │                      │──GET /api/─────────▶│                       │
   │                            │                      │  X-Client-ID:evoke  │                       │
   │                            │                      │                     │──GET /api/───────────▶│
   │                            │                      │                     │  X-Forwarded-By:bolt  │
   │                            │                      │                     │◀──200 OK──────────────│
   │                            │                      │◀──200 OK────────────│                       │
   │                            │◀──200 OK─────────────│                     │                       │
   │◀──200 OK───────────────────│                      │                     │                       │
```

---

## Issue Templates for Each Team

### EVOKE Team Issue

```markdown
## Summary
Add CORS headers, health endpoint, and client identification to Evoke.

## Background
The Mainline Integration Test Harness requires all API requests to flow through
Evoke → Bolt → Manifast. Currently, Evoke is missing critical functionality.

## Requirements
- [ ] Add CORS headers to nginx configuration
  - `Access-Control-Allow-Origin: *` (or configurable origins)
  - `Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS`
  - `Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With`
- [ ] Add `/health` endpoint returning JSON: `{"status":"healthy","service":"evoke"}`
- [ ] Add `X-Client-ID: evoke` header to all outgoing requests to Bolt
- [ ] Ensure `/dist/evoke.js` is served for client-side usage

## Acceptance Criteria
- Browser can fetch from Evoke without CORS errors
- `/health` returns 200 with JSON body
- Test Harness can import and use Evoke client library
```

### BOLT Team Issue

```markdown
## Summary
Internalize route configuration and add built-in health endpoint.

## Background
Currently, Bolt Gateway routes are defined in the mainline_test repo. This should
be moved to the Bolt Gateway repo for proper separation of concerns.

## Requirements
- [ ] Move `manifast-routes.conf` content into Bolt Gateway image
- [ ] Add built-in `/health` endpoint (not from external config)
- [ ] Ensure `X-Forwarded-By: bolt-gateway` header is added to all proxied requests
- [ ] (Optional) Validate `X-Client-ID` header from known clients

## Acceptance Criteria
- Bolt Gateway works without external route configuration
- `/health` endpoint returns `{"status":"healthy","service":"bolt-gateway"}`
- All requests to Manifast include `X-Forwarded-By` header
```

### MANIFAST Team Issue

```markdown
## Summary
Enforce gateway-only access for security.

## Background
Manifast API is currently directly accessible, bypassing the gateway. In production,
all requests should come through Bolt Gateway.

## Requirements
- [ ] Validate `X-Forwarded-By: bolt-gateway` header on all requests
- [ ] Return 403 Forbidden if header is missing or invalid
- [ ] (Optional) Validate `BOLT_GATEWAY_SECRET` for additional security
- [ ] Document that direct access is blocked

## Acceptance Criteria
- `curl http://manifast:8000/health/live` returns 403 (no gateway header)
- `curl -H "X-Forwarded-By: bolt-gateway" http://manifast:8000/health/live` returns 200
- Integration tests pass through full flow
```

---

## Docker Compose Changes (After Phase 1-2)

```yaml
services:
  manifast:
    # REMOVE public port exposure in production
    # ports:
    #   - "8000:8000"  # Only for debugging
    expose:
      - "8000"  # Internal only, accessible by Bolt

  bolt-gateway:
    # No external route config needed
    # volumes:
    #   - ./config/nginx/manifast-routes.conf:/etc/nginx/...  # REMOVE

  evoke:
    # No changes needed if CORS is handled internally

  test-harness:
    # Simplified - just serves frontend, all requests via Evoke
    volumes:
      - ./config/test-harness/index.html:/usr/share/nginx/html/index.html:ro
      # Remove nginx.conf with CORS hacks once Evoke handles it
```

---

## Status Tracking

| Component | Issue Created | Phase 1 | Phase 2 | Phase 3 |
|-----------|--------------|---------|---------|---------|
| Evoke     | [ ]          | [ ]     | [ ]     | N/A     |
| Bolt      | [ ]          | [ ]     | [ ]     | N/A     |
| Manifast  | [ ]          | [ ]     | [ ]     | N/A     |
| Test Harness | N/A       | N/A     | N/A     | [ ]     |

---

## Questions to Resolve

1. **CORS Strategy**: Should CORS be handled at Evoke level, Bolt level, or Manifast level?
   - Recommendation: Evoke (closest to browser)

2. **Authentication**: How should services authenticate each other?
   - Current: Shared secret + header validation
   - Alternative: mTLS, JWT tokens

3. **Direct Access for Debugging**: Should we allow direct access to Manifast/Bolt in development?
   - Recommendation: Yes, but with clear documentation that it's dev-only

4. **Evoke Client Library**: Is Evoke meant to be a JS library or a full frontend?
   - Clarification needed from Evoke team
