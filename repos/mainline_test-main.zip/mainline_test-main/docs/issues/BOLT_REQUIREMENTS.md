# Bolt Gateway - API Gateway Requirements

## Overview

Bolt Gateway is an nginx-based API gateway that routes requests to backend services (Manifast). As the entry point for all API traffic, it must implement standard gateway patterns.

---

## Required Features

### 1. Self-Contained Route Configuration (HIGH PRIORITY)

**Why:** An API gateway should define its own routing rules. External configuration creates:
- Deployment complexity
- Version mismatch risks
- Unclear ownership of route definitions

**Current Problem:** Routes are defined externally and mounted via volume.

**Solution:** Include route configuration in the Bolt Gateway image itself.

**Routes to include:**

```nginx
# Health endpoint (gateway's own health)
location = /health {
    add_header 'Content-Type' 'application/json' always;
    add_header 'Access-Control-Allow-Origin' '*' always;
    return 200 '{"status":"healthy","service":"bolt-gateway"}';
}

# API routes - proxy to backend
location /api/ {
    proxy_pass http://backend:8000/api/;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-By bolt-gateway;
}

# Health check passthrough
location /api/health/ {
    proxy_pass http://backend:8000/health/;
    proxy_set_header X-Forwarded-By bolt-gateway;
}
```

---

### 2. Gateway Identification Header (HIGH PRIORITY)

**Why:** Backend services need to verify that requests came through the authorized gateway. This enables:
- Security: Reject direct access attempts
- Auditing: Track request sources
- Debugging: Trace request flow

**Implementation:**

Add to ALL proxied requests:

```nginx
proxy_set_header X-Forwarded-By bolt-gateway;
```

**Backend can then validate:**
```python
if request.headers.get('X-Forwarded-By') != 'bolt-gateway':
    return 403, "Direct access not allowed"
```

---

### 3. Health Endpoint (HIGH PRIORITY)

**Why:** Container orchestration and monitoring systems need to check gateway health independently of backend services.

**Implementation:**

```nginx
location = /health {
    add_header 'Content-Type' 'application/json' always;
    add_header 'Access-Control-Allow-Origin' '*' always;
    return 200 '{"status":"healthy","service":"bolt-gateway","timestamp":"$time_iso8601"}';
}
```

**Expected Response:**
```json
{
  "status": "healthy",
  "service": "bolt-gateway"
}
```

---

### 4. Client Validation (MEDIUM PRIORITY)

**Why:** Gateways should optionally validate that requests come from known clients. This provides:
- Defense in depth
- Rate limiting per client
- Client-specific routing

**Implementation:**

```nginx
# Map known clients
map $http_x_client_id $known_client {
    default     0;
    "evoke"     1;
    "mobile"    1;
    "internal"  1;
}

# Log unknown clients (or reject them)
location /api/ {
    if ($known_client = 0) {
        # Option 1: Log warning
        access_log /var/log/nginx/unknown_clients.log;
        # Option 2: Reject (uncomment to enable)
        # return 403 '{"error":"Unknown client"}';
    }

    proxy_pass http://backend:8000/api/;
    proxy_set_header X-Client-ID $http_x_client_id;
    proxy_set_header X-Forwarded-By bolt-gateway;
}
```

---

### 5. CORS Handling (MEDIUM PRIORITY)

**Why:** The gateway can either handle CORS or pass through backend CORS headers. Choose one strategy consistently.

**Option A: Gateway handles CORS**
```nginx
add_header 'Access-Control-Allow-Origin' '*' always;
add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS' always;
add_header 'Access-Control-Allow-Headers' 'Content-Type, Authorization' always;
```

**Option B: Backend handles CORS (passthrough)**
```nginx
# Don't add CORS headers at gateway level
# Set environment variable for clarity
# CORS_PASSTHROUGH=true
```

---

## Acceptance Criteria

- [ ] Gateway starts without external route configuration files
- [ ] `curl http://gateway/health` returns gateway health JSON
- [ ] All proxied requests include `X-Forwarded-By: bolt-gateway` header
- [ ] Routes (`/api/*`, `/health`) work with default image configuration

---

## Docker Configuration

```yaml
services:
  bolt-gateway:
    image: bolt-gateway:latest
    ports:
      - "8088:80"
    environment:
      - BACKEND_1_HOST=manifast
      - BACKEND_1_PORT=8000
      - CORS_PASSTHROUGH=true  # Let backend handle CORS
    # NO volume mounts needed for routes
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BACKEND_1_HOST` | `localhost` | Backend 1 service hostname |
| `BACKEND_1_PORT` | `8000` | Backend 1 service port |
| `CORS_PASSTHROUGH` | `false` | If true, don't add CORS headers |
| `LOG_LEVEL` | `warn` | Nginx log level |
