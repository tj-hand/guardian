# Manifast API - Backend Security Requirements

## Overview

Manifast is a FastAPI backend service that should only be accessed through Bolt Gateway. Direct access bypasses security controls, rate limiting, and auditing implemented at the gateway level.

---

## Required Features

### 1. Gateway-Only Access Enforcement (HIGH PRIORITY)

**Why:**
- Security: Gateway provides authentication, rate limiting, and request validation
- Consistency: All requests should follow the same path
- Auditing: Gateway logs all API access
- Defense in depth: Multiple layers of security

**Implementation:**

```python
# middleware/gateway_validation.py
from fastapi import Request, HTTPException
from functools import wraps
import os

GATEWAY_HEADER = os.getenv("BOLT_GATEWAY_HEADER", "X-Forwarded-By")
GATEWAY_VALUE = os.getenv("BOLT_GATEWAY_VALUE", "bolt-gateway")
GATEWAY_ENABLED = os.getenv("BOLT_GATEWAY_ENABLED", "true").lower() == "true"

async def validate_gateway_middleware(request: Request, call_next):
    # Skip validation for health endpoints (needed for container orchestration)
    if request.url.path in ["/health/live", "/health/ready", "/health"]:
        return await call_next(request)

    # Skip if gateway validation is disabled (development only)
    if not GATEWAY_ENABLED:
        return await call_next(request)

    # Validate gateway header
    forwarded_by = request.headers.get(GATEWAY_HEADER)
    if forwarded_by != GATEWAY_VALUE:
        raise HTTPException(
            status_code=403,
            detail={
                "error": "Direct access forbidden",
                "message": "Requests must be routed through the API gateway"
            }
        )

    return await call_next(request)
```

**Register middleware:**
```python
# main.py
from fastapi import FastAPI
from middleware.gateway_validation import validate_gateway_middleware

app = FastAPI()
app.middleware("http")(validate_gateway_middleware)
```

---

### 2. Gateway Secret Validation (MEDIUM PRIORITY)

**Why:** Additional security layer to prevent header spoofing. A shared secret between gateway and backend ensures authenticity.

**Implementation:**

```python
# middleware/gateway_validation.py (extended)
GATEWAY_SECRET = os.getenv("BOLT_GATEWAY_SECRET")

async def validate_gateway_middleware(request: Request, call_next):
    # ... existing header check ...

    # If secret is configured, validate it
    if GATEWAY_SECRET:
        provided_secret = request.headers.get("X-Gateway-Secret")
        if provided_secret != GATEWAY_SECRET:
            raise HTTPException(
                status_code=403,
                detail={"error": "Invalid gateway credentials"}
            )

    return await call_next(request)
```

**Gateway configuration:**
```nginx
# Bolt Gateway nginx.conf
proxy_set_header X-Gateway-Secret $GATEWAY_SECRET;
```

---

### 3. Network-Level Isolation (HIGH PRIORITY)

**Why:** Even with header validation, the service should not be publicly accessible. Defense in depth requires network-level controls.

**Docker Compose:**
```yaml
services:
  manifast:
    image: manifast:latest
    # DO NOT expose ports publicly
    # ports:
    #   - "8000:8000"  # REMOVE THIS

    # Only expose internally to other containers
    expose:
      - "8000"

    networks:
      - internal

  bolt-gateway:
    image: bolt-gateway:latest
    ports:
      - "8088:80"  # Only gateway is public
    networks:
      - internal
      - public

networks:
  internal:
    internal: true  # No external access
  public:
    driver: bridge
```

**Kubernetes:**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: manifast
spec:
  type: ClusterIP  # Internal only, not LoadBalancer
  ports:
    - port: 8000
  selector:
    app: manifast
```

---

### 4. Health Endpoints Without Gateway Requirement (HIGH PRIORITY)

**Why:** Container orchestration systems (Docker, Kubernetes) need to check service health directly. These checks don't go through the gateway.

**Implementation:**

```python
# Health endpoints exempt from gateway validation
@app.get("/health/live")
async def liveness():
    """Kubernetes liveness probe - is the process running?"""
    return {"status": "healthy", "service": "manifast"}

@app.get("/health/ready")
async def readiness():
    """Kubernetes readiness probe - can it accept traffic?"""
    # Check database connection, etc.
    return {"status": "ready", "service": "manifast"}

@app.get("/health")
async def health():
    """General health check"""
    return {
        "status": "healthy",
        "service": "manifast",
        "version": "1.0.0"
    }
```

---

## Acceptance Criteria

- [ ] `curl http://manifast:8000/api/` returns 403 Forbidden
- [ ] `curl -H "X-Forwarded-By: bolt-gateway" http://manifast:8000/api/` returns 200
- [ ] `curl http://manifast:8000/health/live` returns 200 (no gateway header needed)
- [ ] Service is not accessible from outside the container network

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BOLT_GATEWAY_ENABLED` | `true` | Enable/disable gateway validation |
| `BOLT_GATEWAY_HEADER` | `X-Forwarded-By` | Header name to check |
| `BOLT_GATEWAY_VALUE` | `bolt-gateway` | Expected header value |
| `BOLT_GATEWAY_SECRET` | `` | Shared secret (optional) |

---

## Security Considerations

1. **Development vs Production**
   - Development: May disable gateway validation for testing
   - Production: MUST enable gateway validation

2. **Header Spoofing**
   - Headers can be spoofed if service is directly accessible
   - Network isolation is the primary defense
   - Shared secret adds additional protection

3. **Health Endpoint Security**
   - Health endpoints should NOT expose sensitive information
   - Only return status, not internal details
   - Consider rate limiting health endpoints

---

## Testing

```bash
# Should fail - no gateway header
curl http://localhost:8000/api/
# Expected: 403 Forbidden

# Should succeed - with gateway header
curl -H "X-Forwarded-By: bolt-gateway" http://localhost:8000/api/
# Expected: 200 OK

# Should succeed - health endpoints exempt
curl http://localhost:8000/health/live
# Expected: 200 OK

# Full flow test through gateway
curl http://localhost:8088/api/
# Expected: 200 OK (gateway adds header automatically)
```
