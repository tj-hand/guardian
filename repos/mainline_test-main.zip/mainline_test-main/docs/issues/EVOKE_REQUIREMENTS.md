# Evoke - API Client Service Requirements

## Overview

Evoke is a JavaScript API client that communicates with Bolt Gateway. As a service that serves browser-based clients, it must support standard web protocols.

---

## Required Features

### 1. CORS Support (HIGH PRIORITY)

**Why:** Browsers enforce CORS (Cross-Origin Resource Sharing) policy. Without proper CORS headers, browser-based applications cannot make requests to Evoke.

**Implementation:**

```nginx
# nginx.conf - Add to server block
add_header 'Access-Control-Allow-Origin' '*' always;
add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS' always;
add_header 'Access-Control-Allow-Headers' 'Content-Type, Authorization, X-Requested-With, Accept, Origin' always;
add_header 'Access-Control-Expose-Headers' 'Content-Length, Content-Range' always;

# Handle preflight requests
if ($request_method = 'OPTIONS') {
    add_header 'Access-Control-Allow-Origin' '*';
    add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS';
    add_header 'Access-Control-Allow-Headers' 'Content-Type, Authorization, X-Requested-With, Accept, Origin';
    add_header 'Access-Control-Max-Age' 1728000;
    add_header 'Content-Length' 0;
    add_header 'Content-Type' 'text/plain charset=UTF-8';
    return 204;
}
```

**Note:** In production, replace `*` with specific allowed origins for security.

---

### 2. Health Endpoint (HIGH PRIORITY)

**Why:** Container orchestration systems (Docker, Kubernetes) require health endpoints to monitor service status. Clients may also need to verify service availability.

**Implementation:**

```nginx
location = /health {
    add_header 'Access-Control-Allow-Origin' '*' always;
    add_header 'Content-Type' 'application/json' always;
    return 200 '{"status":"healthy","service":"evoke","version":"1.0.0"}';
}
```

**Expected Response:**
```json
{
  "status": "healthy",
  "service": "evoke",
  "version": "1.0.0"
}
```

---

### 3. Client Identification Header (MEDIUM PRIORITY)

**Why:** Downstream services (Bolt Gateway) need to identify the source of requests for:
- Access control
- Rate limiting
- Logging and debugging
- Security auditing

**Implementation:**

When proxying requests to Bolt Gateway, add identification header:

```nginx
location /api/ {
    proxy_pass http://bolt-gateway:8088/;
    proxy_set_header X-Client-ID evoke;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
}
```

---

### 4. JavaScript Client Library (HIGH PRIORITY)

**Why:** Evoke's primary purpose is to provide a JavaScript client for API communication. This library must be accessible for browser applications.

**Requirements:**
- Serve compiled JavaScript at a known path (e.g., `/dist/evoke.js`)
- Support ES modules and/or UMD format
- Provide TypeScript definitions if applicable

**Expected:**
```
GET /dist/evoke.js  → JavaScript client library
GET /dist/evoke.d.ts → TypeScript definitions (optional)
```

---

## Acceptance Criteria

- [ ] `curl -I http://evoke/` returns `Access-Control-Allow-Origin` header
- [ ] `curl http://evoke/health` returns JSON with status "healthy"
- [ ] `curl http://evoke/dist/evoke.js` returns JavaScript client code
- [ ] Requests proxied to Bolt include `X-Client-ID: evoke` header

---

## Configuration Example

Complete nginx.conf example:

```nginx
server {
    listen 80;
    server_name _;

    root /usr/share/nginx/html;
    index index.html;

    # CORS headers for all responses
    add_header 'Access-Control-Allow-Origin' '*' always;
    add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS' always;
    add_header 'Access-Control-Allow-Headers' 'Content-Type, Authorization, Accept, Origin' always;

    # Health endpoint
    location = /health {
        add_header 'Content-Type' 'application/json' always;
        return 200 '{"status":"healthy","service":"evoke"}';
    }

    # Serve static files (JS client library)
    location /dist/ {
        try_files $uri =404;
    }

    # Proxy API requests to Bolt Gateway
    location /api/ {
        proxy_pass http://bolt-gateway:8088/;
        proxy_set_header Host $host;
        proxy_set_header X-Client-ID evoke;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Handle preflight
    if ($request_method = 'OPTIONS') {
        add_header 'Access-Control-Allow-Origin' '*';
        add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS';
        add_header 'Access-Control-Allow-Headers' 'Content-Type, Authorization, Accept, Origin';
        add_header 'Access-Control-Max-Age' 1728000;
        return 204;
    }

    # Default - serve frontend
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```
