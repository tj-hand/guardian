# Mainline Integration Test

Integration test environment for the **Evoke → Bolt → Manifast** service stack.

## Purpose

This repository provides:

- **Integration Testing** - Verify that all services work together correctly
- **Local Development** - Run the complete stack locally with Docker Compose
- **Flow Validation** - Ensure requests follow the correct layered path

## Architecture

```
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│   Test Harness   │────▶│      Evoke       │────▶│   Bolt Gateway   │────▶│     Manifast     │
│      :3001       │     │      :3000       │     │      :8088       │     │    (internal)    │
└──────────────────┘     └──────────────────┘     └──────────────────┘     └──────────────────┘
    Browser UI              API Client              API Gateway              Backend API
```

**Key Principle:** Each service only accepts requests from its adjacent upstream service.

## Quick Start

```bash
# Clone the repository
git clone https://github.com/tj-hand/mainline_test.git
cd mainline_test

# Start all services
docker compose up -d

# Open Test Harness in browser
open http://localhost:3001
```

## Services

| Service | Port | Access | Description |
|---------|------|--------|-------------|
| Test Harness | 3001 | Public | Web UI for testing the integration flow |
| Evoke | 3000 | Public | API client with CORS support |
| Bolt Gateway | 8088 | Public | API gateway with built-in routing |
| Manifast | - | Internal | Backend API (no public port) |

## Request Flow

1. **Test Harness** serves the testing UI
2. All API requests go through **Evoke** (`/evoke/*`)
3. Evoke proxies requests to **Bolt Gateway**
4. Bolt adds `X-Forwarded-By: bolt-gateway` header
5. **Manifast** validates the gateway header and processes the request

## What This Repo Contains

```
mainline_test/
├── docker-compose.yml              # Service orchestration
├── config/
│   └── test-harness/
│       ├── index.html              # Test Harness UI
│       └── nginx.conf              # Simple nginx proxy
└── docs/
    ├── INTEGRATION.md              # Service integration details
    └── issues/                     # Service requirements (reference)
```

## What This Repo Does NOT Contain

Each service is self-contained. This repo has no:

- Bolt routes (built into Bolt Gateway image)
- CORS configuration (handled by Evoke)
- Manifast middleware (Manifast validates internally)

## Testing

Open http://localhost:3001 to access the Test Harness:

1. The flow diagram shows real-time service health
2. Click endpoint buttons to test API calls
3. All requests flow through: Test Harness → Evoke → Bolt → Manifast

## Configuration

Create a `.env` file to customize:

```env
# Service versions
MANIFAST_VERSION=latest
BOLT_VERSION=latest
EVOKE_VERSION=latest

# Ports
EVOKE_PORT=3000
BOLT_HTTP_PORT=8088
TEST_HARNESS_PORT=3001

# Security (optional)
BOLT_GATEWAY_SECRET=your-secret
```

## Commands

```bash
# Start services
docker compose up -d

# View logs
docker compose logs -f

# Stop services
docker compose down

# Rebuild after changes
docker compose up -d --build
```

## Documentation

- [Integration Guide](docs/INTEGRATION.md) - How services work together
- [Service Requirements](docs/issues/) - Specifications for each service

## Related Repositories

| Repository | Description |
|------------|-------------|
| [tj-hand/evoke](https://github.com/tj-hand/evoke) | API Client |
| [tj-hand/bolt-gateway](https://github.com/tj-hand/bolt-gateway) | API Gateway |
| [tj-hand/manifast](https://github.com/tj-hand/manifast) | Backend API |
