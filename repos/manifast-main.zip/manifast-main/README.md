# Manifast

Manifast - The FastAPI boundary that receives, validates, and routes requests to backend services.

## Architecture Context

This repository is the **Layer 0 Backend** container in the Modular Layered Architecture system.

For complete architecture documentation, see: [MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md](./MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md)

```
Layer 5: Comprehensive Logging   ← Cross-cutting (all layers)
Layer 4: Languages (i18n)        ← Depends on Layer 1
Layer 3: Authenticated Area      ← Depends on Layer 2
Layer 2: Multitenant/RBAC        ← Depends on Layer 1
Layer 1: Authentication          ← Depends on Layer 0
Layer 0: Core Infrastructure     ← Foundation (THIS REPO)
```

## Quick Start

```bash
# Clone and setup
git clone https://github.com/tj-hand/manifast.git
cd manifast
cp .env.example .env

# Run with Docker
docker compose -f docker-compose.dev.yml up -d

# Or run locally
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Security

Manifast implements a defense-in-depth security model:

### 1. Network-Level Isolation (Primary)
- Manifast runs on an internal Docker network
- Only accessible to other containers (e.g., Bolt Gateway)
- No public port exposure in production

### 2. Gateway Validation Middleware (Secondary)
- Validates requests are routed through Bolt Gateway
- Checks for `X-Forwarded-By: bolt-gateway` header
- Optional shared secret validation via `X-Gateway-Secret`
- Automatically exempts health endpoints for container orchestration

### Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `BOLT_GATEWAY_ENABLED` | `true` | Enable/disable gateway validation |
| `BOLT_GATEWAY_HEADER` | `X-Forwarded-By` | Header to check for gateway routing |
| `BOLT_GATEWAY_VALUE` | `bolt-gateway` | Expected header value |
| `BOLT_GATEWAY_SECRET` | `` | Optional shared secret for additional security |

### Testing Gateway Validation

```bash
# Direct access blocked (when enabled)
curl http://localhost:8000/api/test
# Returns: 403 Forbidden

# With gateway header
curl -H "X-Forwarded-By: bolt-gateway" http://localhost:8000/api/test
# Returns: 404 (passes through middleware)

# Health endpoints always accessible
curl http://localhost:8000/health
# Returns: 200 OK
```

## Health Endpoints

| Endpoint | Purpose |
|----------|---------|
| `/health` | Full health check with component status |
| `/health/live` | Kubernetes liveness probe |
| `/health/ready` | Kubernetes readiness probe |

## Documentation

- [Deployment Guide](./docs/DEPLOYMENT.md)
- [GitHub Workflows](./docs/GITHUB_WORKFLOWS.md)
- [Architecture](./MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md)

## Development

```bash
# Run tests
pytest tests/ -v

# Run linter
ruff check app/ tests/

# Format code
ruff format app/ tests/
```

## License

MIT
