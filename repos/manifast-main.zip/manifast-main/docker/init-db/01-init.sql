-- Manifast Database Initialization
-- This script runs when the PostgreSQL container is first created

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create schema for application tables
CREATE SCHEMA IF NOT EXISTS manifast;

-- Grant permissions
GRANT ALL PRIVILEGES ON SCHEMA manifast TO manifast;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA manifast TO manifast;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA manifast TO manifast;

-- Set default search path
ALTER DATABASE manifast SET search_path TO manifast, public;

-- Log initialization
DO $$
BEGIN
    RAISE NOTICE 'Manifast database initialized successfully';
END $$;
