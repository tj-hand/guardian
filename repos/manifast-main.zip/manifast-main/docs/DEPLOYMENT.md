# Manifast Deployment Guide

This guide covers deploying Manifast Layer 0 Backend to production environments.

## Prerequisites

- Docker 20.10+ and Docker Compose V2
- PostgreSQL 16+ (managed or self-hosted)
- Redis 7+ (managed or self-hosted)
- Access to Bolt API Gateway configuration

## Quick Start

### 1. Clone and Configure

```bash
# Clone repository
git clone https://github.com/tj-hand/manifast.git
cd manifast

# Create production environment file
cp .env.prod.example .env.prod

# Edit with your production values
nano .env.prod
```

### 2. Required Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql+asyncpg://user:pass@host:5432/db` |
| `REDIS_URL` | Redis connection string | `redis://:pass@host:6379/0` |
| `BOLT_GATEWAY_ENABLED` | Enable gateway validation | `true` |
| `BOLT_GATEWAY_SECRET` | Shared secret with gateway (optional) | `<strong-secret>` |

### 3. Deploy

```bash
# Build and start
docker compose -f docker-compose.prod.yml up -d

# Check logs
docker logs manifast-api-prod -f

# Verify health
curl http://localhost:8000/health
```

## Deployment Options

### Option A: Docker Compose (Single Node)

Best for: Small deployments, staging environments.

```bash
# Using pre-built image
docker compose -f docker-compose.prod.yml pull
docker compose -f docker-compose.prod.yml up -d

# Or build locally
docker compose -f docker-compose.prod.yml up -d --build
```

### Option B: Kubernetes

Best for: Production at scale, auto-scaling requirements.

```yaml
# Example Kubernetes deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: manifast-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: manifast-api
  template:
    metadata:
      labels:
        app: manifast-api
    spec:
      containers:
        - name: manifast
          image: ghcr.io/tj-hand/manifast:latest
          ports:
            - containerPort: 8000
          env:
            - name: DATABASE_URL
              valueFrom:
                secretKeyRef:
                  name: manifast-secrets
                  key: database-url
          livenessProbe:
            httpGet:
              path: /health/live
              port: 8000
            initialDelaySeconds: 10
          readinessProbe:
            httpGet:
              path: /health/ready
              port: 8000
```

### Option C: Cloud Run / ECS / App Runner

Best for: Serverless deployments, pay-per-use.

```bash
# Google Cloud Run example
gcloud run deploy manifast \
  --image ghcr.io/tj-hand/manifast:latest \
  --port 8000 \
  --set-env-vars "ENVIRONMENT=production,DEBUG=false" \
  --set-secrets "DATABASE_URL=manifast-db-url:latest,REDIS_URL=manifast-redis-url:latest"
```

## Security Checklist

Before going live, verify:

- [ ] `DEBUG=false` in production
- [ ] `BOLT_GATEWAY_ENABLED=true` (defense-in-depth validation)
- [ ] `BOLT_GATEWAY_SECRET` is set for additional security (recommended)
- [ ] `CORS_ORIGINS` restricted to your frontend domains
- [ ] Database uses SSL (`?ssl=require` in URL)
- [ ] Redis uses TLS in production
- [ ] Secrets are not in environment files (use secret manager)
- [ ] Container runs as non-root user (already configured)
- [ ] Network isolation: Manifast only accessible via internal network

## Health Checks

The application exposes three health endpoints:

| Endpoint | Purpose | Use Case |
|----------|---------|----------|
| `/health` | Full health status | Monitoring dashboards |
| `/health/live` | Liveness check | Kubernetes livenessProbe |
| `/health/ready` | Readiness check | Kubernetes readinessProbe |

Example response from `/health`:

```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "version": "0.1.0",
    "environment": "production",
    "checks": {
      "database": "healthy",
      "redis": "healthy"
    }
  }
}
```

## Scaling Guidelines

### Horizontal Scaling

Manifast is stateless and supports horizontal scaling:

```yaml
# docker-compose.prod.yml
services:
  manifast:
    deploy:
      replicas: 3
```

For Kubernetes, use HPA:

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: manifast-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: manifast-api
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
```

### Resource Recommendations

| Environment | CPU | Memory | Workers |
|-------------|-----|--------|---------|
| Development | 0.5 | 256Mi | 1 |
| Staging | 1 | 512Mi | 2 |
| Production | 2 | 1Gi | 4 |

## Database Migrations

Run migrations before deploying new versions:

```bash
# Inside container
docker exec manifast-api-prod alembic upgrade head

# Or during deployment
docker run --rm \
  -e DATABASE_URL=$DATABASE_URL \
  ghcr.io/tj-hand/manifast:latest \
  alembic upgrade head
```

## Monitoring

### Logs

Logs are output to stdout in JSON format:

```bash
# View logs
docker logs manifast-api-prod -f

# Filter by level
docker logs manifast-api-prod 2>&1 | grep ERROR
```

### Metrics

Prometheus metrics endpoint (when enabled):

```
GET /metrics
```

## Troubleshooting

### Common Issues

**503 Service Unavailable on /health/ready**

Database or Redis connection failed. Check:
- `DATABASE_URL` is correct and accessible
- `REDIS_URL` is correct and accessible
- Network connectivity between containers

**403 Forbidden on API endpoints**

Gateway validation failed. Check:
- `BOLT_GATEWAY_ENABLED` is `true` (or `false` for local dev)
- Request includes `X-Forwarded-By: bolt-gateway` header
- If `BOLT_GATEWAY_SECRET` is set, request must include `X-Gateway-Secret` header with matching value
- Health endpoints (`/health`, `/health/live`, `/health/ready`) are exempt from validation

**Container keeps restarting**

Check logs for startup errors:
```bash
docker logs manifast-api-prod --tail 100
```

## Rollback

To rollback to a previous version:

```bash
# Using specific tag
docker compose -f docker-compose.prod.yml pull
docker compose -f docker-compose.prod.yml up -d

# Or specify image tag
IMAGE_TAG=v0.1.0 docker compose -f docker-compose.prod.yml up -d
```

## Support

- Issues: https://github.com/tj-hand/manifast/issues
- Documentation: https://github.com/tj-hand/manifast/docs
