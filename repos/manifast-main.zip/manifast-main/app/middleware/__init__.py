"""
Middleware package for Manifast API.
"""

from app.middleware.gateway_validation import validate_gateway_middleware

__all__ = ["validate_gateway_middleware"]
