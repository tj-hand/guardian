"""
Gateway Validation Middleware

Defense-in-depth middleware that ensures requests are routed through the
Bolt Gateway. This provides an additional layer of security on top of
network-level isolation.

Features:
- Validates presence of gateway header
- Optional shared secret validation
- Exempts health check endpoints for container orchestration
"""

import logging

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import Response

from app.core.config import settings

logger = logging.getLogger(__name__)

# Health endpoints that should be accessible without gateway routing
# These are needed for container orchestration (Docker, Kubernetes)
EXEMPT_PATHS = {
    "/health",
    "/health/live",
    "/health/ready",
    "/",
    "/docs",
    "/redoc",
    "/openapi.json",
}


class GatewayValidationMiddleware(BaseHTTPMiddleware):
    """
    Middleware to validate that requests are routed through Bolt Gateway.

    This middleware checks for a specific header that the gateway adds to
    all forwarded requests. If the header is missing or invalid, the request
    is rejected with a 403 Forbidden response.

    Configuration:
        BOLT_GATEWAY_ENABLED: Enable/disable validation (default: True)
        BOLT_GATEWAY_HEADER: Header name to check (default: X-Forwarded-By)
        BOLT_GATEWAY_VALUE: Expected header value (default: bolt-gateway)
        BOLT_GATEWAY_SECRET: Optional shared secret for additional security
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        """Process the request and validate gateway routing."""

        # Skip validation if disabled (development mode)
        if not settings.bolt_gateway_enabled:
            return await call_next(request)

        # Skip validation for exempt paths (health checks, docs)
        if request.url.path in EXEMPT_PATHS:
            return await call_next(request)

        # Validate gateway header
        forwarded_by = request.headers.get(settings.bolt_gateway_header)
        if forwarded_by != settings.bolt_gateway_value:
            logger.warning(
                "Direct access attempt blocked",
                extra={
                    "path": request.url.path,
                    "method": request.method,
                    "client_host": request.client.host if request.client else "unknown",
                    "header_present": forwarded_by is not None,
                },
            )
            return JSONResponse(
                status_code=403,
                content={
                    "error": "Direct access forbidden",
                    "message": "Requests must be routed through the API gateway",
                },
            )

        # Validate shared secret if configured
        if settings.bolt_gateway_secret:
            provided_secret = request.headers.get("X-Gateway-Secret")
            if provided_secret != settings.bolt_gateway_secret:
                logger.warning(
                    "Invalid gateway secret",
                    extra={
                        "path": request.url.path,
                        "method": request.method,
                        "client_host": request.client.host if request.client else "unknown",
                    },
                )
                return JSONResponse(
                    status_code=403,
                    content={"error": "Invalid gateway credentials"},
                )

        return await call_next(request)


async def validate_gateway_middleware(request: Request, call_next):
    """
    Functional middleware for gateway validation.

    This is an alternative to the class-based middleware that can be
    registered using app.middleware("http").

    Usage:
        app.middleware("http")(validate_gateway_middleware)
    """
    # Skip validation if disabled
    if not settings.bolt_gateway_enabled:
        return await call_next(request)

    # Skip validation for exempt paths
    if request.url.path in EXEMPT_PATHS:
        return await call_next(request)

    # Validate gateway header
    forwarded_by = request.headers.get(settings.bolt_gateway_header)
    if forwarded_by != settings.bolt_gateway_value:
        logger.warning(
            "Direct access attempt blocked",
            extra={
                "path": request.url.path,
                "method": request.method,
                "client_host": request.client.host if request.client else "unknown",
                "header_present": forwarded_by is not None,
            },
        )
        return JSONResponse(
            status_code=403,
            content={
                "error": "Direct access forbidden",
                "message": "Requests must be routed through the API gateway",
            },
        )

    # Validate shared secret if configured
    if settings.bolt_gateway_secret:
        provided_secret = request.headers.get("X-Gateway-Secret")
        if provided_secret != settings.bolt_gateway_secret:
            logger.warning(
                "Invalid gateway secret",
                extra={
                    "path": request.url.path,
                    "method": request.method,
                    "client_host": request.client.host if request.client else "unknown",
                },
            )
            return JSONResponse(
                status_code=403,
                content={"error": "Invalid gateway credentials"},
            )

    return await call_next(request)
