"""
Database Connection Layer
Async SQLAlchemy engine and session management for PostgreSQL.
"""

import logging
from collections.abc import AsyncGenerator

from sqlalchemy import MetaData, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from app.core.config import settings

logger = logging.getLogger(__name__)

# Naming convention for constraints (for Alembic migrations)
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

metadata = MetaData(naming_convention=NAMING_CONVENTION)


class Base(DeclarativeBase):
    """
    Base class for all SQLAlchemy models.

    All models should inherit from this class to be included
    in migrations and database operations.
    """

    metadata = metadata


# Global engine and session factory instances
_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_database_url() -> str | None:
    """
    Get the database URL from settings.

    Returns None if no database URL is configured.
    """
    if not settings.database_url:
        return None
    return settings.database_url


def create_engine() -> AsyncEngine | None:
    """
    Create the async SQLAlchemy engine.

    Returns None if no database URL is configured.
    """
    database_url = get_database_url()
    if not database_url:
        logger.warning("No DATABASE_URL configured, database features disabled")
        return None

    return create_async_engine(
        database_url,
        pool_size=settings.database_pool_size,
        max_overflow=settings.database_max_overflow,
        pool_pre_ping=True,  # Verify connections before use
        pool_recycle=300,  # Recycle connections after 5 minutes
        echo=settings.debug,  # Log SQL statements in debug mode
    )


def get_engine() -> AsyncEngine | None:
    """
    Get the async SQLAlchemy engine instance.

    Uses lazy initialization - engine is created on first access.
    Returns None if no database URL is configured.
    """
    global _engine
    if _engine is None:
        _engine = create_engine()
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession] | None:
    """
    Get the async session factory.

    Returns None if no database is configured.
    """
    global _session_factory
    if _session_factory is None:
        engine = get_engine()
        if engine is None:
            return None
        _session_factory = async_sessionmaker(
            bind=engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autocommit=False,
            autoflush=False,
        )
    return _session_factory


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency that provides an async database session.

    Usage:
        @app.get("/items")
        async def get_items(session: AsyncSession = Depends(get_session)):
            result = await session.execute(select(Item))
            return result.scalars().all()

    Yields:
        AsyncSession: Database session for the request.

    Raises:
        RuntimeError: If database is not configured.
    """
    session_factory = get_session_factory()
    if session_factory is None:
        raise RuntimeError("Database not configured. Set DATABASE_URL environment variable.")

    async with session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def check_database_connection() -> bool:
    """
    Check if the database connection is healthy.

    Returns:
        bool: True if connection is successful, False otherwise.
    """
    engine = get_engine()
    if engine is None:
        return False

    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
            return True
    except Exception as e:
        logger.error(f"Database connection check failed: {e}")
        return False


async def init_database() -> None:
    """
    Initialize database connection and verify connectivity.

    Called during application startup.
    """
    engine = get_engine()
    if engine is None:
        logger.info("Database not configured, skipping initialization")
        return

    if await check_database_connection():
        logger.info("Database connection established successfully")
    else:
        logger.error("Failed to establish database connection")


async def close_database() -> None:
    """
    Close database connections.

    Called during application shutdown.
    """
    global _engine, _session_factory

    if _engine is not None:
        await _engine.dispose()
        _engine = None
        _session_factory = None
        logger.info("Database connections closed")
