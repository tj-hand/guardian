"""
Security Utilities

Provides user context extraction from gateway-forwarded headers.
"""

import logging

from fastapi import Request

logger = logging.getLogger(__name__)


def get_current_user_from_token(request: Request) -> dict | None:
    """
    Extract user information from JWT token forwarded by Bolt Gateway.

    The gateway validates the token and forwards user info in headers.
    This function extracts that information for use in route handlers.

    Note: Full JWT validation will be implemented when needed.
    For now, we trust the gateway's validation.
    """
    user_id = request.headers.get("X-User-ID")
    user_email = request.headers.get("X-User-Email")
    user_roles = request.headers.get("X-User-Roles", "")

    if not user_id:
        return None

    return {
        "id": user_id,
        "email": user_email,
        "roles": [r.strip() for r in user_roles.split(",") if r.strip()],
    }
