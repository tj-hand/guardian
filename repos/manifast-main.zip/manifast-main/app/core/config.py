"""
Application Configuration
Environment-based settings using Pydantic Settings.
"""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.

    All configuration is managed via environment variables following
    12-factor app methodology.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Application
    app_name: str = Field(default="Manifast", description="Application name")
    app_version: str = Field(default="0.1.0", description="Application version")
    debug: bool = Field(default=False, description="Debug mode")
    environment: str = Field(default="development", description="Environment name")

    # API
    api_prefix: str = Field(default="/api", description="API route prefix")

    # CORS
    cors_origins: str = Field(default="*", description="Comma-separated allowed origins")
    cors_allow_credentials: bool = Field(default=True, description="Allow credentials in CORS")
    cors_allow_methods: str = Field(default="*", description="Comma-separated allowed HTTP methods")
    cors_allow_headers: str = Field(default="*", description="Comma-separated allowed headers")

    # Gateway Validation (defense-in-depth)
    bolt_gateway_enabled: bool = Field(
        default=True, description="Enable gateway validation middleware"
    )
    bolt_gateway_header: str = Field(
        default="X-Forwarded-By", description="Header name to check for gateway routing"
    )
    bolt_gateway_value: str = Field(
        default="bolt-gateway", description="Expected value of gateway header"
    )
    bolt_gateway_secret: str = Field(
        default="", description="Shared secret for gateway authentication (optional)"
    )

    # Database (prepared for Layer integration)
    database_url: str = Field(default="", description="PostgreSQL connection URL")
    database_pool_size: int = Field(default=5, description="Database connection pool size")
    database_max_overflow: int = Field(default=10, description="Maximum overflow connections")

    # Redis (prepared for Layer integration)
    redis_url: str = Field(default="", description="Redis connection URL")

    # Logging
    log_level: str = Field(default="INFO", description="Logging level")

    # Layer Router Configuration
    layer_router_enabled: bool = Field(
        default=True, description="Enable dynamic layer router mounting"
    )
    layer_router_config: str = Field(default="", description="JSON configuration for layer routers")

    @property
    def cors_origins_list(self) -> list[str]:
        """Parse CORS origins string into list."""
        if self.cors_origins == "*":
            return ["*"]
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def cors_methods_list(self) -> list[str]:
        """Parse CORS methods string into list."""
        if self.cors_allow_methods == "*":
            return ["*"]
        return [method.strip() for method in self.cors_allow_methods.split(",") if method.strip()]

    @property
    def cors_headers_list(self) -> list[str]:
        """Parse CORS headers string into list."""
        if self.cors_allow_headers == "*":
            return ["*"]
        return [header.strip() for header in self.cors_allow_headers.split(",") if header.strip()]


@lru_cache
def get_settings() -> Settings:
    """
    Get cached settings instance.

    Uses lru_cache to ensure settings are only loaded once.
    """
    return Settings()


# Global settings instance
settings = get_settings()
