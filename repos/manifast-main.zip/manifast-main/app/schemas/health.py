"""
Health Check Schemas
Pydantic models for health check responses.
"""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class HealthStatus(str, Enum):
    """Health status values."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class ComponentHealth(BaseModel):
    """Health status for a single component."""

    status: HealthStatus = Field(description="Component health status")
    latency_ms: float | None = Field(default=None, description="Response latency in milliseconds")
    message: str | None = Field(default=None, description="Additional status information")


class HealthCheckResponse(BaseModel):
    """
    Health check response.

    Provides comprehensive health status for container orchestration
    and monitoring systems.
    """

    status: HealthStatus = Field(description="Overall application health status")
    version: str = Field(description="Application version")
    environment: str = Field(description="Current environment (development, staging, production)")
    timestamp: datetime = Field(
        default_factory=datetime.utcnow, description="Health check timestamp"
    )
    uptime_seconds: float | None = Field(default=None, description="Application uptime in seconds")
    components: dict[str, ComponentHealth] = Field(
        default_factory=dict, description="Health status of individual components"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "status": "healthy",
                    "version": "0.1.0",
                    "environment": "development",
                    "timestamp": "2025-11-25T12:00:00Z",
                    "uptime_seconds": 3600.5,
                    "components": {
                        "database": {"status": "healthy", "latency_ms": 5.2, "message": None},
                        "redis": {"status": "healthy", "latency_ms": 1.1, "message": None},
                    },
                }
            ]
        }
    }
