"""
Base Schemas
Common Pydantic models for consistent API responses.
"""

from datetime import datetime
from typing import Generic, TypeVar

from pydantic import BaseModel, Field

# Generic type for response data
T = TypeVar("T")


class BaseResponse(BaseModel, Generic[T]):
    """
    Standard API response wrapper.

    Provides consistent structure for all successful API responses.
    """

    success: bool = Field(default=True, description="Indicates if the request was successful")
    data: T | None = Field(default=None, description="Response payload")
    message: str | None = Field(
        default=None, description="Human-readable message about the response"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "success": True,
                    "data": {"id": 1, "name": "example"},
                    "message": "Operation completed successfully",
                }
            ]
        }
    }


class ErrorDetail(BaseModel):
    """
    Detailed error information.

    Provides structured error details for debugging.
    """

    field: str | None = Field(
        default=None, description="Field that caused the error (for validation errors)"
    )
    reason: str = Field(description="Specific reason for the error")


class ErrorResponse(BaseModel):
    """
    Standard API error response.

    Provides consistent structure for all error responses.
    """

    success: bool = Field(default=False, description="Always false for error responses")
    code: str = Field(
        description="Machine-readable error code (e.g., 'VALIDATION_ERROR', 'NOT_FOUND')"
    )
    detail: str = Field(description="Human-readable error message")
    timestamp: datetime = Field(
        default_factory=datetime.utcnow, description="Time when the error occurred"
    )
    errors: list[ErrorDetail] | None = Field(
        default=None, description="List of detailed errors (for validation errors)"
    )
    request_id: str | None = Field(default=None, description="Request ID for tracing")

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "success": False,
                    "code": "VALIDATION_ERROR",
                    "detail": "Request validation failed",
                    "timestamp": "2025-11-25T12:00:00Z",
                    "errors": [{"field": "email", "reason": "Invalid email format"}],
                    "request_id": "req-123-abc",
                }
            ]
        }
    }


class PaginationMeta(BaseModel):
    """
    Pagination metadata.

    Provides information about paginated results.
    """

    page: int = Field(ge=1, description="Current page number (1-indexed)")
    page_size: int = Field(ge=1, le=100, description="Number of items per page")
    total_items: int = Field(ge=0, description="Total number of items across all pages")
    total_pages: int = Field(ge=0, description="Total number of pages")
    has_next: bool = Field(description="Whether there are more pages after the current one")
    has_previous: bool = Field(description="Whether there are pages before the current one")


class PaginatedResponse(BaseModel, Generic[T]):
    """
    Paginated API response.

    Used for list endpoints that support pagination.
    """

    success: bool = Field(default=True, description="Indicates if the request was successful")
    data: list[T] = Field(default_factory=list, description="List of items for the current page")
    pagination: PaginationMeta = Field(description="Pagination metadata")
    message: str | None = Field(
        default=None, description="Human-readable message about the response"
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "success": True,
                    "data": [{"id": 1}, {"id": 2}],
                    "pagination": {
                        "page": 1,
                        "page_size": 10,
                        "total_items": 25,
                        "total_pages": 3,
                        "has_next": True,
                        "has_previous": False,
                    },
                    "message": None,
                }
            ]
        }
    }


# Common error codes
class ErrorCodes:
    """Standard error codes used across the API."""

    # Client errors (4xx)
    VALIDATION_ERROR = "VALIDATION_ERROR"
    BAD_REQUEST = "BAD_REQUEST"
    UNAUTHORIZED = "UNAUTHORIZED"
    FORBIDDEN = "FORBIDDEN"
    NOT_FOUND = "NOT_FOUND"
    CONFLICT = "CONFLICT"
    RATE_LIMITED = "RATE_LIMITED"

    # Server errors (5xx)
    INTERNAL_ERROR = "INTERNAL_ERROR"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
    DATABASE_ERROR = "DATABASE_ERROR"
    EXTERNAL_SERVICE_ERROR = "EXTERNAL_SERVICE_ERROR"

    # Security errors
    INVALID_TOKEN = "INVALID_TOKEN"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"
