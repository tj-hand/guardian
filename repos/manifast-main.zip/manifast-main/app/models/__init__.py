"""
Models Package
SQLAlchemy ORM models - READ-ONLY for FastAPI Agent.
Database Agent owns schema modifications.
"""
