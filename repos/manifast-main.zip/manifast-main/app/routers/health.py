"""
Health Check Router
Endpoints for application health monitoring and container orchestration.
"""

import time
from datetime import datetime

from fastapi import APIRouter, status

from app.core.config import settings
from app.core.database import check_database_connection
from app.schemas.health import ComponentHealth, HealthCheckResponse, HealthStatus

router = APIRouter(tags=["Health"])

# Track application start time
_start_time = time.time()


async def check_database_health() -> ComponentHealth:
    """
    Check database connectivity.

    Returns health status for the database component.
    """
    if not settings.database_url:
        return ComponentHealth(
            status=HealthStatus.HEALTHY, message="Database not configured (development mode)"
        )

    start = time.time()
    try:
        is_connected = await check_database_connection()
        latency = (time.time() - start) * 1000

        if is_connected:
            return ComponentHealth(
                status=HealthStatus.HEALTHY,
                latency_ms=round(latency, 2),
                message="Database connection successful",
            )
        else:
            return ComponentHealth(
                status=HealthStatus.UNHEALTHY,
                latency_ms=round(latency, 2),
                message="Database connection failed",
            )
    except Exception as e:
        return ComponentHealth(
            status=HealthStatus.UNHEALTHY, message=f"Database connection failed: {str(e)}"
        )


async def check_redis_health() -> ComponentHealth:
    """
    Check Redis connectivity.

    Returns health status for the Redis component.
    Note: Redis connection will be implemented in Sprint 2.
    """
    if not settings.redis_url:
        return ComponentHealth(
            status=HealthStatus.HEALTHY, message="Redis not configured (development mode)"
        )

    # TODO: Implement actual Redis connectivity check
    start = time.time()
    try:
        # Placeholder for actual Redis ping
        latency = (time.time() - start) * 1000
        return ComponentHealth(
            status=HealthStatus.HEALTHY,
            latency_ms=round(latency, 2),
            message="Redis configured (connection test pending)",
        )
    except Exception as e:
        return ComponentHealth(
            status=HealthStatus.UNHEALTHY, message=f"Redis connection failed: {str(e)}"
        )


def determine_overall_status(components: dict[str, ComponentHealth]) -> HealthStatus:
    """
    Determine overall health status based on component health.

    - All healthy = healthy
    - Any degraded = degraded
    - Any unhealthy = unhealthy
    """
    statuses = [c.status for c in components.values()]

    if HealthStatus.UNHEALTHY in statuses:
        return HealthStatus.UNHEALTHY
    if HealthStatus.DEGRADED in statuses:
        return HealthStatus.DEGRADED
    return HealthStatus.HEALTHY


@router.get(
    "/health",
    response_model=HealthCheckResponse,
    status_code=status.HTTP_200_OK,
    summary="Comprehensive Health Check",
    description="""
Check application health status for container orchestration and monitoring.

This endpoint performs comprehensive health checks on all system components:
- Database connectivity and latency
- Redis connectivity and latency

**Note:** This endpoint bypasses Bolt Gateway validation for direct access
by container orchestrators (Kubernetes, Docker Swarm, etc.).

**Response Status Codes:**
- `200 OK`: Application is healthy (all components operational)
- `503 Service Unavailable`: Application is unhealthy (critical component failed)
    """,
    responses={
        200: {
            "description": "Application is healthy",
            "content": {
                "application/json": {
                    "example": {
                        "status": "healthy",
                        "version": "0.1.0",
                        "environment": "production",
                        "timestamp": "2025-11-25T12:00:00Z",
                        "uptime_seconds": 86400.5,
                        "components": {
                            "database": {
                                "status": "healthy",
                                "latency_ms": 5.2,
                                "message": "Database connection successful",
                            },
                            "redis": {
                                "status": "healthy",
                                "latency_ms": 1.1,
                                "message": "Redis connection successful",
                            },
                        },
                    }
                }
            },
        },
        503: {
            "description": "Application is unhealthy",
            "content": {
                "application/json": {
                    "example": {
                        "status": "unhealthy",
                        "version": "0.1.0",
                        "environment": "production",
                        "timestamp": "2025-11-25T12:00:00Z",
                        "uptime_seconds": 86400.5,
                        "components": {
                            "database": {
                                "status": "unhealthy",
                                "latency_ms": None,
                                "message": "Database connection failed: Connection refused",
                            },
                            "redis": {
                                "status": "healthy",
                                "latency_ms": 1.1,
                                "message": "Redis connection successful",
                            },
                        },
                    }
                }
            },
        },
    },
)
async def health_check() -> HealthCheckResponse:
    """
    Comprehensive health check endpoint.

    Checks:
    - Application status
    - Database connectivity (when configured)
    - Redis connectivity (when configured)

    Returns version and environment information for deployment verification.
    """
    # Check component health
    components = {
        "database": await check_database_health(),
        "redis": await check_redis_health(),
    }

    # Calculate uptime
    uptime_seconds = round(time.time() - _start_time, 2)

    # Determine overall status
    overall_status = determine_overall_status(components)

    return HealthCheckResponse(
        status=overall_status,
        version=settings.app_version,
        environment=settings.environment,
        timestamp=datetime.utcnow(),
        uptime_seconds=uptime_seconds,
        components=components,
    )


@router.get(
    "/health/live",
    status_code=status.HTTP_200_OK,
    summary="Liveness Probe",
    description="""
Kubernetes liveness probe - checks if the application process is running.

This is a lightweight endpoint that returns immediately without checking
external dependencies. Used by Kubernetes to determine if the container
should be restarted.

**Use Case:** Configure as `livenessProbe` in Kubernetes deployment.

**Note:** This endpoint bypasses Bolt Gateway validation.
    """,
    responses={
        200: {
            "description": "Application is alive",
            "content": {"application/json": {"example": {"status": "alive"}}},
        }
    },
)
async def liveness_probe() -> dict:
    """
    Simple liveness probe for Kubernetes.

    Returns immediately if the application is running.
    Used by Kubernetes to determine if the container should be restarted.
    """
    return {"status": "alive"}


@router.get(
    "/health/ready",
    status_code=status.HTTP_200_OK,
    summary="Readiness Probe",
    description="""
Kubernetes readiness probe - checks if the application is ready to receive traffic.

This endpoint verifies that critical dependencies (database, cache) are accessible
before allowing traffic to be routed to this instance.

**Use Case:** Configure as `readinessProbe` in Kubernetes deployment.

**Note:** This endpoint bypasses Bolt Gateway validation.

**Response Status Codes:**
- `200 OK`: Application is ready to receive traffic
- `503 Service Unavailable`: Application is not ready (dependency unavailable)
    """,
    responses={
        200: {
            "description": "Application is ready",
            "content": {"application/json": {"example": {"status": "ready"}}},
        },
        503: {
            "description": "Application is not ready",
            "content": {"application/json": {"example": {"detail": "Application not ready"}}},
        },
    },
)
async def readiness_probe() -> dict:
    """
    Readiness probe for Kubernetes.

    Checks if the application is ready to handle requests.
    Used by Kubernetes to determine if traffic should be routed to this pod.
    """
    # Check critical dependencies
    db_health = await check_database_health()
    redis_health = await check_redis_health()

    # Application is ready if no critical component is unhealthy
    is_ready = (
        db_health.status != HealthStatus.UNHEALTHY and redis_health.status != HealthStatus.UNHEALTHY
    )

    if is_ready:
        return {"status": "ready"}

    # Return 503 if not ready
    from fastapi import HTTPException

    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Application not ready"
    )
