"""
Dynamic Layer Router Mounting System
Enables dynamic registration and mounting of routers from upper layers (1-5).
"""

import importlib
import json
import logging
from dataclasses import dataclass, field
from typing import Any

from fastapi import APIRouter, FastAPI

from app.core.config import settings

logger = logging.getLogger(__name__)


@dataclass
class LayerConfig:
    """Configuration for a layer router."""

    layer: int
    module: str
    router_name: str = "router"
    prefix: str = ""
    tags: list[str] = field(default_factory=list)
    enabled: bool = True
    dependencies: list[int] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Set default prefix and tags if not provided."""
        if not self.prefix:
            self.prefix = f"/api/layer{self.layer}"
        if not self.tags:
            self.tags = [f"Layer {self.layer}"]


class LayerRouterManager:
    """
    Manages dynamic mounting of layer routers.

    Layers represent different functional domains:
    - Layer 0: Core Infrastructure (this application)
    - Layer 1: Authentication & Authorization
    - Layer 2: User Management
    - Layer 3: Business Logic
    - Layer 4: Integration Services
    - Layer 5: Admin & Analytics
    """

    # Default layer configurations (can be overridden via environment)
    DEFAULT_LAYERS: list[dict[str, Any]] = [
        {
            "layer": 1,
            "module": "app.layers.auth.router",
            "prefix": "/api/auth",
            "tags": ["Authentication"],
            "enabled": False,  # Disabled until implemented
        },
        {
            "layer": 2,
            "module": "app.layers.users.router",
            "prefix": "/api/users",
            "tags": ["Users"],
            "enabled": False,
            "dependencies": [1],  # Requires auth layer
        },
        {
            "layer": 3,
            "module": "app.layers.business.router",
            "prefix": "/api/v1",
            "tags": ["Business"],
            "enabled": False,
            "dependencies": [1, 2],
        },
        {
            "layer": 4,
            "module": "app.layers.integrations.router",
            "prefix": "/api/integrations",
            "tags": ["Integrations"],
            "enabled": False,
            "dependencies": [1],
        },
        {
            "layer": 5,
            "module": "app.layers.admin.router",
            "prefix": "/api/admin",
            "tags": ["Admin"],
            "enabled": False,
            "dependencies": [1, 2],
        },
    ]

    def __init__(self) -> None:
        """Initialize the layer router manager."""
        self._layers: dict[int, LayerConfig] = {}
        self._mounted_layers: set[int] = set()

    def load_config(self) -> list[LayerConfig]:
        """
        Load layer configurations from environment or defaults.

        Returns:
            List of LayerConfig objects.
        """
        config_data: list[dict[str, Any]] = []

        # Try to load from environment
        if settings.layer_router_config:
            try:
                config_data = json.loads(settings.layer_router_config)
                logger.info(f"Loaded {len(config_data)} layer configs from environment")
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse LAYER_ROUTER_CONFIG: {e}")
                config_data = self.DEFAULT_LAYERS
        else:
            config_data = self.DEFAULT_LAYERS

        layers = []
        for config in config_data:
            try:
                layer_config = LayerConfig(**config)
                layers.append(layer_config)
                self._layers[layer_config.layer] = layer_config
            except TypeError as e:
                logger.error(f"Invalid layer config: {config}, error: {e}")

        return layers

    def validate_dependencies(self, layer_config: LayerConfig) -> bool:
        """
        Check if all dependencies for a layer are satisfied.

        Args:
            layer_config: The layer configuration to check.

        Returns:
            True if all dependencies are mounted, False otherwise.
        """
        for dep_layer in layer_config.dependencies:
            if dep_layer not in self._mounted_layers:
                logger.warning(
                    f"Layer {layer_config.layer} requires Layer {dep_layer} which is not mounted"
                )
                return False
        return True

    def import_router(self, layer_config: LayerConfig) -> APIRouter | None:
        """
        Dynamically import a router from a module.

        Args:
            layer_config: Configuration for the layer to import.

        Returns:
            The imported APIRouter, or None if import fails.
        """
        try:
            module = importlib.import_module(layer_config.module)
            router = getattr(module, layer_config.router_name, None)

            if router is None:
                logger.error(
                    f"Router '{layer_config.router_name}' not found in "
                    f"module '{layer_config.module}'"
                )
                return None

            if not isinstance(router, APIRouter):
                logger.error(
                    f"'{layer_config.router_name}' in '{layer_config.module}' is not an APIRouter"
                )
                return None

            return router

        except ImportError as e:
            logger.debug(
                f"Layer {layer_config.layer} module not available: {layer_config.module} ({e})"
            )
            return None
        except Exception as e:
            logger.error(f"Failed to import Layer {layer_config.layer} router: {e}")
            return None

    def mount_layers(self, app: FastAPI) -> int:
        """
        Mount all enabled layer routers to the FastAPI application.

        Routers are mounted in order of layer number to ensure
        dependencies are satisfied.

        Args:
            app: The FastAPI application instance.

        Returns:
            Number of successfully mounted layers.
        """
        if not settings.layer_router_enabled:
            logger.info("Layer router mounting disabled")
            return 0

        layers = self.load_config()
        mounted_count = 0

        # Sort by layer number to ensure proper dependency order
        sorted_layers = sorted(layers, key=lambda x: x.layer)

        for layer_config in sorted_layers:
            if not layer_config.enabled:
                logger.debug(f"Layer {layer_config.layer} is disabled, skipping")
                continue

            # Check dependencies
            if not self.validate_dependencies(layer_config):
                logger.warning(
                    f"Skipping Layer {layer_config.layer} due to unsatisfied dependencies"
                )
                continue

            # Import and mount router
            router = self.import_router(layer_config)
            if router is None:
                continue

            try:
                app.include_router(
                    router,
                    prefix=layer_config.prefix,
                    tags=layer_config.tags,
                )
                self._mounted_layers.add(layer_config.layer)
                mounted_count += 1
                logger.info(
                    f"Mounted Layer {layer_config.layer} at "
                    f"{layer_config.prefix} with tags {layer_config.tags}"
                )
            except Exception as e:
                logger.error(f"Failed to mount Layer {layer_config.layer}: {e}")

        logger.info(f"Layer mounting complete: {mounted_count} layers mounted")
        return mounted_count

    def get_mounted_layers(self) -> set[int]:
        """Get the set of currently mounted layer numbers."""
        return self._mounted_layers.copy()

    def is_layer_mounted(self, layer: int) -> bool:
        """Check if a specific layer is mounted."""
        return layer in self._mounted_layers


# Global layer router manager instance
layer_manager = LayerRouterManager()


def mount_layer_routers(app: FastAPI) -> int:
    """
    Convenience function to mount all layer routers.

    Args:
        app: The FastAPI application instance.

    Returns:
        Number of successfully mounted layers.
    """
    return layer_manager.mount_layers(app)
