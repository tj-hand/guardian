"""
Manifast - Layer 0 Backend
FastAPI boundary that receives, validates, and routes requests to backend services.
"""

__version__ = "0.1.0"
