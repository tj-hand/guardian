"""
Services Package
Business logic layer - handles complex operations and orchestrates data flow.
"""
