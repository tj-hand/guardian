"""
Manifast - Layer 0 Backend
FastAPI Application Entry Point

This is the core infrastructure layer that receives, validates,
and routes requests from the Bolt API Gateway to backend services.
"""

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi

from app.core.config import settings
from app.core.database import close_database, init_database
from app.middleware.gateway_validation import GatewayValidationMiddleware
from app.routers import health_router, mount_layer_routers

# OpenAPI Tags for grouping endpoints
OPENAPI_TAGS = [
    {
        "name": "Health",
        "description": "Health check endpoints for monitoring and container orchestration. "
        "These endpoints bypass Bolt Gateway validation for direct access.",
    },
    {
        "name": "Layers",
        "description": "Dynamic layer router endpoints. Routes requests to backend service layers (1-5).",
    },
]

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper()),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan handler.

    Manages startup and shutdown events for the application.
    Use this for database connections, cache initialization, etc.
    """
    # Startup
    logger.info(f"Starting {settings.app_name} v{settings.app_version}")
    logger.info(f"Environment: {settings.environment}")
    logger.info(f"Debug mode: {settings.debug}")

    # Initialize database connection
    await init_database()

    yield

    # Shutdown
    logger.info(f"Shutting down {settings.app_name}")

    # Close database connections
    await close_database()


def custom_openapi(app: FastAPI) -> dict:
    """
    Generate custom OpenAPI schema with enhanced documentation.
    """
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=settings.app_name,
        version=settings.app_version,
        description="""
## Manifast - Layer 0 Backend API

Manifast is the core infrastructure layer (Layer 0) of the backend architecture.
It serves as the FastAPI boundary that receives, validates, and routes requests
from the Bolt API Gateway to backend services.

### Architecture

```
Bolt API Gateway → Manifast (Layer 0) → Layer 1-5 Services
```

### Security

Security is enforced at the network level. Manifast is only accessible via
the internal Docker network, where the Bolt API Gateway is the only service
with access.

### Health Checks

Health endpoints (`/health`, `/health/live`, `/health/ready`) are accessible
for container orchestrators (Kubernetes, Docker).

### Error Handling

All errors follow a consistent format:

```json
{
  "success": false,
  "code": "ERROR_CODE",
  "detail": "Human-readable message",
  "timestamp": "2025-11-25T12:00:00Z"
}
```
        """,
        routes=app.routes,
        tags=OPENAPI_TAGS,
    )

    # Add security scheme documentation
    openapi_schema["info"]["contact"] = {
        "name": "Manifast API Support",
        "url": "https://github.com/tj-hand/manifast",
    }
    openapi_schema["info"]["license"] = {
        "name": "MIT",
        "url": "https://opensource.org/licenses/MIT",
    }

    # Add server information
    openapi_schema["servers"] = [
        {
            "url": "http://localhost:8000",
            "description": "Development server",
        },
    ]

    app.openapi_schema = openapi_schema
    return app.openapi_schema


def create_application() -> FastAPI:
    """
    Application factory.

    Creates and configures the FastAPI application instance.
    """
    app = FastAPI(
        title=settings.app_name,
        description="Layer 0 Backend - FastAPI boundary that receives, validates, and routes requests from Bolt API Gateway.",
        version=settings.app_version,
        docs_url=f"{settings.api_prefix}/docs" if settings.debug else None,
        redoc_url=f"{settings.api_prefix}/redoc" if settings.debug else None,
        openapi_url=f"{settings.api_prefix}/openapi.json" if settings.debug else None,
        openapi_tags=OPENAPI_TAGS,
        lifespan=lifespan,
    )

    # Set custom OpenAPI schema generator
    app.openapi = lambda: custom_openapi(app)

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=settings.cors_allow_credentials,
        allow_methods=settings.cors_methods_list,
        allow_headers=settings.cors_headers_list,
    )

    # Gateway validation middleware (defense-in-depth)
    # Validates that requests are routed through Bolt Gateway
    # Can be disabled via BOLT_GATEWAY_ENABLED=false for development
    app.add_middleware(GatewayValidationMiddleware)
    logger.info(f"Gateway validation: {'enabled' if settings.bolt_gateway_enabled else 'disabled'}")

    # Register routers
    # Health check endpoints (no prefix - direct access for orchestration)
    app.include_router(health_router)

    # Mount dynamic layer routers (Layers 1-5)
    # Each layer can be configured via LAYER_ROUTER_CONFIG environment variable
    mounted_count = mount_layer_routers(app)
    logger.info(f"Layer routers mounted: {mounted_count}")

    return app


# Create application instance
app = create_application()


@app.get(
    "/",
    summary="API Root",
    description="""
Returns basic application information and status.

This endpoint provides a quick overview of the API service including:
- Application name and version
- Layer designation
- Operational status
    """,
    tags=["Health"],
    responses={
        200: {
            "description": "Application information",
            "content": {
                "application/json": {
                    "example": {
                        "name": "Manifast",
                        "version": "0.1.0",
                        "layer": "Layer 0 - Core Infrastructure",
                        "status": "operational",
                    }
                }
            },
        }
    },
)
async def root() -> dict:
    """
    Root endpoint.

    Returns basic application information.
    """
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "layer": "Layer 0 - Core Infrastructure",
        "status": "operational",
    }


@app.get(
    f"{settings.api_prefix}/",
    summary="API Gateway Root",
    description="""
Gateway-accessible API root endpoint.

This endpoint is accessible through Bolt Gateway at /api/ and provides:
- Service identification
- Version information
- Documentation links (when enabled)
- API navigation
    """,
    tags=["Health"],
    responses={
        200: {
            "description": "API information and navigation",
            "content": {
                "application/json": {
                    "example": {
                        "service": "manifast",
                        "version": "0.1.0",
                        "status": "operational",
                        "docs": "/api/docs",
                        "openapi": "/api/openapi.json",
                    }
                }
            },
        }
    },
)
async def api_root() -> dict:
    """
    API root endpoint for gateway access.

    Returns service info and documentation links.
    """
    response = {
        "service": settings.app_name.lower(),
        "version": settings.app_version,
        "status": "operational",
    }

    # Include doc links only when docs are enabled
    if settings.debug:
        response["docs"] = f"{settings.api_prefix}/docs"
        response["openapi"] = f"{settings.api_prefix}/openapi.json"

    return response
