"""
Tests for Security Utilities

Tests the user context extraction from gateway-forwarded headers.
"""


class TestGetCurrentUserFromToken:
    """Tests for user extraction from gateway-forwarded headers."""

    def test_extract_user_with_all_headers(self):
        """Should extract user info when all headers present."""
        from unittest.mock import MagicMock

        from app.core.security import get_current_user_from_token

        request = MagicMock()
        request.headers = {
            "X-User-ID": "user-123",
            "X-User-Email": "test@example.com",
            "X-User-Roles": "admin, user",
        }

        user = get_current_user_from_token(request)

        assert user is not None
        assert user["id"] == "user-123"
        assert user["email"] == "test@example.com"
        assert user["roles"] == ["admin", "user"]

    def test_extract_user_without_user_id(self):
        """Should return None when user ID is missing."""
        from unittest.mock import MagicMock

        from app.core.security import get_current_user_from_token

        request = MagicMock()
        request.headers = {
            "X-User-Email": "test@example.com",
        }

        user = get_current_user_from_token(request)
        assert user is None

    def test_extract_user_empty_roles(self):
        """Should handle empty roles gracefully."""
        from unittest.mock import MagicMock

        from app.core.security import get_current_user_from_token

        request = MagicMock()
        request.headers = {
            "X-User-ID": "user-123",
            "X-User-Email": "test@example.com",
            "X-User-Roles": "",
        }

        user = get_current_user_from_token(request)

        assert user is not None
        assert user["roles"] == []

    def test_extract_user_without_email(self):
        """Should handle missing email gracefully."""
        from unittest.mock import MagicMock

        from app.core.security import get_current_user_from_token

        request = MagicMock()
        request.headers = {
            "X-User-ID": "user-456",
            "X-User-Roles": "viewer",
        }

        user = get_current_user_from_token(request)

        assert user is not None
        assert user["id"] == "user-456"
        assert user["email"] is None
        assert user["roles"] == ["viewer"]
