"""
Tests for Gateway Validation Middleware

Tests the defense-in-depth gateway validation that ensures requests
are routed through Bolt Gateway.
"""

import os
from unittest.mock import AsyncMock, patch

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient


@pytest_asyncio.fixture
async def app_with_gateway_enabled():
    """Create app with gateway validation enabled."""
    # Set up environment before importing
    os.environ["BOLT_GATEWAY_ENABLED"] = "true"
    os.environ["BOLT_GATEWAY_SECRET"] = ""

    from app.core.config import get_settings

    get_settings.cache_clear()

    with (
        patch("app.main.init_database", new_callable=AsyncMock),
        patch("app.main.close_database", new_callable=AsyncMock),
        patch("app.middleware.gateway_validation.settings.bolt_gateway_enabled", True),
        patch("app.middleware.gateway_validation.settings.bolt_gateway_secret", ""),
    ):
        from app.main import create_application

        app = create_application()
        yield app

    # Reset environment
    os.environ["BOLT_GATEWAY_ENABLED"] = "false"
    get_settings.cache_clear()


@pytest_asyncio.fixture
async def app_with_gateway_and_secret():
    """Create app with gateway validation and secret enabled."""
    os.environ["BOLT_GATEWAY_ENABLED"] = "true"
    os.environ["BOLT_GATEWAY_SECRET"] = "test-secret-123"

    from app.core.config import get_settings

    get_settings.cache_clear()

    with (
        patch("app.main.init_database", new_callable=AsyncMock),
        patch("app.main.close_database", new_callable=AsyncMock),
        patch("app.middleware.gateway_validation.settings.bolt_gateway_enabled", True),
        patch("app.middleware.gateway_validation.settings.bolt_gateway_secret", "test-secret-123"),
    ):
        from app.main import create_application

        app = create_application()
        yield app

    # Reset environment
    os.environ["BOLT_GATEWAY_ENABLED"] = "false"
    os.environ["BOLT_GATEWAY_SECRET"] = ""
    get_settings.cache_clear()


@pytest_asyncio.fixture
async def client_gateway_enabled(app_with_gateway_enabled) -> AsyncClient:
    """Client for testing with gateway validation enabled."""
    transport = ASGITransport(app=app_with_gateway_enabled)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


@pytest_asyncio.fixture
async def client_gateway_with_secret(app_with_gateway_and_secret) -> AsyncClient:
    """Client for testing with gateway validation and secret enabled."""
    transport = ASGITransport(app=app_with_gateway_and_secret)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac


class TestGatewayValidationEnabled:
    """Tests when gateway validation is enabled."""

    @pytest.mark.asyncio
    async def test_request_without_header_returns_403(self, client_gateway_enabled: AsyncClient):
        """Requests without gateway header should be blocked."""
        response = await client_gateway_enabled.get("/api/test")
        assert response.status_code == 403
        data = response.json()
        assert data["error"] == "Direct access forbidden"

    @pytest.mark.asyncio
    async def test_request_with_valid_header_passes_through(
        self, client_gateway_enabled: AsyncClient
    ):
        """Requests with valid gateway header should pass middleware."""
        # Test a non-exempt path - with valid header, middleware passes
        # through and we get 404 (endpoint doesn't exist) instead of 403
        response = await client_gateway_enabled.get(
            "/api/test", headers={"X-Forwarded-By": "bolt-gateway"}
        )
        # 404 means the middleware allowed it through
        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_request_with_wrong_header_value_returns_403(
        self, client_gateway_enabled: AsyncClient
    ):
        """Requests with wrong gateway header value should be blocked."""
        response = await client_gateway_enabled.get(
            "/api/test", headers={"X-Forwarded-By": "wrong-value"}
        )
        assert response.status_code == 403
        data = response.json()
        assert data["error"] == "Direct access forbidden"


class TestHealthEndpointsExempt:
    """Tests that health endpoints are exempt from gateway validation."""

    @pytest.mark.asyncio
    async def test_health_endpoint_without_header(self, client_gateway_enabled: AsyncClient):
        """Health endpoint should work without gateway header."""
        response = await client_gateway_enabled.get("/health")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_health_live_without_header(self, client_gateway_enabled: AsyncClient):
        """Liveness probe should work without gateway header."""
        response = await client_gateway_enabled.get("/health/live")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_health_ready_without_header(self, client_gateway_enabled: AsyncClient):
        """Readiness probe should work without gateway header."""
        response = await client_gateway_enabled.get("/health/ready")
        assert response.status_code == 200


class TestGatewaySecretValidation:
    """Tests for gateway secret validation."""

    @pytest.mark.asyncio
    async def test_health_endpoint_exempt_from_secret(
        self, client_gateway_with_secret: AsyncClient
    ):
        """Health endpoints should be exempt from secret validation."""
        response = await client_gateway_with_secret.get("/health")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_non_exempt_without_secret_returns_403(
        self, client_gateway_with_secret: AsyncClient
    ):
        """Non-exempt endpoints without secret should be blocked."""
        response = await client_gateway_with_secret.get(
            "/api/test", headers={"X-Forwarded-By": "bolt-gateway"}
        )
        assert response.status_code == 403
        data = response.json()
        assert data["error"] == "Invalid gateway credentials"

    @pytest.mark.asyncio
    async def test_request_with_wrong_secret_returns_403(
        self, client_gateway_with_secret: AsyncClient
    ):
        """Requests with wrong secret should be blocked."""
        response = await client_gateway_with_secret.get(
            "/api/test",
            headers={
                "X-Forwarded-By": "bolt-gateway",
                "X-Gateway-Secret": "wrong-secret",
            },
        )
        assert response.status_code == 403
        data = response.json()
        assert data["error"] == "Invalid gateway credentials"

    @pytest.mark.asyncio
    async def test_request_with_valid_secret_passes_through(
        self, client_gateway_with_secret: AsyncClient
    ):
        """Requests with valid secret should pass middleware."""
        # Test against a non-exempt path - with valid header and secret,
        # middleware passes through and we get 404 (endpoint doesn't exist)
        response = await client_gateway_with_secret.get(
            "/api/test",
            headers={
                "X-Forwarded-By": "bolt-gateway",
                "X-Gateway-Secret": "test-secret-123",
            },
        )
        # 404 means the middleware allowed it through
        assert response.status_code == 404


class TestGatewayValidationDisabled:
    """Tests when gateway validation is disabled (using default client from conftest)."""

    @pytest.mark.asyncio
    async def test_request_without_header_succeeds_when_disabled(self, client: AsyncClient):
        """Requests should succeed without header when validation is disabled."""
        response = await client.get("/")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_health_works_when_disabled(self, client: AsyncClient):
        """Health endpoints should work when validation is disabled."""
        response = await client.get("/health")
        assert response.status_code == 200
