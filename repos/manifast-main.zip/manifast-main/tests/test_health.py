"""
Integration Tests for Health Check Endpoints

Tests the /health, /health/live, and /health/ready endpoints.
"""

import pytest
from httpx import AsyncClient


class TestHealthEndpoint:
    """Tests for the main /health endpoint."""

    @pytest.mark.asyncio
    async def test_health_returns_200(self, client: AsyncClient):
        """Health endpoint should return 200 OK."""
        response = await client.get("/health")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_health_contains_required_fields(self, client: AsyncClient):
        """Health response should contain all required fields."""
        response = await client.get("/health")
        data = response.json()

        assert "status" in data
        assert "version" in data
        assert "environment" in data
        assert "timestamp" in data
        assert "uptime_seconds" in data
        assert "components" in data

    @pytest.mark.asyncio
    async def test_health_status_is_healthy(self, client: AsyncClient):
        """Health status should be healthy when all components are up."""
        response = await client.get("/health")
        data = response.json()

        assert data["status"] == "healthy"

    @pytest.mark.asyncio
    async def test_health_environment_is_testing(self, client: AsyncClient):
        """Environment should be set to testing."""
        response = await client.get("/health")
        data = response.json()

        assert data["environment"] == "testing"

    @pytest.mark.asyncio
    async def test_health_components_present(self, client: AsyncClient):
        """Health response should include database and redis components."""
        response = await client.get("/health")
        data = response.json()

        components = data["components"]
        assert "database" in components
        assert "redis" in components

    @pytest.mark.asyncio
    async def test_health_component_structure(self, client: AsyncClient):
        """Each component should have status and message fields."""
        response = await client.get("/health")
        data = response.json()

        for component_name, component in data["components"].items():
            assert "status" in component, f"{component_name} missing status"
            assert "message" in component, f"{component_name} missing message"


class TestLivenessProbe:
    """Tests for the /health/live Kubernetes liveness probe."""

    @pytest.mark.asyncio
    async def test_liveness_returns_200(self, client: AsyncClient):
        """Liveness probe should return 200 OK."""
        response = await client.get("/health/live")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_liveness_returns_alive_status(self, client: AsyncClient):
        """Liveness probe should return status: alive."""
        response = await client.get("/health/live")
        data = response.json()

        assert data["status"] == "alive"

    @pytest.mark.asyncio
    async def test_liveness_is_fast(self, client: AsyncClient):
        """Liveness probe should respond quickly (no dependency checks)."""
        import time

        start = time.time()
        await client.get("/health/live")
        duration = time.time() - start

        # Should respond in under 100ms
        assert duration < 0.1


class TestReadinessProbe:
    """Tests for the /health/ready Kubernetes readiness probe."""

    @pytest.mark.asyncio
    async def test_readiness_returns_200_when_ready(self, client: AsyncClient):
        """Readiness probe should return 200 when dependencies are healthy."""
        response = await client.get("/health/ready")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_readiness_returns_ready_status(self, client: AsyncClient):
        """Readiness probe should return status: ready."""
        response = await client.get("/health/ready")
        data = response.json()

        assert data["status"] == "ready"


class TestRootEndpoint:
    """Tests for the root / endpoint."""

    @pytest.mark.asyncio
    async def test_root_returns_200(self, client: AsyncClient):
        """Root endpoint should return 200 OK."""
        response = await client.get("/")
        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_root_contains_app_info(self, client: AsyncClient):
        """Root endpoint should return application information."""
        response = await client.get("/")
        data = response.json()

        assert "name" in data
        assert "version" in data
        assert "layer" in data
        assert "status" in data

    @pytest.mark.asyncio
    async def test_root_status_operational(self, client: AsyncClient):
        """Root endpoint should show operational status."""
        response = await client.get("/")
        data = response.json()

        assert data["status"] == "operational"
