"""
Pytest Configuration and Fixtures

Provides async test client, database fixtures, and common test utilities.
"""

import asyncio

# Override settings before importing app
import os
from collections.abc import AsyncGenerator, Generator
from unittest.mock import AsyncMock, patch

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

os.environ["DATABASE_URL"] = ""
os.environ["REDIS_URL"] = ""
os.environ["DEBUG"] = "true"
os.environ["ENVIRONMENT"] = "testing"
# Disable gateway validation for regular tests (tested separately)
os.environ["BOLT_GATEWAY_ENABLED"] = "false"


@pytest.fixture(scope="session")
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    """
    Create an event loop for the test session.

    Required for async tests with pytest-asyncio.
    """
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def app():
    """
    Create a fresh application instance for testing.

    Patches database initialization to avoid real DB connections.
    """
    from app.core.config import get_settings

    # Clear the settings cache to pick up test environment
    get_settings.cache_clear()

    with (
        patch("app.main.init_database", new_callable=AsyncMock),
        patch("app.main.close_database", new_callable=AsyncMock),
    ):
        # Import the actual app which includes the root endpoint
        from app.main import app as main_app

        yield main_app


@pytest_asyncio.fixture
async def client(app) -> AsyncGenerator[AsyncClient, None]:
    """
    Async HTTP client for testing endpoints.

    Uses HTTPX's AsyncClient with ASGITransport for testing FastAPI.
    """
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
