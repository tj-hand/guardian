"""
Manifast Integration Tests
"""
