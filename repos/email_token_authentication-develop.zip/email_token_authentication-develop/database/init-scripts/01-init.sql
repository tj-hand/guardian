-- Database Initialization Script
-- Email Token Authentication System
-- Created: 2025-11-05
--
-- This script performs initial database setup for the PostgreSQL container.
-- It runs automatically when the database container is first created.
--
-- Note: Table creation is handled by Alembic migrations. This script only
-- contains database-level configuration and extensions.

-- Ensure we're using UTF-8 encoding
-- (Usually set by default, but explicitly verify)
SET client_encoding = 'UTF8';

-- Set default timezone to UTC
-- All timestamps in the application use UTC
SET timezone = 'UTC';

-- Enable UUID generation extension (required for UUID primary keys)
-- uuid-ossp provides functions like uuid_generate_v4()
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable pgcrypto extension for cryptographic functions
-- Provides functions for hashing (used for token hashing)
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create a function to automatically update updated_at timestamps
-- This trigger function can be attached to any table with an updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Note: The trigger will be created by Alembic migration if needed
-- For now, the function is available for future use

-- Log successful initialization
DO $$
BEGIN
    RAISE NOTICE 'Database initialization complete';
    RAISE NOTICE 'Extensions enabled: uuid-ossp, pgcrypto';
    RAISE NOTICE 'Timezone set to UTC';
    RAISE NOTICE 'Trigger function created: update_updated_at_column()';
END $$;
