#!/bin/bash
# Development helper script for Email Token Authentication backend

set -e  # Exit on error

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Helper functions
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}→ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Check Python version
check_python() {
    print_info "Checking Python version..."
    if command -v python3.11 &> /dev/null; then
        PYTHON_CMD=python3.11
    elif command -v python3 &> /dev/null; then
        PYTHON_CMD=python3
        version=$(python3 --version | cut -d' ' -f2)
        if [[ ! $version =~ ^3\.11 ]]; then
            print_error "Python 3.11 required, found $version"
            exit 1
        fi
    else
        print_error "Python 3.11 not found"
        exit 1
    fi
    print_success "Python version OK: $($PYTHON_CMD --version)"
}

# Setup virtual environment
setup_venv() {
    print_info "Setting up virtual environment..."
    if [ ! -d "venv" ]; then
        $PYTHON_CMD -m venv venv
        print_success "Virtual environment created"
    else
        print_success "Virtual environment already exists"
    fi
}

# Install dependencies
install_deps() {
    print_info "Installing dependencies..."
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt
    print_success "Dependencies installed"
}

# Setup environment file
setup_env() {
    print_info "Setting up environment file..."
    if [ ! -f ".env" ]; then
        cp .env.example .env
        print_success ".env file created from .env.example"
        print_info "Please edit .env with your configuration"
    else
        print_success ".env file already exists"
    fi
}

# Run database migrations
run_migrations() {
    print_info "Running database migrations..."
    source venv/bin/activate
    alembic upgrade head
    print_success "Database migrations complete"
}

# Run tests
run_tests() {
    print_info "Running tests..."
    source venv/bin/activate
    pytest
    print_success "Tests passed"
}

# Start development server
start_server() {
    print_info "Starting development server..."
    source venv/bin/activate
    print_success "Server starting at http://localhost:8000"
    print_info "API docs: http://localhost:8000/docs"
    print_info "Health check: http://localhost:8000/health"
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
}

# Format code
format_code() {
    print_info "Formatting code..."
    source venv/bin/activate
    black .
    isort .
    print_success "Code formatted"
}

# Lint code
lint_code() {
    print_info "Linting code..."
    source venv/bin/activate
    flake8 app tests
    print_success "Linting passed"
}

# Show help
show_help() {
    cat << EOF
Email Token Authentication - Development Helper

Usage: ./dev.sh [command]

Commands:
    setup       - Complete setup (venv, deps, env, migrations)
    install     - Install dependencies
    migrate     - Run database migrations
    test        - Run tests
    start       - Start development server
    format      - Format code (black + isort)
    lint        - Lint code (flake8)
    clean       - Clean cache files
    help        - Show this help message

Examples:
    ./dev.sh setup      # First time setup
    ./dev.sh start      # Start development server
    ./dev.sh test       # Run tests

EOF
}

# Clean cache files
clean() {
    print_info "Cleaning cache files..."
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name "*.pyc" -delete 2>/dev/null || true
    find . -type d -name ".pytest_cache" -exec rm -rf {} + 2>/dev/null || true
    find . -type d -name "htmlcov" -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name ".coverage" -delete 2>/dev/null || true
    print_success "Cache files cleaned"
}

# Main script
main() {
    case "$1" in
        setup)
            check_python
            setup_venv
            install_deps
            setup_env
            print_success "Setup complete! Edit .env and run: ./dev.sh migrate && ./dev.sh start"
            ;;
        install)
            check_python
            setup_venv
            install_deps
            ;;
        migrate)
            run_migrations
            ;;
        test)
            run_tests
            ;;
        start)
            start_server
            ;;
        format)
            format_code
            ;;
        lint)
            lint_code
            ;;
        clean)
            clean
            ;;
        help|"")
            show_help
            ;;
        *)
            print_error "Unknown command: $1"
            show_help
            exit 1
            ;;
    esac
}

main "$@"
