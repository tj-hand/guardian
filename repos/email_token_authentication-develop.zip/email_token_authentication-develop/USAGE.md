# Email Token Authentication - External Usage Guide

## Overview

This guide explains how to consume the Email Token Authentication system as versioned Docker images from GitHub Container Registry (GHCR). The system provides passwordless authentication using 6-digit email tokens with comprehensive white-label customization capabilities.

## Quick Start

```bash
# Pull the latest stable release
docker pull ghcr.io/tj-hand/email-token-auth-frontend:v0.1.0
docker pull ghcr.io/tj-hand/email-token-auth-backend:v0.1.0

# Or use latest tag (not recommended for production)
docker pull ghcr.io/tj-hand/email-token-auth-frontend:latest
docker pull ghcr.io/tj-hand/email-token-auth-backend:latest
```

## Version Management

### Semantic Versioning

This project follows [Semantic Versioning](https://semver.org/):

- **0.x.y** - Pre-production releases (beta/testing)
  - Breaking changes allowed
  - Not recommended for production without thorough testing
  - Current status: **v0.1.0**

- **1.x.y** - Production-ready releases
  - Breaking changes only on MAJOR version bumps
  - Recommended for production use
  - Status: Not yet available

### Version Tags

Each release publishes multiple tags:

```bash
# Specific version (recommended for production)
ghcr.io/tj-hand/email-token-auth-frontend:v0.1.0

# Major.Minor version (auto-updates patch versions)
ghcr.io/tj-hand/email-token-auth-frontend:v0.1

# Major version only (auto-updates minor and patch)
ghcr.io/tj-hand/email-token-auth-frontend:v0

# Latest (always points to newest release)
ghcr.io/tj-hand/email-token-auth-frontend:latest

# Branch-based tags (development)
ghcr.io/tj-hand/email-token-auth-frontend:develop
ghcr.io/tj-hand/email-token-auth-frontend:main
```

### Recommended Version Strategy

**Production:**
```yaml
# Lock to specific version for stability
services:
  frontend:
    image: ghcr.io/tj-hand/email-token-auth-frontend:v0.1.0
```

**Staging/Testing:**
```yaml
# Use minor version tag to get patch updates
services:
  frontend:
    image: ghcr.io/tj-hand/email-token-auth-frontend:v0.1
```

**Development:**
```yaml
# Use latest or branch tags
services:
  frontend:
    image: ghcr.io/tj-hand/email-token-auth-frontend:develop
```

## Integration Example

See [`docker-compose.external.yml`](docker-compose.external.yml) for a complete example. Here's a minimal setup:

```yaml
version: '3.8'

services:
  auth-backend:
    image: ghcr.io/tj-hand/email-token-auth-backend:v0.1.0
    environment:
      # Application
      - APP_NAME=My Custom App
      - SECRET_KEY=${SECRET_KEY}

      # Database
      - POSTGRES_HOST=postgres
      - POSTGRES_USER=${DB_USER}
      - POSTGRES_PASSWORD=${DB_PASSWORD}
      - POSTGRES_DB=auth_db

      # Email (Mailgun)
      - MAILGUN_API_KEY=${MAILGUN_API_KEY}
      - MAILGUN_DOMAIN=${MAILGUN_DOMAIN}
      - MAILGUN_FROM_EMAIL=noreply@myapp.com

      # CORS
      - ALLOWED_ORIGINS=https://myapp.com
    ports:
      - "8000:8000"
    depends_on:
      - postgres

  auth-frontend:
    image: ghcr.io/tj-hand/email-token-auth-frontend:v0.1.0
    environment:
      # API
      - VITE_API_BASE_URL=https://api.myapp.com

      # Branding
      - VITE_APP_NAME=My Custom App
      - VITE_BRAND_PRIMARY_COLOR=#ff6600
      - VITE_BRAND_LOGO_URL=/assets/logo.png
    ports:
      - "80:80"

  postgres:
    image: postgres:16
    environment:
      - POSTGRES_USER=${DB_USER}
      - POSTGRES_PASSWORD=${DB_PASSWORD}
      - POSTGRES_DB=auth_db
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

## Configuration Reference

### Backend Environment Variables

#### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `SECRET_KEY` | JWT signing key (generate with `openssl rand -hex 32`) | `a1b2c3d4...` |
| `POSTGRES_HOST` | Database hostname | `postgres` |
| `POSTGRES_USER` | Database username | `authuser` |
| `POSTGRES_PASSWORD` | Database password | `secure_password_123` |
| `POSTGRES_DB` | Database name | `auth_db` |
| `MAILGUN_API_KEY` | Mailgun API key for sending emails | `key-abc123...` |
| `MAILGUN_DOMAIN` | Mailgun domain | `mg.myapp.com` |

#### Optional Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `APP_NAME` | `Email Token Auth` | Application name |
| `APP_ENV` | `development` | Environment: `development`, `staging`, `production` |
| `TOKEN_EXPIRY_MINUTES` | `2` | Token validity period (1-60 minutes) |
| `TOKEN_LENGTH` | `6` | Token length in digits (4-8) |
| `SESSION_EXPIRY_DAYS` | `7` | Session duration (1-30 days) |
| `POSTGRES_PORT` | `5432` | Database port |
| `MAILGUN_FROM_EMAIL` | `noreply@example.com` | From email address |
| `MAILGUN_FROM_NAME` | `Email Token Auth` | From name in emails |
| `ALLOWED_ORIGINS` | `http://localhost:5173` | Comma-separated CORS origins |
| `RATE_LIMIT_REQUESTS` | `3` | Max token requests per email |
| `RATE_LIMIT_WINDOW_MINUTES` | `15` | Rate limit time window |
| `ENABLE_EMAIL_WHITELIST` | `true` | Require users to exist in DB before login |
| `API_V1_PREFIX` | `/v1` | API route prefix |
| `COMPANY_NAME` | `Email Token Auth` | Company name for branding |
| `SUPPORT_EMAIL` | `support@example.com` | Support contact email |
| `BRAND_PRIMARY_COLOR` | `#007bff` | Primary brand color (hex) |
| `EMAIL_TEMPLATE_PATH` | `app/templates/email` | Email template directory |

### Frontend Environment Variables

#### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `VITE_API_BASE_URL` | Backend API URL | `https://api.myapp.com` |

#### Optional Variables (White-Label Customization)

| Variable | Default | Description |
|----------|---------|-------------|
| `VITE_APP_NAME` | `Email Token Auth` | Application name |
| `VITE_COMPANY_NAME` | `My Company` | Company name |
| `VITE_APP_TAGLINE` | `Secure passwordless authentication` | Application tagline |
| `VITE_BRAND_LOGO_URL` | `/logo.svg` | Logo image URL |
| `VITE_BRAND_FAVICON_URL` | `/favicon.ico` | Favicon URL |
| `VITE_BRAND_PRIMARY_COLOR` | `#007bff` | Primary brand color (hex) |
| `VITE_BRAND_SECONDARY_COLOR` | `#6c757d` | Secondary color |
| `VITE_BRAND_ACCENT_COLOR` | `#28a745` | Accent color |
| `VITE_BRAND_SUCCESS_COLOR` | `#28a745` | Success state color |
| `VITE_BRAND_ERROR_COLOR` | `#dc3545` | Error state color |
| `VITE_BRAND_WARNING_COLOR` | `#ffc107` | Warning state color |
| `VITE_BRAND_FONT_FAMILY` | System fonts | Body font family (CSS) |
| `VITE_BRAND_HEADING_FONT_FAMILY` | `inherit` | Heading font family |
| `VITE_SUPPORT_EMAIL` | `support@example.com` | Support email |
| `VITE_SUPPORT_URL` | (empty) | Support page URL |
| `VITE_TWITTER_URL` | (empty) | Twitter profile URL |
| `VITE_LINKEDIN_URL` | (empty) | LinkedIn profile URL |
| `VITE_GITHUB_URL` | (empty) | GitHub profile URL |
| `VITE_FOOTER_TEXT` | (empty) | Custom footer text |
| `VITE_SHOW_POWERED_BY` | `true` | Show "Powered by" attribution |
| `VITE_TOKEN_LENGTH` | `6` | Expected token length (must match backend) |

## White-Label Customization

### Basic Branding

Customize the look and feel using environment variables:

```yaml
environment:
  # Identity
  - VITE_APP_NAME=Acme Authentication
  - VITE_COMPANY_NAME=Acme Corporation
  - VITE_APP_TAGLINE=Secure access for Acme products

  # Colors
  - VITE_BRAND_PRIMARY_COLOR=#ff5722
  - VITE_BRAND_SECONDARY_COLOR=#424242
  - VITE_BRAND_ACCENT_COLOR=#4caf50

  # Assets
  - VITE_BRAND_LOGO_URL=https://cdn.acme.com/logo.svg
  - VITE_BRAND_FAVICON_URL=https://cdn.acme.com/favicon.ico

  # Contact
  - VITE_SUPPORT_EMAIL=support@acme.com
  - VITE_SUPPORT_URL=https://help.acme.com
```

### Custom Assets

To use custom logos and favicons:

1. **Host externally:**
   ```yaml
   - VITE_BRAND_LOGO_URL=https://cdn.mycompany.com/logo.png
   ```

2. **Mount as volume:**
   ```yaml
   volumes:
     - ./branding/logo.png:/usr/share/nginx/html/assets/logo.png:ro
   environment:
     - VITE_BRAND_LOGO_URL=/assets/logo.png
   ```

### Email Customization

Customize email templates (backend):

```yaml
environment:
  # Email branding
  - COMPANY_NAME=Acme Corporation
  - MAILGUN_FROM_NAME=Acme Security
  - MAILGUN_FROM_EMAIL=security@acme.com
  - BRAND_PRIMARY_COLOR=#ff5722
  - SUPPORT_EMAIL=support@acme.com
```

## Security Considerations

### Production Checklist

- [ ] **Secrets Management**
  - Use strong `SECRET_KEY` (32+ bytes, cryptographically random)
  - Store secrets in environment variables or secret management system
  - Rotate secrets regularly
  - Never commit secrets to version control

- [ ] **Database Security**
  - Use strong database password (20+ characters)
  - Restrict database access to backend only
  - Enable SSL/TLS for database connections
  - Regular backups with encryption

- [ ] **Email Configuration**
  - Configure valid Mailgun credentials
  - Use dedicated sending domain
  - Monitor email delivery and bounce rates
  - Implement SPF, DKIM, and DMARC records

- [ ] **Network Security**
  - Use HTTPS only (no HTTP)
  - Configure proper CORS origins
  - Use reverse proxy (Nginx, Traefik, etc.)
  - Enable rate limiting at gateway level

- [ ] **Access Control**
  - Enable email whitelist (`ENABLE_EMAIL_WHITELIST=true`)
  - Manually approve new users
  - Monitor authentication logs
  - Set appropriate token expiry (2-5 minutes recommended)

- [ ] **Container Security**
  - Pull specific version tags (not `latest`)
  - Scan images for vulnerabilities (Trivy reports available)
  - Run containers as non-root user (already configured)
  - Keep images updated with security patches

## Deployment Patterns

### Development Environment

```yaml
services:
  auth-backend:
    image: ghcr.io/tj-hand/email-token-auth-backend:develop
    environment:
      - APP_ENV=development
      - MAILGUN_API_KEY=  # Leave empty for console logging
      - ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000
```

### Staging Environment

```yaml
services:
  auth-backend:
    image: ghcr.io/tj-hand/email-token-auth-backend:v0.1
    environment:
      - APP_ENV=staging
      - SECRET_KEY=${STAGING_SECRET_KEY}
      - MAILGUN_API_KEY=${STAGING_MAILGUN_KEY}
      - ALLOWED_ORIGINS=https://staging.myapp.com
```

### Production Environment

```yaml
services:
  auth-backend:
    image: ghcr.io/tj-hand/email-token-auth-backend:v0.1.0  # Lock to specific version
    environment:
      - APP_ENV=production
      - SECRET_KEY=${PROD_SECRET_KEY}
      - MAILGUN_API_KEY=${PROD_MAILGUN_KEY}
      - ALLOWED_ORIGINS=https://myapp.com
      - ENABLE_EMAIL_WHITELIST=true
      - TOKEN_EXPIRY_MINUTES=2
    restart: unless-stopped
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '1'
          memory: 512M
```

## Database Initialization

The backend automatically handles database migrations on startup. For the first deployment:

1. **With Email Whitelist Disabled** (open registration):
   ```yaml
   environment:
     - ENABLE_EMAIL_WHITELIST=false
   ```
   Users are created automatically on first token request.

2. **With Email Whitelist Enabled** (secure mode):
   ```yaml
   environment:
     - ENABLE_EMAIL_WHITELIST=true
   ```
   Manually add users to database:
   ```sql
   INSERT INTO users (id, email, is_active, created_at, updated_at)
   VALUES (gen_random_uuid(), 'admin@example.com', true, now(), now());
   ```

## Monitoring and Troubleshooting

### Health Checks

**Backend:**
```bash
curl http://localhost:8000/health
# Response: {"status": "healthy", "version": "v0.1.0"}
```

**Frontend:**
```bash
curl http://localhost:80/
# Response: HTML content
```

### Common Issues

#### 1. Authentication Fails

**Symptoms:** Token validation fails, users can't log in

**Checks:**
- Verify `MAILGUN_API_KEY` is set and valid
- Check backend logs for email sending errors
- Confirm `TOKEN_EXPIRY_MINUTES` hasn't expired
- Verify `ENABLE_EMAIL_WHITELIST` setting matches user expectations

```bash
docker logs auth-backend | grep -i "email\|token\|error"
```

#### 2. CORS Errors

**Symptoms:** Browser console shows CORS policy errors

**Solution:**
```yaml
environment:
  - ALLOWED_ORIGINS=https://frontend.com,https://app.frontend.com
```

#### 3. Database Connection Fails

**Symptoms:** Backend can't connect to database

**Checks:**
- Verify `POSTGRES_HOST` matches database service name
- Confirm database is running and accessible
- Check credentials match database configuration

```bash
docker logs auth-backend | grep -i "database\|postgres\|connection"
```

#### 4. Images Won't Pull

**Symptoms:** `docker pull` fails with authentication error

**Solution:**
```bash
# Login to GitHub Container Registry
echo $GITHUB_TOKEN | docker login ghcr.io -u USERNAME --password-stdin

# Or use personal access token with read:packages scope
```

### Viewing Logs

```bash
# Backend logs
docker logs -f auth-backend

# Frontend logs (Nginx access logs)
docker logs -f auth-frontend

# Database logs
docker logs -f postgres
```

## Migration Guide

### From Development Setup to Production

1. **Export current configuration:**
   ```bash
   docker inspect auth-backend --format='{{range $k, $v := .Config.Env}}{{println $v}}{{end}}'
   ```

2. **Update image references:**
   ```yaml
   # Old (local build)
   build: ./backend

   # New (versioned image)
   image: ghcr.io/tj-hand/email-token-auth-backend:v0.1.0
   ```

3. **Migrate environment variables to secure storage**

4. **Test in staging environment first**

5. **Deploy to production with locked version**

### Updating to New Versions

```bash
# Check current version
docker inspect auth-backend --format='{{.Config.Image}}'

# Pull new version
docker pull ghcr.io/tj-hand/email-token-auth-backend:v0.2.0

# Update docker-compose.yml
# Stop and recreate containers
docker-compose up -d auth-backend

# Verify health
curl http://localhost:8000/health
```

## Architecture Overview

```
┌─────────────┐      ┌──────────────┐      ┌─────────────┐
│   Client    │─────▶│   Frontend   │─────▶│   Gateway   │
│  (Browser)  │◀─────│  (Nginx/Vue) │◀─────│   (Nginx)   │
└─────────────┘      └──────────────┘      └─────────────┘
                                                    │
                                                    ▼
                                            ┌─────────────┐
                                            │   Backend   │
                                            │  (FastAPI)  │
                                            └─────────────┘
                                                    │
                                    ┌───────────────┼───────────────┐
                                    ▼               ▼               ▼
                              ┌──────────┐   ┌──────────┐   ┌──────────┐
                              │PostgreSQL│   │ Mailgun  │   │  Redis   │
                              │ Database │   │  Email   │   │  (opt.)  │
                              └──────────┘   └──────────┘   └──────────┘
```

## Support and Contributing

### Getting Help

- **Documentation:** See [README.md](README.md) for project overview
- **Issues:** [GitHub Issues](https://github.com/tj-hand/email_token_authentication/issues)
- **Security:** Report vulnerabilities privately to security@example.com

### Contributing

This project follows the nginx_api_gateway model:
- Core system is maintained in this repository
- External consumers use versioned Docker images
- Contributions welcome via pull requests
- Breaking changes only on major version bumps (after v1.0.0)

## License

Copyright 2024. All rights reserved.

## Changelog

### v0.1.0 (2024-11-10)

**Initial beta release**

Features:
- 6-digit email token authentication
- Mailgun email integration
- PostgreSQL database
- Comprehensive white-label customization
- Docker images published to GHCR
- Development and production multi-stage builds
- Email whitelist support
- Rate limiting
- Session management

Known Limitations:
- Pre-production (0.x) version
- Not yet production-tested at scale
- Breaking changes may occur in 0.x releases
- Limited to single-region deployment

---

**Note:** This is a pre-production (v0.x) release. Thoroughly test in your environment before production use. The API and configuration may change before v1.0.0.
