# Email Token Authentication

Passwordless authentication system using 6-digit email tokens with Vue 3 frontend and FastAPI backend.

## Overview

This project implements a secure, passwordless authentication system where users receive a 6-digit numeric code via email (Mailgun) to log in. The system features white-label customization capabilities and follows OAuth 2.0 patterns for future extensibility.

## Using as a Docker Image Dependency

This project is available as versioned Docker images on GitHub Container Registry (GHCR), allowing other projects to consume the authentication system without cloning the repository.

### Quick Start (External Consumption)

```bash
# Pull versioned images
docker pull ghcr.io/tj-hand/email-token-auth-frontend:v0.1.0
docker pull ghcr.io/tj-hand/email-token-auth-backend:v0.1.0

# Or use in docker-compose.yml
services:
  auth-backend:
    image: ghcr.io/tj-hand/email-token-auth-backend:v0.1.0
    environment:
      - SECRET_KEY=${SECRET_KEY}
      - POSTGRES_HOST=postgres
      # ... other config
```

### Documentation for External Users

- **[USAGE.md](USAGE.md)** - Complete guide for consuming these Docker images
  - Version management and semantic versioning
  - Complete environment variable reference
  - Integration examples and best practices
  - Production deployment checklist
  - Troubleshooting guide

- **[docker-compose.external.yml](docker-compose.external.yml)** - Reference implementation
  - Production-ready docker-compose example
  - All configuration options documented
  - Optional services (Redis, API Gateway)
  - Security and resource management

### Current Version

**v0.1.0** - Pre-production beta release

This is a 0.x version, meaning:
- Not yet production-tested at scale
- Breaking changes may occur before v1.0.0
- Recommended for testing and staging environments
- Thoroughly test in your environment before production use

See [VERSION](VERSION) file and [USAGE.md](USAGE.md) for version management details.

### Key Features for External Consumers

- Comprehensive white-label customization via environment variables
- No code changes required - fully configurable
- Multi-stage Docker builds (development and production targets)
- Security scanning with Trivy (SARIF reports available)
- Follows nginx_api_gateway pattern for consistency
- Semantic versioning for predictable updates

## Architecture

- **Frontend:** Vue 3 + TypeScript + Vite
- **Backend:** FastAPI + Python 3.11
- **Database:** PostgreSQL
- **Gateway:** Nginx API Gateway
- **Email:** Mailgun
- **Container:** Docker Compose

## Features

- 6-digit email token authentication (auto-submit on 6th digit)
- White-label theming and branding
- Secure token generation and validation
- Configurable via environment variables
- Docker containerized development environment

## Quick Start

### Prerequisites

- Docker and Docker Compose
- Git
- Node.js 18+ (for local development)
- Python 3.11 (for local development)

### Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd email_token_authentication
```

2. Copy environment files:
```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

3. Configure environment variables in `.env` files (see Configuration section)

4. Start the development environment:
```bash
docker-compose up -d
```

5. Access the application:
- Frontend: http://localhost:5173
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

## Configuration

### Backend Environment Variables

See `backend/.env.example` for all available configuration options.

Key variables:
- `MAILGUN_API_KEY`: Your Mailgun API key
- `MAILGUN_DOMAIN`: Your Mailgun domain
- `SECRET_KEY`: Application secret key (generate with `openssl rand -hex 32`)
- `POSTGRES_*`: Database connection settings

### Frontend Environment Variables

See `frontend/.env.example` for all available configuration options.

Key variables:
- `VITE_API_BASE_URL`: Backend API URL
- `VITE_APP_NAME`: Application name for white-label
- `VITE_BRAND_PRIMARY_COLOR`: Primary brand color

## Development

### Project Structure

```
email_token_authentication/
├── backend/          # FastAPI application
├── frontend/         # Vue 3 application
├── gateway/          # Nginx API gateway
├── database/         # PostgreSQL initialization
├── docs/             # Documentation
└── docker-compose.yml
```

### Git Flow

This project follows Git Flow:
- `main` - Production-ready code
- `develop` - Integration branch
- `feature/*` - Feature development
- `bugfix/*` - Bug fixes
- `release/*` - Release preparation
- `hotfix/*` - Production hotfixes

### SCRUM Methodology

Development follows SCRUM with 2-week sprints managed via GitHub Issues and Project Boards.

## Testing

### Backend Tests
```bash
cd backend
pytest
```

### Frontend Tests
```bash
cd frontend
npm run test
```

### E2E Tests (Playwright)

End-to-end tests verify the complete authentication flow from user perspective using Playwright.

**Installation:**

```bash
cd frontend

# Install dependencies (if not already installed)
npm install

# Install Playwright browsers
npx playwright install
```

**Running E2E Tests:**

```bash
# Run all E2E tests (headless)
npm run test:e2e

# Run with UI mode (interactive)
npm run test:e2e:ui

# Run in headed mode (see browser)
npm run test:e2e:headed

# Debug specific test
npm run test:e2e:debug

# View HTML report after running tests
npm run test:e2e:report
```

**Test Coverage:**

The E2E test suite covers:

- **Authentication Flow** (`e2e/auth.spec.ts`)
  - Token request and validation
  - 6-digit token input with auto-submit
  - Invalid token error handling
  - Expired token error handling

- **Protected Routes** (`e2e/protected-routes.spec.ts`)
  - Unauthenticated users redirected to login
  - Authenticated users can access dashboard
  - Session persistence across page refresh
  - Logout clears session
  - Expired JWT token handling

- **Rate Limiting** (`e2e/rate-limiting.spec.ts`)
  - Maximum 3 token requests per 15 minutes
  - Rate limit error messages
  - Per-email rate limiting
  - Rate limit window expiry

**Test Structure:**

```
frontend/e2e/
├── auth.spec.ts              # Authentication flow tests
├── protected-routes.spec.ts   # Protected routes and session tests
├── rate-limiting.spec.ts      # Rate limiting tests
└── helpers/
    └── auth-helpers.ts        # Shared test utilities
```

**Test Utilities:**

Common helpers available in `e2e/helpers/auth-helpers.ts`:

- `setAuthenticatedSession()` - Set up authenticated context
- `mockTokenRequest()` - Mock token request API
- `mockTokenValidation()` - Mock token validation API
- `loginWithMockedAPI()` - Complete login flow
- `clearAuth()` - Clear authentication from browser

**Configuration:**

E2E tests are configured in `frontend/playwright.config.ts`:

- Tests run on multiple browsers (Chromium, Firefox, WebKit)
- Mobile viewports tested (Pixel 5, iPhone 12)
- Dev server starts automatically before tests
- Screenshots and videos captured on failure
- Traces collected for debugging

**Running in CI/CD:**

```bash
# CI environment automatically detected
npm run test:e2e

# Playwright will:
# - Run tests serially (not parallel)
# - Retry failed tests 2 times
# - Fail build if test.only found
# - Generate HTML report
```

**Docker Environment:**

To run E2E tests in Docker:

```bash
# Start services
docker-compose up -d

# Run E2E tests from host
cd frontend
npm run test:e2e

# Or run inside frontend container
docker-compose exec frontend npm run test:e2e
```

**Writing New E2E Tests:**

Example test structure:

```typescript
import { test, expect } from '@playwright/test'
import { loginWithMockedAPI, mockTokenRequest } from './helpers/auth-helpers'

test.describe('My Feature', () => {
  test('should do something', async ({ page }) => {
    // Set up mocks
    await mockTokenRequest(page, 'user@example.com')

    // Perform actions
    await page.goto('/')

    // Assert results
    await expect(page.locator('...')).toBeVisible()
  })
})
```

**Troubleshooting:**

- **Tests fail to start:** Run `npx playwright install` to install browsers
- **Port already in use:** Stop dev server running on port 5173
- **Timeout errors:** Increase timeout in `playwright.config.ts`
- **Flaky tests:** Check for race conditions, add explicit waits

## Code Quality & Pre-commit Hooks

This project uses pre-commit hooks to automatically enforce code quality standards before every commit.

### Installation

**Prerequisites:**
- Python 3.11+ installed
- Node.js 18+ installed
- Git installed

**Install pre-commit:**

Option 1 - Using pip (in virtual environment):
```bash
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install pre-commit
```

Option 2 - Using pipx (recommended):
```bash
pipx install pre-commit
```

Option 3 - Using system package manager:
```bash
# Ubuntu/Debian
sudo apt install pre-commit

# macOS
brew install pre-commit
```

**Set up hooks:**
```bash
# Install the git hooks
pre-commit install

# Run hooks on all files (first time)
pre-commit run --all-files
```

### What Gets Checked

**Backend (Python):**
- **Black** - Code formatting (line length: 100)
- **isort** - Import sorting (compatible with Black)
- **flake8** - Code linting (PEP 8 compliance)
- **mypy** - Static type checking

**Frontend (Vue/TypeScript):**
- **ESLint** - JavaScript/TypeScript linting
- **Prettier** - Code formatting
- **TypeScript** - Type checking (vue-tsc)

**General:**
- Trailing whitespace removal
- End-of-file fixing
- YAML syntax validation
- Large file detection (>1MB)
- Merge conflict detection

### Manual Usage

Run hooks manually without committing:
```bash
# Run all hooks on all files
pre-commit run --all-files

# Run specific hook
pre-commit run black --all-files
pre-commit run eslint --all-files

# Run hooks on staged files only
pre-commit run
```

Run individual tools directly:
```bash
# Backend
cd backend
black .
isort .
flake8 .
mypy app/

# Frontend
cd frontend
npm run lint
npm run format
npm run type-check
```

### Bypassing Hooks

In rare cases when you need to bypass hooks (not recommended):
```bash
git commit --no-verify
```

**Note:** Bypassing hooks should only be done when absolutely necessary, as CI/CD pipelines will still run these checks.

### Troubleshooting

**Hook fails to run:**
```bash
# Clear pre-commit cache and reinstall
pre-commit clean
pre-commit install --install-hooks
```

**Type errors in backend:**
```bash
cd backend
mypy app/ --show-error-codes
```

**ESLint errors in frontend:**
```bash
cd frontend
npm run lint -- --debug
```

**Conflicting formatters:**
- Black and Prettier are configured to be compatible
- If you see formatting conflicts, run the formatter manually first

### Configuration Files

- [`.pre-commit-config.yaml`](./.pre-commit-config.yaml) - Pre-commit hook configuration
- [`backend/pyproject.toml`](./backend/pyproject.toml) - Python tool settings (Black, isort, mypy, pytest)
- [`backend/.flake8`](./backend/.flake8) - Flake8 linting rules
- [`frontend/.eslintrc.cjs`](./frontend/.eslintrc.cjs) - ESLint configuration
- [`frontend/.prettierrc`](./frontend/.prettierrc) - Prettier formatting rules

## Deployment

Deployment guide for Azure Container Apps and other platforms available in `docs/DEPLOYMENT.md` (coming soon).

## Documentation

### Core Documentation
- [CLAUDE.md](./CLAUDE.md) - Complete project specification and AI agent guidelines
- [README.md](./README.md) - This file - Quick start and overview

### Technical Documentation
- [docs/INTEGRATION.md](./docs/INTEGRATION.md) - Guide for integrating this auth system into other projects
- [gateway/README.md](./gateway/README.md) - Gateway configuration and version management

### Project Management
- GitHub Issues - Product backlog and issue tracking
- GitHub Project Board - Sprint planning and progress tracking
- Pull Requests - Code review and sprint deliverables

## Authentication & Security

### JWT Session Management

After successful 6-digit token validation, the system issues a JWT (JSON Web Token) for maintaining user sessions.

**JWT Token Lifecycle:**

1. **Token Generation** - Created after successful 6-digit token validation
2. **Token Storage** - Stored in browser localStorage (frontend)
3. **Token Usage** - Included in Authorization header for protected endpoints
4. **Token Expiry** - Configurable duration (default: 7 days)
5. **Token Refresh** - Can be refreshed before expiration using refresh endpoint

**Configuration:**

```bash
# Backend .env
SESSION_EXPIRY_DAYS=7        # JWT token validity (1-30 days)
JWT_ALGORITHM=HS256          # Signing algorithm
SECRET_KEY=<your-secret>     # MUST be secure in production
```

**Token Refresh Mechanism:**

The system implements JWT token rotation for security:

```bash
# Refresh endpoint
POST /api/v1/auth/refresh
Authorization: Bearer <current-jwt-token>

# Response
{
  "access_token": "<new-jwt-token>",
  "token_type": "bearer",
  "expires_in": 604800,
  "user": { ... }
}
```

**Best Practices:**

- Frontend should refresh tokens proactively before expiration
- Old token remains valid until original expiry (no blacklist needed)
- Refresh tokens on user activity for better UX
- Use secure, unique SECRET_KEY per environment

**Example (JavaScript):**

```javascript
// Check if token needs refresh (within 1 day of expiry)
const tokenExpiresAt = new Date(user.token_expiry)
const oneDayFromNow = new Date(Date.now() + 24 * 60 * 60 * 1000)

if (tokenExpiresAt < oneDayFromNow) {
  // Refresh token proactively
  const response = await fetch('/api/v1/auth/refresh', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${currentToken}`
    }
  })
  const { access_token } = await response.json()
  // Store new token
  localStorage.setItem('token', access_token)
}
```

### Configuration for Different Environments

**Development:**
```bash
SESSION_EXPIRY_DAYS=30       # Long sessions for convenience
TOKEN_EXPIRY_MINUTES=60      # Longer 6-digit token validity
RATE_LIMIT_REQUESTS=10       # Relaxed rate limiting
```

**Staging:**
```bash
SESSION_EXPIRY_DAYS=7        # Standard sessions
TOKEN_EXPIRY_MINUTES=15      # Standard token validity
RATE_LIMIT_REQUESTS=3        # Standard rate limiting
```

**Production:**
```bash
SESSION_EXPIRY_DAYS=7        # Secure sessions (or less for high-security)
TOKEN_EXPIRY_MINUTES=10      # Tight token validity
RATE_LIMIT_REQUESTS=3        # Strict rate limiting
SECRET_KEY=<64-char-key>     # Long, secure key
```

### Security Implications by Configuration

**JWT Expiry Time:**

| Duration | Security Level | Use Case | Pros | Cons |
|----------|---------------|----------|------|------|
| 1 day | High | Banking, healthcare | Maximum security | Frequent re-auth |
| 7 days (default) | Medium | Standard apps | Balanced security/UX | Moderate risk |
| 30 days | Low | Internal tools | Best UX | Higher risk if compromised |

**6-Digit Token Expiry:**

| Duration | Security Level | Use Case | Pros | Cons |
|----------|---------------|----------|------|------|
| 5-10 min | High | Production apps | Secure | Users must act quickly |
| 15 min (default) | Medium | Standard apps | Balanced | Moderate window |
| 30-60 min | Low | Development | Convenient | Larger attack window |

**Rate Limiting:**

| Requests | Window | Security Level | Use Case |
|----------|--------|----------------|----------|
| 2 | 10 min | High | Production (strict) |
| 3 (default) | 15 min | Medium | Standard apps |
| 5-10 | 30-60 min | Low | Development/testing |

### Security Features

- **6-Digit Tokens:** Cryptographically secure random generation
- **Token Expiry:** 2 minutes default (configurable 1-60 minutes)
- **One-Time Use:** Tokens invalidated immediately after validation
- **Rate Limiting:** 3 requests per 15 minutes per email (configurable)
- **JWT Sessions:** HS256 signed tokens with configurable expiry (1-30 days)
- **Token Refresh:** Secure token rotation mechanism
- **Email Security:** Security by obscurity (always returns success)
- **HTTPS Enforced:** Production must use HTTPS
- **Secret Key Validation:** Enforced secure keys in production
- **Password Hashing:** bcrypt (for future features)

## White-Label Customization

Customize branding by:
1. Updating environment variables for colors and text
2. Adding logo/favicon to `frontend/src/assets/branding/`
3. Modifying `frontend/src/config/branding.json`
4. Customizing email templates in `backend/app/templates/email/`

## License

[To be determined]

## Contributing

Please read [CONTRIBUTING.md](./CONTRIBUTING.md) for details on our code of conduct and the process for submitting pull requests.

## Support

For issues and questions, please use the GitHub issue tracker.
