# Email Token Authentication Project

## Project Overview
Passwordless authentication system using 6-digit numeric email tokens. Users receive a 6-digit code via email (Mailgun) to access the system without traditional passwords.

## MANDATORY REQUIREMENTS ⚠️

### 🔴 1. MANDATORY: Workflow Management for All Code Changes

**For ALL code changes (features, bugs, refactoring, documentation, configuration, tests):**
- ✅ **MUST use agile-git-workflow agent** (global) - No exceptions
- ✅ Every code change = Issue + Branch + PR workflow via agile-git-workflow
- ✅ Never commit directly to main branch

**NOT required for:**
- ❌ Questions and explanations
- ❌ Read-only codebase exploration
- ❌ Planning discussions without implementation

**How to use:**
- The agile-git-workflow agent handles the complete SCRUM + Git Flow cycle
- Automatically creates issues, branches, commits, and pull requests
- Manages project board updates and sprint tracking

### 2. Gateway Integration Protocol
- **Pull gateway from:** https://github.com/tj-hand/nginx_api_gateway
- **ONLY modify customizable files** - Core gateway files MUST remain intact
- **Suggest improvements:** Document in this project → Implement in gateway repo → Re-pull to this project
- **Gateway documentation:** Must be consulted from the repository before any integration work

### 3. Specialist Agent Usage Protocol
**For EVERY prompt, evaluate if specialist agents can help:**

**Global Agents (from ~/.claude/agents/):**
- **agile-git-workflow** - SCRUM + Git Flow workflow (MANDATORY for all code changes)
- **docker-expert** - Docker, docker-compose, containerization
- **vue3-expert** - Vue.js/Frontend tasks
- **postgres-expert** - Database/PostgreSQL tasks
- **python-expert** - FastAPI/Backend tasks

**Decision tree:**
- If task involves code changes → **MUST use agile-git-workflow first**
- If task involves Docker/containers → **USE docker-expert**
- If task is within project agent expertise → **USE the specialist agent**
- If task is outside all agents' scope → Handle directly
- **Deploy agents in parallel** when tasks are independent

### 4. File Creation Protocol
**System Files vs Documentation Files:**

**System Files (ALWAYS create following best practices):**
- Code files (Python, Vue, TypeScript, etc.)
- Configuration files (Dockerfile, docker-compose.yml, etc.)
- Environment files (.env.example)
- Package management (requirements.txt, package.json)
- Database migrations
- All files necessary for the application to function

**Documentation/Text Files (MINIMIZE):**
- **Avoid:** Multiple separate markdown files, per-feature docs, redundant READMEs
- **Prefer:** All-in-one documentation (single comprehensive file)
- **Keep:** Only essential docs (README.md, CLAUDE.md)

**Project State Management:**
- All project state tracked via Git/GitHub through agile-git-workflow agent
- Issues = Backlog items
- Project Board = Sprint planning and progress
- Branches = Active work
- No separate state tracking files needed

**Rule:** Always create system files using best practices. Minimize documentation files - consolidate when possible.

## Architecture

### System Components (Docker Containers)
1. **Frontend** - Vue 3 with white-label customization layer
2. **Backend** - FastAPI (Python 3.11) with 6-digit email token authentication
3. **Database** - PostgreSQL (latest stable)
4. **Gateway** - Nginx API Gateway (from external repo)

### Tech Stack
- **Frontend:** Vue 3 (latest), Vite, TypeScript
- **Backend:** FastAPI, Python 3.11 (crewai compatibility requirement)
- **Database:** PostgreSQL (latest stable)
- **Gateway:** Nginx
- **Email Service:** Mailgun (configurable via environment variables)
- **Container Orchestration:** Docker Compose (dev), Azure Container Apps (prod)

## Authentication Flow

### User Journey
1. User enters email address on login page
2. Backend generates **6-digit numeric token** (e.g., 123456)
3. Backend sends email with **only the 6 digits** (no clickable links)
4. User enters the 6 digits in frontend input field
5. **Frontend auto-submits** when all 6 digits are entered
6. Backend validates token and creates session
7. User is authenticated

### Technical Requirements
- **Token Format:** 6 numeric digits (000000-999999)
- **Email Content:** Plain text with 6-digit code only (no HTML links)
- **Frontend Input:** Auto-submit on 6th digit entry
- **Token Expiry:** 2 minutes (configurable)
- **One-time use:** Token invalidated after successful validation

**Note:** OAuth 2.0 integration is planned for future when accessing external services.

## White-Label Customization

### Customizable Elements
- **Visual:** Colors, logo, fonts, favicon
- **Content:** Application name, welcome text, email templates
- **Branding:** Custom domains, footer text, links

### Configuration Method
- Environment variables for backend settings
- JSON configuration files for frontend themes
- No multi-tenant support in initial version (single brand per deployment)

### Directory Structure for Customization
```
frontend/
  src/
    config/
      branding.json       # Brand-specific configuration
      theme.json          # Color schemes, fonts
    assets/
      branding/           # Logo, favicon, images (gitignored)
backend/
  app/
    templates/
      email/              # Customizable email templates
    config/
      settings.py         # Environment-based configuration
```

## Development Methodology

### SCRUM & Git Flow (Managed by agile-git-workflow agent)
**All development follows SCRUM methodology with Git Flow branching strategy.**

**The agile-git-workflow agent (global) handles:**
- Sprint planning and management
- Issue creation and tracking
- Branch creation (feature/*, bugfix/*, release/*, hotfix/*)
- Commit workflow with conventional commits
- Pull Request creation and management
- Project board updates (Backlog → Sprint Backlog → In Progress → In Review → Done)
- Sprint ceremonies (planning, review, retrospective)

**Sprint Duration:** 2 weeks

**Branch Strategy:**
- `main` - Production-ready code
- `develop` - Integration branch
- `feature/*` - Feature development
- `bugfix/*` - Bug fixes
- `release/*` - Release preparation
- `hotfix/*` - Production hotfixes

**Note:** Never commit directly or manage Git workflow manually. Always use the agile-git-workflow agent for all code changes.

## Specialist Agents (MANDATORY USAGE)

### Global Agents (from ~/.claude/agents/)
1. **agile-git-workflow** - SCRUM + Git Flow workflow management
   - Issue creation and tracking
   - Branch management (feature/*, bugfix/*, etc.)
   - Commit workflow with conventional commits
   - Pull Request creation and management
   - Project board updates
   - Sprint planning and ceremonies
   - **MANDATORY for ALL code changes**

2. **docker-expert** - Docker containerization and orchestration
   - Dockerfile creation and optimization
   - docker-compose configuration
   - Multi-stage builds
   - Container networking and security
   - Development environment setup
   - Production deployment configurations

3. **vue3-expert** - Frontend Vue.js development
   - Vue component creation
   - Frontend routing and state management
   - UI/UX implementation
   - Frontend testing
   - Auto-submit 6-digit input logic

4. **postgres-expert** - Database design and operations
   - Schema design
   - Migrations
   - Query optimization
   - Database configuration

5. **python-expert** - Backend development
   - FastAPI endpoints
   - Business logic
   - 6-digit token generation and validation
   - Mailgun email integration
   - Backend testing

### Agent Usage Protocol (MANDATORY)
**For EVERY prompt:**
1. **FIRST:** If task involves ANY code changes → Use **agile-git-workflow** (MANDATORY)
2. Analyze if the task involves Docker/containers → Use **docker-expert**
3. Analyze if the task involves Vue/Frontend → Use **vue3-expert**
4. Analyze if the task involves PostgreSQL/Database → Use **postgres-expert**
5. Analyze if the task involves Python/Backend → Use **python-expert**
6. If task spans multiple domains → Use multiple agents in parallel
7. If task is outside all domains → Handle directly

### Agent Deployment Rules
- Use Task tool with `subagent_type` parameter
- Deploy multiple agents in parallel when tasks are independent
- Always announce which agent you're spawning
- Summarize the agent's task before spawning
- Report key findings after agent completes
- List files created/modified by the agent

### Example Agent Usage
```
Task: Implement 6-digit token input with auto-submit

Analysis:
- Code changes required → agile-git-workflow (MANDATORY)
- Frontend component (Vue) → vue3-expert
- Backend validation endpoint → python-expert
- Database token storage → postgres-expert

Action Step 1: Using agile-git-workflow agent to:
- Create issue: "Implement 6-digit token input with auto-submit"
- Create feature branch: feature/token-input-auto-submit
- Set up Git workflow

Action Step 2: Spawning 3 specialist agents in parallel...

[After completion]
Results:
- vue3-expert created: frontend/src/components/TokenInput.vue
- python-expert created: backend/app/api/routes/auth.py
- postgres-expert created: backend/alembic/versions/001_token_table.py

Action Step 3: Using agile-git-workflow agent to:
- Commit changes with conventional commits
- Create Pull Request to develop
- Update project board
```

## Gateway Integration (Versioned Docker Images)

### Architecture
- **Core Gateway:** Versioned Docker image from `ghcr.io/tj-hand/nginx-api-gateway`
- **Source Repository:** https://github.com/tj-hand/nginx_api_gateway (private)
- **Customizations:** Mounted as volumes from `gateway/custom-routes/`
- **Version Management:** Via `.env` environment variables

### Current Setup (✅ IMPLEMENTED)
```yaml
# Gateway uses versioned image (not built locally)
gateway:
  image: ${GATEWAY_IMAGE}:${GATEWAY_VERSION}
  volumes:
    - ./gateway/custom-routes/auth-routes.conf:/etc/nginx/conf.d/custom-routes/auth-routes.conf:ro
```

### Version Management
```bash
# Update gateway version in root .env
GATEWAY_VERSION=v1.2.0

# Pull and restart
docker-compose pull gateway
docker-compose up -d gateway
```

### Customization Protocol
1. **Custom Routes:** Modify `gateway/custom-routes/auth-routes.conf`
2. **Restart:** `docker-compose restart gateway` to apply changes
3. **Core Gateway:** Never modified (managed in external repository)

### Requesting Gateway Improvements
1. **Document** the issue/improvement in this project
2. **Create issue** in gateway repository
3. **Implement** in gateway repository
4. **Update version** in this project after gateway release

**See:** `gateway/README.md` for detailed gateway integration documentation

## Environment Variables

### Backend (FastAPI)
```bash
# Application
APP_NAME=Email Token Auth
APP_ENV=development
SECRET_KEY=<generated>
TOKEN_EXPIRY_MINUTES=15
TOKEN_LENGTH=6

# Database
POSTGRES_HOST=database
POSTGRES_PORT=5432
POSTGRES_USER=<custom>
POSTGRES_PASSWORD=<custom>
POSTGRES_DB=auth_db

# Mailgun
MAILGUN_API_KEY=<custom>
MAILGUN_DOMAIN=<custom>
MAILGUN_FROM_EMAIL=<custom>
MAILGUN_FROM_NAME=<custom>

# CORS
ALLOWED_ORIGINS=http://localhost:5173

# Session
SESSION_EXPIRY_DAYS=7
```

### Frontend (Vue 3)
```bash
# API
VITE_API_BASE_URL=http://localhost/api

# Branding
VITE_APP_NAME=Email Token Auth
VITE_BRAND_PRIMARY_COLOR=#007bff
VITE_BRAND_LOGO_URL=/branding/logo.png

# Auth
VITE_TOKEN_LENGTH=6
```

### Gateway (Nginx)
```bash
# Upstream services
UPSTREAM_FRONTEND=frontend:80
UPSTREAM_BACKEND=backend:8000

# Port
GATEWAY_PORT=80
```

## Project Structure
```
email_token_authentication/
├── .git/
├── .github/
│   └── workflows/           # CI/CD pipelines
├── backend/
│   ├── app/
│   │   ├── api/             # FastAPI routes
│   │   ├── core/            # Configuration, security
│   │   ├── models/          # Database models
│   │   ├── schemas/         # Pydantic schemas
│   │   ├── services/        # Business logic (6-digit token generation)
│   │   ├── templates/       # Email templates (customizable)
│   │   └── main.py          # FastAPI app entry point
│   ├── tests/
│   ├── alembic/             # Database migrations
│   ├── Dockerfile
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── assets/
│   │   │   └── branding/    # Customizable assets (gitignored)
│   │   ├── components/      # Vue components (including 6-digit input)
│   │   ├── views/           # Page views
│   │   ├── router/          # Vue Router
│   │   ├── stores/          # Pinia stores
│   │   ├── config/          # Branding configuration
│   │   ├── composables/     # Vue composables
│   │   └── App.vue
│   ├── public/
│   ├── tests/
│   ├── Dockerfile
│   ├── package.json
│   └── .env.example
├── gateway/                  # To be pulled from external repo
│   ├── nginx.conf           # Core (DO NOT MODIFY)
│   ├── conf.d/              # Customizable configurations
│   └── Dockerfile
├── database/
│   └── init-scripts/        # PostgreSQL initialization
├── docker-compose.yml
├── docker-compose.prod.yml
├── .gitignore
├── README.md
├── CLAUDE.md                # This file
└── docs/
    ├── BACKLOG.md           # Product backlog
    ├── SPRINT.md            # Current sprint details
    └── ARCHITECTURE.md      # Technical architecture
```

## Initial Backlog (High Priority)

### Sprint 1: Foundation & Infrastructure
1. **Project Setup**
   - Initialize Git repository with gitflow
   - Set up Docker Compose
   - Configure development environment
   - Create .env.example files

2. **Database Schema**
   - Design user and token tables (6-digit tokens)
   - Create Alembic migrations
   - Set up PostgreSQL container

3. **Backend Core**
   - FastAPI application scaffold
   - Database connection setup
   - Environment configuration
   - Health check endpoint

4. **Frontend Core**
   - Vue 3 + Vite scaffold
   - Router setup
   - Basic layout structure
   - Environment configuration

### Sprint 2: Authentication Implementation
5. **6-Digit Token Generation (Backend)**
   - Token model (6 numeric digits)
   - Secure token generation service
   - Mailgun integration (plain text email)
   - Token storage in database with expiry

6. **Login Flow (Frontend)**
   - Email input page
   - 6-digit token input component with auto-submit
   - API integration
   - Form validation

7. **Token Validation (Backend)**
   - Token validation endpoint
   - Expiry and one-time use logic
   - Session creation
   - Error handling

8. **Session Management**
   - Session storage (JWT)
   - Protected routes (backend)
   - Auth middleware
   - Logout functionality

### Sprint 3: White-Label & Gateway
9. **White-Label System**
   - Branding configuration loader
   - Theme system (CSS variables)
   - Email template customization
   - Asset management

10. **Gateway Integration (MANDATORY PROTOCOL)**
    - Review gateway repository documentation
    - Identify customizable vs core files
    - Pull nginx_api_gateway repository
    - Configure gateway for services (customizable files only)
    - Update Docker Compose
    - Test end-to-end flow

### Sprint 4: Testing & Documentation
11. **Testing**
    - Backend unit tests (6-digit token generation/validation)
    - Frontend component tests (auto-submit input)
    - Integration tests
    - E2E tests (full auth flow)

12. **Documentation & Deployment**
    - API documentation (OpenAPI)
    - User guide
    - Deployment guide (Azure Container Apps)
    - Environment setup instructions

## Security Considerations
- **Token generation:** Cryptographically secure random 6-digit numbers
- **Token storage:** Hashed in database
- **Rate limiting:** Max 3 token requests per email per 15 minutes
- **Token expiry:** 2 minutes default
- **One-time use:** Token invalidated immediately after validation
- **HTTPS only** in production
- **CORS configuration**
- **SQL injection prevention** (ORM)
- **XSS prevention** (Vue automatic escaping)

## Best Practices

### Code Quality
- Type hints for Python code
- TypeScript for Vue components
- ESLint + Prettier for frontend
- Black + isort for backend
- Pre-commit hooks

### Version Control (MANDATORY)
- **All Git operations handled by agile-git-workflow agent** (global)
- Conventional commits (feat:, fix:, docs:, etc.)
- Reference issue numbers in commits (#123)
- Descriptive PR descriptions
- Code review required for merges
- All work tracked through Git project board
- **Never commit directly** - always use agile-git-workflow agent

### Testing
- Minimum 80% code coverage
- Test critical authentication paths
- Mock external services (Mailgun)
- Test white-label configurations
- Test 6-digit auto-submit behavior

## Deployment Strategy

### Development
- **Docker configuration managed by docker-expert agent** (global)
- Docker Compose with hot-reload
- Local environment variables
- Mock email service (optional)

### Production (Azure Container Apps)
- **Container optimization by docker-expert agent** (global)
- Separate containers for each service
- Managed PostgreSQL database
- Environment variables via Azure Key Vault
- HTTPS with custom domain
- Horizontal scaling enabled

## Future Considerations
- OAuth 2.0 integration for external services
- Multi-tenant support
- Two-factor authentication (optional)
- Social login integration
- User profile management
- Audit logging

## Agent Coordination Role

### Technical Project Manager Responsibilities
As the coordinating agent, you must:
1. **Analyze** every incoming request
2. **Evaluate** which specialist agents can help (MANDATORY step)
3. **ALWAYS check:** Does this involve code changes? → Use agile-git-workflow agent first
4. **ALWAYS check:** Does this involve Docker? → Use docker-expert agent
5. **Break down** into subtasks assigned to specialist agents (vue3-expert, postgres-expert, python-expert)
6. **Deploy** agents in parallel when possible
7. **Synthesize** results from all agents
8. **Maintain** project coherence across sprints

### Execution Transparency (REQUIRED)
When using agents, always:
1. **Announce** which agent is being spawned
2. **Summarize** the agent's specific task
3. **Report** key findings after completion
4. **List** all files created/modified

Example:
```
"Task: Create 6-digit token generation service

Step 1: Using agile-git-workflow agent to set up Git workflow
- Creating issue: 'Implement 6-digit token generation service'
- Creating feature branch: feature/token-generation
- Setting up project board

Step 2: I'm spawning the python-expert agent to implement the service

Task assigned to agent:
- Implement secure 6-digit numeric token generation
- Integrate Mailgun for plain-text email delivery
- Store hashed tokens in database with 15-minute expiry

[Agent execution...]

Agent completed successfully. Created:
- backend/app/services/token_service.py (token generation logic)
- backend/app/services/email_service.py (Mailgun integration)
- backend/tests/test_token_service.py (unit tests)

Step 3: Using agile-git-workflow agent to complete the workflow
- Committing changes with conventional commit message
- Creating Pull Request to develop branch
- Updating project board (In Progress → In Review)
```

## Quick Reference: 6-Digit Token Flow

### Backend
```python
# Generate 6-digit token
token = secrets.randbelow(1000000)  # 000000-999999
token_str = f"{token:06d}"  # Zero-padded

# Email content (plain text, NO links)
email_body = f"""
Your verification code is:

{token_str}

This code expires in 2 minutes.
"""
```

### Frontend
```vue
<!-- 6-digit input with auto-submit -->
<input
  v-model="tokenDigits"
  maxlength="6"
  @input="handleTokenInput"
  pattern="[0-9]*"
  inputmode="numeric"
/>

<script>
const handleTokenInput = () => {
  if (tokenDigits.value.length === 6) {
    // Auto-submit when 6 digits entered
    submitToken(tokenDigits.value)
  }
}
</script>
```

## Notes
- Gateway repository integration is a backlog item (awaiting repo availability)
- Python 3.11 specifically required (crewai compatibility)
- Latest stable versions for all other technologies
- 6-digit tokens provide 1,000,000 combinations with 15-minute expiry
- Auto-submit improves UX by eliminating manual submit button
