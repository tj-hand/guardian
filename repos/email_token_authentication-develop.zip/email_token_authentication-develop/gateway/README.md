# NGINX API Gateway - Versioned Docker Image Integration

## Overview

This directory contains **customizations only** for the NGINX API Gateway. The core gateway functionality is provided via a versioned Docker image from the external repository.

**Gateway Architecture:**
- **Core Gateway**: Pulled as versioned Docker image from `ghcr.io/tj-hand/nginx-api-gateway`
- **Customizations**: Mounted from this directory as volumes (routes, configs)
- **Version Control**: Managed via environment variables in root `.env`

**Integration Status:** ✅ COMPLETE - Gateway is fully configured and operational

## Quick Start

### 1. Configure Gateway Version

Edit the root `.env` file:
```bash
# Gateway Image Configuration
GATEWAY_IMAGE=ghcr.io/tj-hand/nginx-api-gateway
GATEWAY_VERSION=latest  # Or specific version: v1.0.0, v1.1.0, etc.
```

### 2. Start Gateway

```bash
# From project root
docker-compose up gateway
```

The gateway will:
1. Pull the versioned image from the registry
2. Mount custom routes from `./custom-routes/`
3. Apply environment-specific configuration

## Directory Structure

```
gateway/
├── custom-routes/          # Customizable route configurations
│   └── auth-routes.conf   # Email token authentication routes
├── .env                   # Gateway-specific environment variables
├── .env.example           # Environment variable template
└── README.md              # This file
```

## Customization

### Custom Routes

Custom routes are defined in `custom-routes/auth-routes.conf` and mounted into the gateway container as a volume.

**To modify routes:**
1. Edit `custom-routes/auth-routes.conf`
2. Restart gateway: `docker-compose restart gateway`

**Current custom routes:**
- `POST /api/auth/request-token` - Request 6-digit email token
- `POST /api/auth/verify-token` - Verify token and create session
- `POST /api/auth/logout` - Invalidate session
- `GET /api/auth/me` - Get current user info

### Environment Variables

Gateway-specific variables in `gateway/.env`:

```bash
# Backend upstreams
BACKEND_1_HOST=backend
BACKEND_1_PORT=8000

# Frontend URL
FRONTEND_URL=http://localhost:5173

# Upload limits
MAX_UPLOAD_SIZE=10M

# Rate limiting
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=100
```

## Version Management

### Viewing Available Versions

```bash
# List available gateway versions
docker pull ghcr.io/tj-hand/nginx-api-gateway --all-tags

# Or check GitHub Container Registry
# https://github.com/tj-hand/nginx_api_gateway/pkgs/container/nginx-api-gateway
```

### Updating Gateway Version

**Development (latest features):**
```bash
# In root .env
GATEWAY_VERSION=latest
docker-compose pull gateway
docker-compose up -d gateway
```

**Production (pinned version):**
```bash
# In root .env
GATEWAY_VERSION=v1.2.0
docker-compose pull gateway
docker-compose up -d gateway
```

### Rollback

```bash
# Update .env to previous version
GATEWAY_VERSION=v1.1.0

# Pull and restart
docker-compose pull gateway
docker-compose up -d gateway
```

## Gateway Repository

**Source Repository:** https://github.com/tj-hand/nginx_api_gateway

### Requesting Features or Improvements

**DO NOT modify core gateway files in this directory.** Instead:

1. **Document the issue/improvement** in this project
2. **Create an issue** in the gateway repository
3. **Implement in gateway repo** (contribute or request)
4. **Update version** in this project after gateway release

### Gateway Documentation

For comprehensive gateway documentation, see:
- Gateway Repository: https://github.com/tj-hand/nginx_api_gateway
- Gateway README: Core features, configuration options, security
- Gateway Docs: Deployment guides, best practices

## Request Flow Architecture

```text
Frontend (Port 5173)
    ↓
Gateway (Port 8080) ← Health Check (Port 9090)
    ↓
Backend FastAPI (Port 8000)
    ↓
PostgreSQL (Port 5432)
```

**Request Flow:**
1. Frontend makes request to: `http://localhost:8080/api/auth/*`
2. Gateway validates CORS origin
3. Gateway applies rate limiting
4. Gateway routes request to backend based on path
5. Gateway forwards Authorization header (does NOT validate)
6. Backend validates authentication/authorization
7. Backend performs business logic and database operations
8. Backend returns response to Gateway
9. Gateway returns response to Frontend (with CORS headers)

## Testing Custom Routes

```bash
# Health check
curl http://localhost:8080/health

# Request authentication token
curl -X POST http://localhost:8080/api/auth/request-token \
  -H "Content-Type: application/json" \
  -d '{"email": "user@example.com"}'

# Verify token
curl -X POST http://localhost:8080/api/auth/verify-token \
  -H "Content-Type: application/json" \
  -d '{"email": "user@example.com", "token": "123456"}'

# Protected endpoint (requires Authorization header)
curl http://localhost:8080/api/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## Troubleshooting

### Gateway Won't Start

```bash
# Check if image exists
docker pull ghcr.io/tj-hand/nginx-api-gateway:latest

# Verify environment variables
cat .env | grep GATEWAY

# Check logs
docker-compose logs gateway
```

### Custom Routes Not Working

```bash
# Verify mount path
docker inspect email_auth_gateway | grep Mounts -A 10

# Check route file syntax
nginx -t -c gateway/custom-routes/auth-routes.conf

# Restart gateway
docker-compose restart gateway
```

### Version Compatibility

Ensure backend/frontend versions are compatible with gateway version:
```bash
# Check all service versions
cat .env | grep VERSION
```

## Security & Performance Features

### Security Features
- ✅ CORS protection (only allows frontend origin)
- ✅ Rate limiting (prevents brute force)
- ✅ Security headers (X-Frame-Options, CSP, etc.)
- ✅ Authorization forwarding (transparent pipe to backend)
- ✅ No token validation at gateway (backend owns auth logic)

**Architecture Note:** Gateway handles routing only. All authentication and authorization logic is performed by the backend.

### Performance Features
- ✅ Connection pooling (keepalive to backend)
- ✅ Gzip compression (bandwidth reduction)
- ✅ Auto worker scaling (CPU cores)
- ✅ Optimized buffering

## Production Deployment

For production deployments, see:
- Root `docker-compose.prod.yml` for production configuration
- `docs/DEPLOYMENT.md` for Azure Container Apps deployment
- `docs/VERSION_MANAGEMENT.md` for version control strategy

---

**Architecture Pattern:** Versioned Docker Images
**Gateway Repository:** https://github.com/tj-hand/nginx_api_gateway
**Version Control:** Via `.env` environment variables
**Customization:** Volume mounts (custom-routes/)
