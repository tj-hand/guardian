"""
Simple Example Backend for Bolt Gateway Integration

This is a minimal Flask application demonstrating a backend service
that works with Bolt gateway.
"""

from flask import Flask, jsonify
from flask_cors import CORS
import os

app = Flask(__name__)

# CORS is handled by Bolt gateway, but we enable it here for direct testing
CORS(app)

PORT = int(os.getenv('PORT', 8000))


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint for Docker healthcheck and monitoring."""
    return jsonify({"status": "healthy"}), 200


@app.route('/api/hello', methods=['GET'])
def hello():
    """Simple API endpoint that returns a greeting."""
    return jsonify({
        "message": "Hello from backend!",
        "service": "example-backend",
        "port": PORT
    }), 200


@app.route('/api/public/info', methods=['GET'])
def public_info():
    """Public endpoint (no auth required)."""
    return jsonify({
        "message": "Public info from backend",
        "version": "1.0.0",
        "endpoints": [
            "/health",
            "/api/hello",
            "/api/public/info"
        ]
    }), 200


if __name__ == '__main__':
    print(f"Starting example backend on port {PORT}")
    app.run(host='0.0.0.0', port=PORT, debug=False)
