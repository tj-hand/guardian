# Simple Bolt Gateway Integration Example

This example demonstrates how to integrate Bolt gateway into your project using pre-built Docker images.

## What This Example Shows

- ✅ Using Bolt gateway with a simple backend service
- ✅ Configuration via environment variables
- ✅ No source code needed - just docker-compose.yml
- ✅ Production-ready setup with health checks

## Project Structure

```
simple-integration/
├── README.md              # This file
├── docker-compose.yml     # Complete integration example
├── .env.example           # Environment configuration template
└── backend/               # Simple example backend
    ├── Dockerfile
    └── app.py
```

## Quick Start

### 1. Copy environment configuration

```bash
cp .env.example .env
# Edit .env if you need to customize
```

### 2. Start all services

```bash
docker compose up -d
```

### 3. Test the gateway

```bash
# Health check
curl http://localhost:8081/health

# Test backend through gateway
curl http://localhost/api/hello

# Expected response: {"message": "Hello from backend!"}
```

### 4. Stop services

```bash
docker compose down
```

## Configuration

All configuration is done via environment variables in `.env`:

| Variable | Description | Default |
|----------|-------------|---------|
| `BACKEND_1_HOST` | Backend service hostname | `example-backend` |
| `BACKEND_1_PORT` | Backend service port | `8000` |
| `FRONTEND_URL` | Frontend URL for CORS | `http://localhost` |
| `MAX_UPLOAD_SIZE` | Max file upload size | `100M` |

## Architecture

```
┌─────────────────────────────────────┐
│  Client (Browser/API Consumer)      │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Bolt Gateway (Port 80)             │
│  - Routes requests                  │
│  - CORS handling                    │
│  - Rate limiting                    │
│  - Health checks (Port 8081)        │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Your Backend (Port 8000)           │
│  - Business logic                   │
│  - Database operations              │
│  - API endpoints                    │
└─────────────────────────────────────┘
```

## What's Happening

1. **Bolt Gateway** pulls the latest image from GitHub Container Registry
2. **Environment variables** configure backend connection and CORS
3. **Gateway routes** requests from port 80 to your backend on port 8000
4. **Health checks** ensure services are running (port 8081)
5. **Docker networks** provide isolated communication between services

## Customizing for Your Project

### Add Your Own Backend

Replace the `example-backend` service with your actual backend:

```yaml
services:
  bolt-gateway:
    # ... gateway config stays the same
    environment:
      - BACKEND_1_HOST=my-actual-backend
      - BACKEND_1_PORT=3000

  my-actual-backend:
    build: ./my-backend
    ports:
      - "3000:3000"
    networks:
      - app-network
```

### Add Multiple Backends

```yaml
services:
  bolt-gateway:
    environment:
      - BACKEND_1_HOST=api-service
      - BACKEND_1_PORT=8000
      - BACKEND_2_HOST=data-service
      - BACKEND_2_PORT=8001
      - FRONTEND_URL=http://localhost

  api-service:
    build: ./api-service
    networks:
      - app-network

  data-service:
    build: ./data-service
    networks:
      - app-network
```

### Add Custom Routes

Create custom route configuration and mount it:

```yaml
services:
  bolt-gateway:
    image: ghcr.io/tj-hand/bolt-gateway:latest
    volumes:
      - ./custom-routes/auth.conf:/etc/nginx/conf.d/custom-routes/auth.conf:ro
```

See [`gateway/docs/custom-routes-example.conf`](../../gateway/docs/custom-routes-example.conf) for templates.

## Production Considerations

Before deploying to production:

1. **Pin the version** instead of using `:latest`
   ```yaml
   image: ghcr.io/tj-hand/bolt-gateway:1.0.0
   ```

2. **Use environment-specific configuration**
   ```bash
   # .env.production
   FRONTEND_URL=https://your-domain.com
   BACKEND_1_HOST=api.internal.company.com
   ```

3. **Add SSL/TLS** at your load balancer or cloud platform level

4. **Configure monitoring** and log aggregation

5. **Test thoroughly** in staging environment first

## Troubleshooting

### Gateway returns 502 Bad Gateway

**Cause**: Gateway can't reach backend

**Solution**:
```bash
# Check backend is running
docker compose ps

# Check logs
docker compose logs example-backend

# Verify network connectivity
docker compose exec bolt-gateway ping example-backend
```

### CORS errors in browser

**Cause**: `FRONTEND_URL` doesn't match your frontend domain

**Solution**:
```bash
# Update .env with exact frontend URL (including protocol)
FRONTEND_URL=http://localhost:3000

# Restart gateway
docker compose restart bolt-gateway
```

### File upload fails (413 Request Entity Too Large)

**Cause**: File exceeds `MAX_UPLOAD_SIZE`

**Solution**:
```bash
# In .env
MAX_UPLOAD_SIZE=500M

# Restart gateway
docker compose restart bolt-gateway
```

## Next Steps

- Read the [complete integration guide](../../gateway/docs/INTEGRATION_GUIDE.md)
- Explore [custom routes examples](../../gateway/docs/custom-routes-example.conf)
- Check the [main Bolt documentation](../../README.md)

## Need Help?

- Open an issue: https://github.com/tj-hand/bolt/issues
- Read the docs: [gateway/README.md](../../gateway/README.md)
