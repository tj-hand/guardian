# Bolt API Gateway

**Bolt** is a production-ready NGINX API Gateway for routing frontend requests to multiple backend services with security, authentication, and file handling support.

## Gateway Implementation

See the [`gateway/`](gateway/) directory
- [`gateway/nginx/`](gateway/nginx/) - NGINX configuration files
- [`gateway/docker/`](gateway/docker/) - Container setup (Dockerfile, entrypoint)
- [`gateway/docs/`](gateway/docs/) - Integration guides and documentation
- [`gateway/README.md`](gateway/README.md) - Complete gateway documentation
- [`gateway/.env.example`](gateway/.env.example) - Environment configuration template

## Features
- Multi-backend routing and load balancing
- Origin validation and CORS configuration
- Security headers and rate limiting
- File upload/download handling (up to 100MB)
- JWT authentication forwarding
- Health checks and monitoring

## Architecture

Bolt serves as **Layer 0 (Core Infrastructure)** in a modular layered architecture. See [MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md](MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md) for the complete architectural vision where Bolt acts as the Gateway Container foundation.

## Quick Start
```bash
cd gateway
cp .env.example .env
# Edit .env with your backend configuration
docker compose up -d
```

## Integration into Your Project

```yaml
# Add to your docker-compose.yml
services:
  bolt-gateway:
    image: ghcr.io/tj-hand/bolt-gateway:latest
    ports:
      - "80:80"
      - "8081:8080"
    environment:
      - BACKEND_1_HOST=your-backend
      - BACKEND_1_PORT=8000
      - FRONTEND_URL=http://localhost
```

## Documentation

| Document | Description |
|----------|-------------|
| [gateway/README.md](gateway/README.md) | Complete gateway documentation |
| [gateway/docs/INTEGRATION_GUIDE.md](gateway/docs/INTEGRATION_GUIDE.md) | Gateway integration strategies |
| [examples/simple-integration/](examples/simple-integration/) | **Simple integration example - Start here!** |
| [MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md](MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md) | Complete architectural guide - Bolt as Layer 0 Gateway Container |

---

## Project Management

This project uses a **Control Board** for visual task management and automated deployment. The Control Board integration is configured in the [`.claude/`](.claude/) directory:

- [`.claude/project.yml`](.claude/project.yml) - Project roadmap and feature tracking
- [`.claude/Claude.md`](.claude/Claude.md) - AI orchestrator instructions
- [`.claude/agents/`](.claude/agents/) - Specialized development agents

---

## License

MIT
