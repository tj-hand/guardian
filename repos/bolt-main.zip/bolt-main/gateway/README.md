# Bolt Gateway

> NGINX API Gateway for routing requests to multiple backend services and external APIs with security, authentication, and CORS handling.

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Adding More Backends](#adding-more-backends)
- [External Services](#external-services)
- [Environment Variables](#environment-variables)
- [Deployment](#deployment)
- [Security](#security)
- [Troubleshooting](#troubleshooting)

---

## Overview

Bolt Gateway is a production-ready NGINX API Gateway that:

- Routes requests to **multiple backend services** based on URL path
- Supports **internal services and external APIs** (any resolvable hostname)
- Provides gateway health endpoint (`/health`) independent of backends
- Adds gateway identification header (`X-Forwarded-By`) for backend validation
- Supports optional client validation via `X-Client-ID` header
- Handles CORS (gateway-controlled or passthrough mode)
- Handles file uploads/downloads with extended timeouts

### Architecture

```
┌─────────────────┐
│     Client      │
│   (Frontend)    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Bolt Gateway   │ ← Health: /health (JSON)
│   (Port 8088)   │
└────────┬────────┘
         │ X-Forwarded-By: bolt-gateway
         │
    ┌────┼────┬────────┐
    ▼    ▼    ▼        ▼
┌──────┐┌──────┐┌──────┐┌─────────────┐
│ Back ││ Back ││ Back ││  External   │
│ end  ││ end  ││ end  ││   Service   │
│  1   ││  2   ││  N   ││ (Stripe,etc)│
└──────┘└──────┘└──────┘└─────────────┘
```

> **Note:** The default configuration includes 2 backends as an example. You can add unlimited backends and external services by extending the NGINX configuration.

### Request Flow

1. Client sends request to Gateway
2. Gateway validates CORS origin (if enabled)
3. Gateway routes request based on URL path
4. Gateway adds `X-Forwarded-By: bolt-gateway` header
5. Gateway forwards request to appropriate backend or external service
6. Backend can verify request came through gateway
7. Backend processes request and returns response
8. Gateway returns response to client

---

## Features

### Gateway Health Endpoint

Independent health check that verifies gateway is running:

```bash
curl http://localhost:8088/health
# Returns: {"status":"healthy","service":"bolt-gateway"}
```

### Gateway Identification Header

All proxied requests include `X-Forwarded-By: bolt-gateway`. Backend can validate:

```python
# Python/Django example
if request.headers.get('X-Forwarded-By') != 'bolt-gateway':
    return HttpResponseForbidden('Direct access not allowed')
```

### Multi-Backend Routing

Route requests to different backends based on URL path. The default configuration includes 2 backends as an example:

| Route | Backend | Description |
|-------|---------|-------------|
| `/api/users/*` | Backend 1 | User/Auth endpoints |
| `/api/protected/*` | Backend 1 | Protected endpoints |
| `/api/products/*` | Backend 2 | Product endpoints |
| `/api/public/info` | Backend 1 | Public info |
| `/api/public/products` | Backend 2 | Public products |
| `/api/*` | Backend 1 | Catch-all (default) |

> **This is not a limit!** See [Adding More Backends](#adding-more-backends) to add Backend 3, 4, N, or external services.

### Client Validation (Optional)

The gateway can track or reject requests based on `X-Client-ID` header:

```nginx
# Known clients (configured in default.conf.template)
map $http_x_client_id $known_client {
    default     0;    # Unknown
    "evoke"     1;    # Known
    "mobile"    1;    # Known
    "internal"  1;    # Known
}
```

### CORS Handling

Two modes available:

| Mode | `CORS_PASSTHROUGH` | Behavior |
|------|-------------------|----------|
| Gateway-controlled | `false` (default) | Gateway adds CORS headers, hides backend CORS |
| Passthrough | `true` | Backend handles CORS, gateway passes through |

---

## Quick Start

### Prerequisites

- Docker 20.10+
- Docker Compose 2.0+

### 1. Configure Environment

```bash
cp .env.example .env
# Edit .env with your backend details
```

### 2. Start Gateway

```bash
docker-compose up -d
```

### 3. Verify Health

```bash
curl http://localhost:8088/health
# Returns: {"status":"healthy","service":"bolt-gateway"}
```

### 4. Test Routing

```bash
# Backend 1 route
curl http://localhost:8088/api/users/ping

# Backend 2 route
curl http://localhost:8088/api/products/ping
```

---

## Configuration

### Docker Compose Example

```yaml
services:
  bolt:
    image: bolt:latest
    ports:
      - "8088:80"
    environment:
      # Backend 1 (User/Auth)
      - BACKEND_1_HOST=user-service
      - BACKEND_1_PORT=8000
      # Backend 2 (Products)
      - BACKEND_2_HOST=product-service
      - BACKEND_2_PORT=8001
      # CORS
      - FRONTEND_URL=http://localhost
      - CORS_PASSTHROUGH=false
```

### Production Configuration

```yaml
services:
  bolt:
    image: ghcr.io/tj-hand/bolt:latest
    ports:
      - "8088:80"
    environment:
      - BACKEND_1_HOST=api.internal
      - BACKEND_1_PORT=8000
      - BACKEND_2_HOST=products.internal
      - BACKEND_2_PORT=8000
      - FRONTEND_URL=https://your-app.com
      - CORS_PASSTHROUGH=true
```

---

## Adding More Backends

The default configuration includes 2 backends **as an example**. You can add unlimited additional backends.

### Method 1: Custom Routes Directory

Create additional route files in `/etc/nginx/conf.d/custom-routes/`:

```nginx
# custom-routes/backend-3.conf

# Define Backend 3
upstream backend_3 {
    server analytics-service:8000;
    keepalive 32;
}

# Route to Backend 3
location /api/analytics/ {
    proxy_pass http://backend_3/api/analytics/;
    proxy_set_header X-Forwarded-By bolt-gateway;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header Authorization $http_authorization;
    proxy_http_version 1.1;
    proxy_set_header Connection "";
}
```

Mount in Docker Compose:

```yaml
services:
  bolt:
    volumes:
      - ./custom-routes:/etc/nginx/conf.d/custom-routes:ro
```

### Method 2: Extend the Template

Add more backends directly to `default.conf.template`:

```nginx
# Add Backend 3
upstream backend_3 {
    server ${BACKEND_3_HOST}:${BACKEND_3_PORT};
    keepalive 32;
}

# Add Backend 4
upstream backend_4 {
    server ${BACKEND_4_HOST}:${BACKEND_4_PORT};
    keepalive 32;
}
```

Then add corresponding environment variables to `docker-entrypoint.sh`:

```bash
export BACKEND_3_HOST="${BACKEND_3_HOST:-localhost}"
export BACKEND_3_PORT="${BACKEND_3_PORT:-8002}"
```

---

## External Services

Backend hosts can be **any resolvable hostname**, not just internal Docker services. This enables routing to external APIs and third-party services.

### Supported Host Types

| Type | Example | Use Case |
|------|---------|----------|
| Docker service | `user-service` | Internal microservices |
| Internal DNS | `api.internal.company.com` | Private network services |
| External API | `api.stripe.com` | Third-party services |
| IP address | `10.0.0.50` | Direct IP routing |
| Cloud service | `my-api.us-east-1.amazonaws.com` | AWS, GCP, Azure services |

### Example: External Payment Service

```yaml
environment:
  # Internal backend
  - BACKEND_1_HOST=user-service
  - BACKEND_1_PORT=8000
  # External payment API
  - BACKEND_2_HOST=api.stripe.com
  - BACKEND_2_PORT=443
```

### Example: Custom Route to External Service

```nginx
# custom-routes/payments.conf

upstream stripe_api {
    server api.stripe.com:443;
    keepalive 32;
}

location /api/payments/ {
    proxy_pass https://stripe_api/v1/;
    proxy_ssl_server_name on;
    proxy_set_header X-Forwarded-By bolt-gateway;
    proxy_set_header Host api.stripe.com;
    # ... other headers
}
```

### HTTPS to External Services

For external HTTPS services, use `proxy_ssl_server_name on`:

```nginx
location /api/external/ {
    proxy_pass https://external-api.com/;
    proxy_ssl_server_name on;
    proxy_ssl_protocols TLSv1.2 TLSv1.3;
    # ...
}
```

---

## Environment Variables

### Default Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BACKEND_1_HOST` | `localhost` | Backend 1 hostname |
| `BACKEND_1_PORT` | `8000` | Backend 1 port |
| `BACKEND_2_HOST` | `localhost` | Backend 2 hostname |
| `BACKEND_2_PORT` | `8001` | Backend 2 port |
| `FRONTEND_URL` | `http://localhost` | Frontend origin for CORS |
| `CORS_PASSTHROUGH` | `false` | If `true`, backend handles CORS |
| `MAX_UPLOAD_SIZE` | `100M` | Maximum file upload size |
| `LOG_LEVEL` | `warn` | NGINX log level |

### Adding More Backend Variables

To add `BACKEND_3_*`, `BACKEND_4_*`, etc., update `docker-entrypoint.sh`:

```bash
export BACKEND_3_HOST="${BACKEND_3_HOST:-localhost}"
export BACKEND_3_PORT="${BACKEND_3_PORT:-8002}"
```

And add to the `env_vars` list:

```bash
local env_vars='$BACKEND_1_HOST:$BACKEND_1_PORT:$BACKEND_2_HOST:$BACKEND_2_PORT:$BACKEND_3_HOST:$BACKEND_3_PORT:...'
```

---

## Deployment

### Docker

```bash
# Build image
docker build -f docker/Dockerfile -t bolt:latest .

# Run container
docker run -d \
  -p 8088:80 \
  -e BACKEND_1_HOST=backend-1 \
  -e BACKEND_1_PORT=8000 \
  -e BACKEND_2_HOST=backend-2 \
  -e BACKEND_2_PORT=8001 \
  -e CORS_PASSTHROUGH=true \
  bolt:latest
```

### Production Checklist

- [ ] Set `BACKEND_*_HOST` and `BACKEND_*_PORT` to production backends
- [ ] Set `FRONTEND_URL` to production frontend domain
- [ ] Configure SSL/TLS at load balancer level
- [ ] Set up health check monitoring on `/health`
- [ ] Configure log aggregation

---

## Security

### Gateway Identification

Backend services should verify `X-Forwarded-By: bolt-gateway` header to reject direct access:

```python
# Django middleware example
class GatewayRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.headers.get('X-Forwarded-By') != 'bolt-gateway':
            return HttpResponseForbidden('Direct access not allowed')
        return self.get_response(request)
```

### Security Headers

All responses include:

- `X-Content-Type-Options: nosniff`
- `X-XSS-Protection: 1; mode=block`
- `X-Frame-Options: SAMEORIGIN`
- `Referrer-Policy: strict-origin-when-cross-origin`

### Rate Limiting

- API routes: 10 req/s per IP (burst 20)
- Auth routes: 5 req/s per IP (burst 10)
- Upload routes: 2 req/s per IP (burst 5)

---

## Troubleshooting

### Gateway Health Check

```bash
# Check gateway health
curl http://localhost:8088/health
# Expected: {"status":"healthy","service":"bolt-gateway"}

# Check Docker health
docker inspect bolt | grep -A 10 Health
```

### 502 Bad Gateway

Backend is unreachable:

```bash
# Check backends are running
docker ps | grep backend

# Test backend directly
curl http://localhost:3001/health

# Check gateway logs
docker logs bolt
```

### CORS Issues

1. Check `FRONTEND_URL` matches your frontend origin
2. If backend handles CORS, set `CORS_PASSTHROUGH=true`
3. Check browser console for specific CORS error

### Validate NGINX Config

```bash
docker exec bolt nginx -t
```

### View Logs

```bash
docker logs -f bolt
```

---

## Acceptance Criteria

- [x] Gateway starts without external route configuration files
- [x] `curl http://gateway/health` returns gateway health JSON
- [x] All proxied requests include `X-Forwarded-By: bolt-gateway` header
- [x] Routes work with default image configuration
- [x] Multiple backend routing supported (not limited to 2)
- [x] External services supported

---

## License

MIT License
