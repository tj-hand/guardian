# NGINX API Gateway Configuration

This directory contains the foundational NGINX configuration for the API Gateway. The configuration is designed to be production-ready, secure, and prepared for future expansion.

## Directory Structure

```
nginx/
├── nginx.conf                 # Main NGINX configuration
├── conf.d/
│   └── default.conf          # Default server block configuration
├── templates/                # Template files for environment variable substitution
└── README.md                 # This file
```

## Configuration Overview

### nginx.conf (Main Configuration)

The main configuration file establishes:

- **Worker Processes**: Auto-configured based on available CPU cores
- **Event Handling**: Optimized with epoll for Linux systems
- **Logging**: Custom log format with timing information
- **Performance**: Gzip compression, file caching, keepalive connections
- **Buffer Sizes**: Configured for typical API workloads
- **Rate Limiting**: Predefined zones for API, auth, and upload protection
- **Security**: Server tokens hidden, secure defaults

### conf.d/default.conf (Server Configuration)

The server block configuration includes:

- **Upstream Definition**: Backend API service connection pooling
- **Security Headers**: X-Content-Type-Options, X-Frame-Options, CSP, etc.
- **Health Check**: `/health` endpoint for monitoring
- **Placeholder Routes**: Commented sections for future implementation:
  - `/api/*` - Authenticated API routes
  - `/auth/*` - Authentication endpoints
  - `/public/*` - Public (non-authenticated) routes
  - `/api/upload` - File upload handling
  - `/api/download` - File download handling
  - `/ws/*` - WebSocket support

## Environment Variables

The configuration is designed to work with the following environment variables:

| Variable | Description | Default | Usage |
|----------|-------------|---------|-------|
| `FRONTEND_URL` | Frontend application URL for CORS validation | - | Origin validation |
| `BACKEND_API_URL` | Backend service URL/host:port | `127.0.0.1:8080` | Upstream proxy_pass |
| `MAX_UPLOAD_SIZE` | Maximum file upload size | `10M` | client_max_body_size |

## Key Features Prepared

### 1. Rate Limiting

Three rate limiting zones are defined:

- **api_limit**: 10 requests/second for general API routes
- **auth_limit**: 5 requests/second for authentication endpoints
- **upload_limit**: 2 requests/second for file uploads
- **conn_limit**: Maximum 10 concurrent connections per IP

### 2. Security Headers

Production-ready security headers included:

- X-Content-Type-Options: nosniff
- X-XSS-Protection: 1; mode=block
- X-Frame-Options: SAMEORIGIN
- Referrer-Policy: strict-origin-when-cross-origin
- Content-Security-Policy (baseline configuration)

### 3. CORS Support

CORS configuration is prepared but commented out. To enable:

1. Uncomment the CORS map block in `nginx.conf`
2. Configure allowed origins based on `FRONTEND_URL`
3. Uncomment CORS headers in `default.conf` location blocks

### 4. File Upload/Download

Specialized configuration sections prepared for:

- Extended timeouts for large files
- Request buffering control
- Streaming upload support
- Buffer size optimization for downloads

### 5. Proxy Settings

Default proxy configuration includes:

- Header preservation (X-Real-IP, X-Forwarded-For, etc.)
- Connection keepalive for backend communication
- Timeout configurations (60s default, 300s for file operations)
- HTTP/1.1 with connection reuse

## Testing the Configuration

### Validate Syntax

```bash
nginx -t -c /path/to/nginx.conf
```

### Run with Docker

Example `Dockerfile`:

```dockerfile
FROM nginx:alpine

# Copy custom configuration
COPY nginx/nginx.conf /etc/nginx/nginx.conf
COPY nginx/conf.d/default.conf /etc/nginx/conf.d/default.conf

# Expose port
EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
```

Example `docker-compose.yml`:

```yaml
version: '3.8'

services:
  nginx:
    build: .
    ports:
      - "80:80"
    environment:
      - FRONTEND_URL=http://localhost
      - BACKEND_API_URL=backend:8080
      - MAX_UPLOAD_SIZE=100M
    depends_on:
      - backend
    networks:
      - app-network

  backend:
    image: your-backend-image
    networks:
      - app-network

networks:
  app-network:
    driver: bridge
```

### Test Health Check

```bash
curl http://localhost/health
# Expected: OK
```

## Implementation Roadmap

### Phase 1: Basic Routing (Current)
- ✅ Foundation structure
- ✅ Health check endpoint
- ✅ Security headers
- ✅ Rate limiting zones

### Phase 2: API Routing (Next)
- Configure backend upstream with environment variable
- Enable `/api/*` routes with authentication validation
- Enable `/auth/*` routes with rate limiting
- Enable `/public/*` routes

### Phase 3: CORS and Security
- Configure origin validation with FRONTEND_URL
- Enable CORS headers for all routes
- Implement OPTIONS preflight handling
- Fine-tune CSP headers based on frontend requirements

### Phase 4: File Handling
- Configure MAX_UPLOAD_SIZE from environment
- Enable `/api/upload` route with streaming support
- Enable `/api/download` route with optimized buffering
- Test with various file sizes and types

### Phase 5: Advanced Features
- WebSocket support (if needed)
- Static file serving for Vue.js SPA (if serving from NGINX)
- Custom error pages
- SSL/TLS configuration (Let's Encrypt or custom certificates)
- Additional security hardening (rate limiting fine-tuning, DDoS protection)

## Configuration Decisions Made

### 1. Worker Processes: Auto
**Rationale**: Automatically scales to available CPU cores, optimal for both development and production.

### 2. Gzip Compression: Enabled (Level 6)
**Rationale**: Good balance between compression ratio and CPU usage. Reduces bandwidth by 60-80% for text-based responses.

### 3. Keepalive Connections: Enabled
**Rationale**: Reduces latency and improves throughput by reusing TCP connections.

### 4. Default Body Size: 10M
**Rationale**: Suitable for typical API requests. Will be increased for file upload routes specifically.

### 5. Timeout Settings: 60s default, 300s for uploads
**Rationale**: Prevents hanging connections while allowing time for legitimate operations.

### 6. Rate Limiting: Conservative defaults
**Rationale**: Protects against abuse while allowing normal usage. Can be adjusted based on actual traffic patterns.

### 7. Security Headers: Permissive baseline
**Rationale**: Provides protection without breaking functionality. Should be tightened based on specific application needs.

## Next Steps

1. **Configure Backend Connection**
   - Set BACKEND_API_URL in environment or docker-compose
   - Update upstream block in default.conf

2. **Enable First Route**
   - Uncomment `/api/*` location block
   - Configure authentication validation mechanism
   - Test with backend service

3. **Configure CORS**
   - Set FRONTEND_URL environment variable
   - Uncomment CORS map in nginx.conf
   - Enable CORS headers in location blocks
   - Test preflight requests

4. **Implement Authentication Validation**
   - Decide on authentication mechanism (JWT validation, auth_request, etc.)
   - Configure auth validation endpoint
   - Test authenticated and unauthenticated requests

5. **File Upload Configuration**
   - Set MAX_UPLOAD_SIZE environment variable
   - Uncomment upload location block
   - Test with various file sizes
   - Monitor memory and performance

## Troubleshooting

### Configuration Test Fails

```bash
nginx -t -c /etc/nginx/nginx.conf
```

Check error messages for syntax errors or missing includes.

### 502 Bad Gateway

- Verify backend service is running and accessible
- Check upstream server address in default.conf
- Review error logs: `tail -f /var/log/nginx/error.log`

### CORS Errors

- Verify FRONTEND_URL is correctly set
- Ensure CORS headers are uncommented
- Check browser console for specific CORS issues
- Test preflight OPTIONS requests

### Rate Limiting Too Strict

Adjust rate limiting parameters in nginx.conf:
- Increase rate: `rate=20r/s` (instead of 10r/s)
- Increase burst: `burst=40` (instead of 20)
- Allow some excess: remove `nodelay` to queue requests

## Monitoring and Logging

### Access Logs

```bash
tail -f /var/log/nginx/access.log
```

Custom format includes:
- Request timing information
- Upstream response times
- Forwarded client IP addresses

### Error Logs

```bash
tail -f /var/log/nginx/error.log
```

Set log level in nginx.conf (debug, info, notice, warn, error, crit, alert, emerg)

### Performance Metrics

Monitor these metrics:
- Request rate (requests/second)
- Response times (upstream_response_time)
- Connection count (active connections)
- Error rate (4xx, 5xx responses)
- Rate limit drops (check error log)

## Additional Resources

- [NGINX Documentation](https://nginx.org/en/docs/)
- [NGINX Reverse Proxy Guide](https://docs.nginx.com/nginx/admin-guide/web-server/reverse-proxy/)
- [NGINX Rate Limiting](https://www.nginx.com/blog/rate-limiting-nginx/)
- [NGINX Security Controls](https://docs.nginx.com/nginx/admin-guide/security-controls/)
