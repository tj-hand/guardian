#!/bin/sh
# =============================================================================
# Docker Entrypoint Script for NGINX API Gateway
# =============================================================================
# This script processes NGINX template files with environment variable
# substitution, validates the generated configuration, and starts NGINX.
#
# Features:
# - Dynamic backend configuration via environment variables
# - Multiple backend support
# - Configuration validation before startup
# - Clear error messages and logging
# - Fail-fast on errors
# - Production-ready with proper signal handling
# =============================================================================

set -e  # Exit immediately if a command exits with a non-zero status
set -u  # Treat unset variables as an error
# Note: pipefail is not available in POSIX sh (Alpine's default shell)

# -----------------------------------------------------------------------------
# Environment Variables with Secure Defaults
# -----------------------------------------------------------------------------
# Backend 1 Configuration (Primary backend - User/Auth, Main API)
export BACKEND_1_HOST="${BACKEND_1_HOST:-localhost}"
export BACKEND_1_PORT="${BACKEND_1_PORT:-8000}"

# Backend 2 Configuration (Secondary backend - Products, Data)
export BACKEND_2_HOST="${BACKEND_2_HOST:-localhost}"
export BACKEND_2_PORT="${BACKEND_2_PORT:-8001}"

# Frontend Configuration
export FRONTEND_URL="${FRONTEND_URL:-http://localhost}"

# CORS Configuration
# Set to "true" to pass through backend CORS headers instead of gateway handling them
export CORS_PASSTHROUGH="${CORS_PASSTHROUGH:-false}"

# NGINX Configuration
export MAX_UPLOAD_SIZE="${MAX_UPLOAD_SIZE:-100M}"
export LOG_LEVEL="${LOG_LEVEL:-warn}"

# -----------------------------------------------------------------------------
# Logging Functions
# -----------------------------------------------------------------------------
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') - $*"
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') - $*" >&2
}

log_debug() {
    if [ "${DEBUG:-false}" = "true" ]; then
        echo "[DEBUG] $(date '+%Y-%m-%d %H:%M:%S') - $*"
    fi
}

# -----------------------------------------------------------------------------
# Print Configuration (for debugging)
# -----------------------------------------------------------------------------
print_configuration() {
    log_info "Starting NGINX API Gateway with the following configuration:"
    log_info "================================================"
    log_info "Backend 1: ${BACKEND_1_HOST}:${BACKEND_1_PORT}"
    log_info "Backend 2: ${BACKEND_2_HOST}:${BACKEND_2_PORT}"
    log_info "Frontend URL: ${FRONTEND_URL}"
    log_info "CORS Passthrough: ${CORS_PASSTHROUGH}"
    log_info "Max Upload Size: ${MAX_UPLOAD_SIZE}"
    log_info "Log Level: ${LOG_LEVEL}"
    log_info "================================================"
}

# -----------------------------------------------------------------------------
# Validate Required Tools
# -----------------------------------------------------------------------------
validate_tools() {
    log_debug "Validating required tools..."

    if ! command -v envsubst &> /dev/null; then
        log_error "envsubst command not found. Please install gettext package."
        exit 1
    fi

    if ! command -v nginx &> /dev/null; then
        log_error "nginx command not found. This script requires NGINX to be installed."
        exit 1
    fi

    log_debug "All required tools are available."
}

# -----------------------------------------------------------------------------
# Apply CORS Passthrough Mode
# -----------------------------------------------------------------------------
# When CORS_PASSTHROUGH=true, remove gateway CORS handling and let backends
# manage their own CORS headers. This removes:
# - Global proxy_hide_header directives for CORS headers
# - Gateway add_header directives for CORS headers
# - Preflight (OPTIONS) handlers that return 204
# -----------------------------------------------------------------------------
apply_cors_passthrough() {
    local config_file="$1"

    log_info "Applying CORS passthrough mode - backend will handle CORS headers"

    # Remove lines between CORS marker comments
    # CORS_GATEWAY_BEGIN ... CORS_GATEWAY_END - Global CORS config
    # CORS_PREFLIGHT_BEGIN ... CORS_PREFLIGHT_END - OPTIONS handlers
    # CORS_LOCATION_BEGIN ... CORS_LOCATION_END - Location-specific CORS
    # CORS_HEALTH_BEGIN ... CORS_HEALTH_END - Health endpoint CORS

    # Use sed to remove content between markers (keeping markers as comments for reference)
    sed -i \
        -e '/# CORS_GATEWAY_BEGIN/,/# CORS_GATEWAY_END/{ /# CORS_GATEWAY_BEGIN/b; /# CORS_GATEWAY_END/b; s/^/#DISABLED_FOR_PASSTHROUGH# /; }' \
        -e '/# CORS_PREFLIGHT_BEGIN/,/# CORS_PREFLIGHT_END/{ /# CORS_PREFLIGHT_BEGIN/b; /# CORS_PREFLIGHT_END/b; s/^/#DISABLED_FOR_PASSTHROUGH# /; }' \
        -e '/# CORS_LOCATION_BEGIN/,/# CORS_LOCATION_END/{ /# CORS_LOCATION_BEGIN/b; /# CORS_LOCATION_END/b; s/^/#DISABLED_FOR_PASSTHROUGH# /; }' \
        -e '/# CORS_HEALTH_BEGIN/,/# CORS_HEALTH_END/{ /# CORS_HEALTH_BEGIN/b; /# CORS_HEALTH_END/b; s/^/#DISABLED_FOR_PASSTHROUGH# /; }' \
        "${config_file}"

    log_info "CORS passthrough mode applied successfully"
}

# -----------------------------------------------------------------------------
# Process NGINX Template Files
# -----------------------------------------------------------------------------
process_templates() {
    local template_dir="/etc/nginx/conf.d"
    local template_file="${template_dir}/default.conf.template"
    local output_file="${template_dir}/default.conf"

    log_info "Processing NGINX configuration templates..."

    # Check if template file exists
    if [ ! -f "${template_file}" ]; then
        log_error "Template file not found: ${template_file}"
        log_error "Cannot proceed without configuration template."
        exit 1
    fi

    log_debug "Processing template: ${template_file}"

    # Define the environment variables to substitute
    # This ensures only our template variables are substituted, not NGINX variables
    local env_vars='$BACKEND_1_HOST:$BACKEND_1_PORT:$BACKEND_2_HOST:$BACKEND_2_PORT:$FRONTEND_URL:$MAX_UPLOAD_SIZE:$LOG_LEVEL'

    # Process template with envsubst and sed
    # Step 1: envsubst substitutes our template variables (${BACKEND_1_HOST}, etc.)
    # Step 2: sed converts $$ to $ (NGINX variable escaping)
    # Using a variable list prevents envsubst from corrupting NGINX variables
    if ! envsubst "${env_vars}" < "${template_file}" | sed 's/\$\$/$/g' > "${output_file}"; then
        log_error "Failed to process template file: ${template_file}"
        exit 1
    fi

    # Verify output file was created
    if [ ! -f "${output_file}" ]; then
        log_error "Failed to create configuration file: ${output_file}"
        exit 1
    fi

    # Check if output file is not empty
    if [ ! -s "${output_file}" ]; then
        log_error "Generated configuration file is empty: ${output_file}"
        exit 1
    fi

    log_info "Template processing completed successfully."
    log_debug "Generated configuration file: ${output_file}"

    # Apply CORS passthrough if enabled
    if [ "${CORS_PASSTHROUGH}" = "true" ]; then
        apply_cors_passthrough "${output_file}"
    fi
}

# -----------------------------------------------------------------------------
# Validate NGINX Configuration
# -----------------------------------------------------------------------------
validate_nginx_config() {
    log_info "Validating NGINX configuration..."

    # Run nginx -t to test configuration
    # Capture both stdout and stderr
    if ! nginx_output=$(nginx -t 2>&1); then
        log_error "NGINX configuration validation failed!"
        log_error "=== NGINX Configuration Error ==="
        log_error "${nginx_output}"
        log_error "================================="
        log_error "Please check your configuration files and environment variables."
        exit 1
    fi

    log_info "NGINX configuration validation successful."
    log_debug "${nginx_output}"
}

# -----------------------------------------------------------------------------
# Start NGINX
# -----------------------------------------------------------------------------
start_nginx() {
    log_info "Starting NGINX..."

    # Use exec to replace the shell with NGINX
    # This ensures proper signal handling (SIGTERM, SIGINT) for graceful shutdown
    # daemon off: Keep NGINX in foreground so container doesn't exit
    exec nginx -g 'daemon off;'
}

# -----------------------------------------------------------------------------
# Cleanup Function (called on script exit)
# -----------------------------------------------------------------------------
cleanup() {
    local exit_code=$?
    if [ ${exit_code} -ne 0 ]; then
        log_error "Script exited with error code: ${exit_code}"
    fi
}

# Register cleanup function to run on script exit
trap cleanup EXIT

# -----------------------------------------------------------------------------
# Main Execution
# -----------------------------------------------------------------------------
main() {
    log_info "NGINX API Gateway Docker Entrypoint"
    log_info "===================================="

    # Print current configuration
    print_configuration

    # Validate required tools
    validate_tools

    # Process template files
    process_templates

    # Validate generated NGINX configuration
    validate_nginx_config

    # Start NGINX (this will replace the current process)
    start_nginx
}

# Execute main function
main
