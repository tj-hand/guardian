# NGINX API Gateway - Docker Build Guide

## Overview

This directory contains the optimized Dockerfile for building the NGINX API Gateway container. The Dockerfile implements multi-stage builds, security hardening, and production-ready best practices.

## Quick Start

### Build the Image

```bash
# Basic build with default settings
docker build -f docker/Dockerfile -t nginx-api-gateway:latest .

# Build with custom NGINX version
docker build -f docker/Dockerfile \
  --build-arg NGINX_VERSION=1.27-alpine \
  -t nginx-api-gateway:1.27 .

# Build with specific user/group
docker build -f docker/Dockerfile \
  --build-arg NGINX_USER=nginx \
  --build-arg NGINX_GROUP=nginx \
  -t nginx-api-gateway:latest .
```

### Run the Container

```bash
# Run with default settings
docker run -d \
  --name api-gateway \
  -p 80:80 \
  nginx-api-gateway:latest

# Run with custom environment variables
docker run -d \
  --name api-gateway \
  -p 80:80 \
  -e NGINX_WORKER_PROCESSES=4 \
  -e NGINX_WORKER_CONNECTIONS=2048 \
  nginx-api-gateway:latest

# Run with volume mount for configuration (development)
docker run -d \
  --name api-gateway \
  -p 80:80 \
  -v $(pwd)/nginx/nginx.conf:/etc/nginx/nginx.conf:ro \
  -v $(pwd)/nginx/conf.d:/etc/nginx/conf.d:ro \
  nginx-api-gateway:latest
```

### Health Check

```bash
# Check container health status
docker inspect --format='{{.State.Health.Status}}' api-gateway

# Test health endpoint manually
curl http://localhost:8080/health
```

## Dockerfile Architecture

### Multi-Stage Build Strategy

The Dockerfile uses a 2-stage build process:

#### Stage 1: Configuration Validator
- **Purpose**: Validate NGINX configurations at build time
- **Benefit**: Catches configuration errors before deployment
- **Result**: Build fails fast if config is invalid

#### Stage 2: Production Image
- **Purpose**: Create minimal, secure final image
- **Features**:
  - Alpine-based (minimal size)
  - Non-root user execution
  - Health check endpoint
  - Proper signal handling
  - Optimized layer caching

### Base Image Selection

**Chosen**: `nginx:1.27-alpine`

**Rationale**:
- **Alpine Linux**: Minimal size (~23MB base vs ~142MB for Debian)
- **Version 1.27**: Latest stable NGINX version with modern features
- **Security**: Smaller attack surface, fewer vulnerabilities
- **Performance**: Fast startup, low memory footprint
- **Official**: Maintained by NGINX team, follows best practices

### Image Size Optimization Techniques

1. **Alpine Base Image**: 85% size reduction vs Debian
2. **Multi-Stage Build**: Validation stage not included in final image
3. **Minimal Dependencies**: Only curl + ca-certificates for health checks
4. **Cache Cleanup**: `--no-cache` flag + removal of `/var/cache/apk/*`
5. **Layer Optimization**: Commands combined with `&&` to reduce layers
6. **Smart .dockerignore**: Excludes ~90% of project files from build context

Expected final image size: **~25-30MB** (vs 150MB+ for standard nginx)

## Security Features

### Non-Root User Execution

The container runs as the `nginx` user (not root) for enhanced security:

```dockerfile
USER ${NGINX_USER}
```

**Benefits**:
- Prevents privilege escalation attacks
- Limits damage from container breakout
- Meets compliance requirements (PCI-DSS, SOC 2)

**Note**: NGINX can run on port 80 as non-root user in Docker because the port binding happens at the container level by Docker daemon.

### Additional Security Measures

1. **Configuration Validation**: Build fails if NGINX config is invalid
2. **Proper File Permissions**: `chown` ensures nginx user owns all files
3. **CA Certificates**: Installed for secure upstream HTTPS connections
4. **Minimal Attack Surface**: Only essential packages installed
5. **No Shell Access**: Alpine minimal image reduces available tools
6. **Health Check Isolation**: Separate port (8080) for health endpoint

## Health Check Configuration

### Docker Health Check

```dockerfile
HEALTHCHECK --interval=30s \
            --timeout=3s \
            --start-period=5s \
            --retries=3 \
            CMD curl -f http://localhost:8080/health || exit 1
```

**Parameters**:
- **interval**: Check every 30 seconds
- **timeout**: Health check must respond within 3 seconds
- **start-period**: Grace period of 5 seconds after container start
- **retries**: Mark unhealthy after 3 consecutive failures

### Health Endpoint

Endpoint: `http://localhost:8080/health`

**Response**:
```
HTTP/1.1 200 OK
Content-Type: text/plain

healthy
```

**Features**:
- Dedicated port (8080) isolated from main traffic
- No logging (`access_log off`) to reduce noise
- Fast response (no backend checks)
- Plain text for simplicity

## Environment Variables

The following environment variables can be set at runtime:

| Variable | Default | Description |
|----------|---------|-------------|
| `NGINX_WORKER_PROCESSES` | `auto` | Number of worker processes (auto-detect CPU cores) |
| `NGINX_WORKER_CONNECTIONS` | `1024` | Maximum connections per worker |
| `NGINX_KEEPALIVE_TIMEOUT` | `65` | Keep-alive timeout in seconds |
| `NGINX_CLIENT_MAX_BODY_SIZE` | `10m` | Maximum request body size |

**Usage**:
```bash
docker run -e NGINX_WORKER_PROCESSES=4 nginx-api-gateway:latest
```

## Build Arguments

Customize the build process with these arguments:

| Argument | Default | Description |
|----------|---------|-------------|
| `NGINX_VERSION` | `1.27-alpine` | NGINX base image version |
| `NGINX_USER` | `nginx` | User to run NGINX process |
| `NGINX_GROUP` | `nginx` | Group for NGINX process |

**Example**:
```bash
docker build \
  --build-arg NGINX_VERSION=1.26-alpine \
  --build-arg NGINX_USER=www-data \
  -f docker/Dockerfile \
  -t nginx-api-gateway:custom .
```

## Signal Handling

The Dockerfile configures proper signal handling for graceful shutdowns:

```dockerfile
STOPSIGNAL SIGQUIT
CMD ["nginx", "-g", "daemon off;"]
```

**Behavior**:
- `SIGQUIT`: Graceful shutdown - waits for connections to finish
- `SIGTERM`: Fast shutdown - closes connections immediately
- `SIGKILL`: Forced kill - last resort (not catchable)

**Docker Stop**:
```bash
docker stop api-gateway  # Sends SIGQUIT, waits 10s, then SIGKILL
docker stop -t 30 api-gateway  # Wait 30 seconds before SIGKILL
```

## Directory Structure

```
nginx_api_gateway/
├── docker/
│   ├── Dockerfile          # Multi-stage production Dockerfile
│   └── README.md           # This file
├── nginx/
│   ├── nginx.conf          # Main NGINX configuration
│   └── conf.d/             # Additional configuration files
└── .dockerignore           # Build context exclusions
```

## Troubleshooting

### Build Fails at Configuration Validation

**Error**: `nginx: [emerg] configuration file /tmp/nginx.conf test failed`

**Solution**: Fix NGINX configuration syntax errors in `nginx/nginx.conf` or `nginx/conf.d/`

### Container Exits Immediately

**Check logs**:
```bash
docker logs api-gateway
```

**Common causes**:
- Invalid NGINX configuration (should be caught at build time)
- Port already in use (change `-p 8080:80` to use different host port)
- Permission issues (check file ownership)

### Health Check Failing

**Debug**:
```bash
# Check health status
docker inspect --format='{{.State.Health}}' api-gateway

# Test health endpoint
docker exec api-gateway curl -f http://localhost:8080/health

# Check NGINX error logs
docker logs api-gateway
```

### Cannot Access on Port 80

**Causes**:
1. Port binding issue: `docker run -p 80:80` (requires sudo on Linux)
2. Firewall blocking port 80
3. Another service using port 80

**Solutions**:
```bash
# Use alternative port
docker run -p 8080:80 nginx-api-gateway:latest

# Check if port is in use
sudo netstat -tulpn | grep :80

# Run with host network (Linux only)
docker run --network host nginx-api-gateway:latest
```

## Production Recommendations

1. **Version Pinning**: Always use specific versions, never `:latest`
   ```bash
   docker build -t nginx-api-gateway:1.0.0 .
   ```

2. **Resource Limits**: Set memory and CPU limits
   ```bash
   docker run -m 512m --cpus=2 nginx-api-gateway:1.0.0
   ```

3. **Logging**: Use Docker logging drivers
   ```bash
   docker run --log-driver=json-file --log-opt max-size=10m nginx-api-gateway:1.0.0
   ```

4. **Read-Only Root**: Mount root filesystem as read-only
   ```bash
   docker run --read-only --tmpfs /var/cache/nginx nginx-api-gateway:1.0.0
   ```

5. **Security Scanning**: Scan images for vulnerabilities
   ```bash
   docker scan nginx-api-gateway:1.0.0
   trivy image nginx-api-gateway:1.0.0
   ```

6. **Secrets Management**: Never bake secrets into images
   ```bash
   # Use environment variables or Docker secrets
   docker run --env-file .env nginx-api-gateway:1.0.0
   ```

## Performance Tuning

### For High Traffic Scenarios

Build with optimized settings:
```bash
docker run -d \
  --name api-gateway \
  -p 80:80 \
  -e NGINX_WORKER_PROCESSES=auto \
  -e NGINX_WORKER_CONNECTIONS=4096 \
  -e NGINX_KEEPALIVE_TIMEOUT=30 \
  --cpus=4 \
  -m 2g \
  nginx-api-gateway:latest
```

### Monitoring

```bash
# Watch resource usage
docker stats api-gateway

# View NGINX metrics
docker exec api-gateway curl http://localhost:8080/nginx_status
```

## Next Steps

1. Create NGINX configurations in `nginx/` directory (Issue #1)
2. Set up docker-compose for multi-container orchestration
3. Configure CI/CD pipeline for automated builds
4. Set up container registry (Docker Hub, ECR, GCR)
5. Implement centralized logging (ELK, Splunk, CloudWatch)
6. Add monitoring and alerting (Prometheus, Grafana)

## Support

For issues or questions:
- Check NGINX logs: `docker logs api-gateway`
- Review NGINX configuration: `docker exec api-gateway nginx -T`
- Validate configuration: `docker exec api-gateway nginx -t`
