# NGINX API Gateway - Complete Integration Guide

**All-in-one guide for using this gateway in your project**

## Table of Contents

- [Quick Start (5 minutes)](#quick-start-5-minutes)
- [Deployment Strategies](#deployment-strategies)
- [Understanding Git Behavior](#understanding-git-behavior)
- [Configuration](#configuration)
- [Custom Routes](#custom-routes)
- [File Classification](#file-classification)
- [Troubleshooting](#troubleshooting)

---

## Quick Start (5 minutes)

### For Most Projects (Recommended)

**Use pre-built Docker images** - No source code needed!

```yaml
# your-project/docker-compose.yml

services:
  bolt:
    image: ghcr.io/tj-hand/bolt:latest
    ports:
      - "80:80"        # Main gateway traffic
      - "8081:8080"    # Health check endpoint
    environment:
      - BACKEND_1_HOST=your-backend-service
      - BACKEND_1_PORT=8000
      - FRONTEND_URL=https://your-app.com
    depends_on:
      - your-backend-service
    networks:
      - app-network

  your-backend-service:
    build: ./backend
    ports:
      - "8000:8000"
    networks:
      - app-network

networks:
  app-network:
    driver: bridge
```

**That's it!** No git submodules, no source code, just configuration.

**Available Images:**
- `ghcr.io/tj-hand/bolt:latest` - Latest stable release
- `ghcr.io/tj-hand/bolt:1.0.0` - Specific version (recommended for production)
- `ghcr.io/tj-hand/bolt:main` - Latest main branch build

---

## Deployment Strategies

Choose the strategy that fits your use case:

### Strategy 1: Pre-Built Docker Images ⭐ RECOMMENDED

**Best for**: Production, CI/CD pipelines, most projects

**How it works**:
1. Gateway maintainers publish versioned images to registry
2. You pull and configure via environment variables
3. No source code in your project

**Setup**:
```yaml
services:
  bolt:
    image: ghcr.io/tj-hand/bolt:1.0.0  # Pin specific version
    env_file: .env.gateway
    ports:
      - "80:80"
      - "8081:8080"
    networks:
      - app-network
```

**Pros**:
- ✅ Fastest deployment
- ✅ Smallest footprint
- ✅ Easy version management
- ✅ No build time

**Cons**:
- ❌ Requires image registry access
- ❌ Can't inspect source easily

---

### Strategy 2: Git Archive Extraction

**Best for**: Building from source with minimal files

**How it works**:
1. Clone Bolt repository
2. Use `git archive` to extract only production files
3. `export-ignore` excludes test files, .claude/, etc.
4. Build Docker image from clean source

**Setup**:
```bash
# In your project
git clone --depth 1 https://github.com/tj-hand/bolt.git bolt-source
cd bolt-source/gateway
git archive --format=tar HEAD | tar -x -C ../../gateway-clean
cd ../../gateway-clean
docker build -f docker/Dockerfile -t myproject-gateway:latest .
```

**Result**: Clean source without test files

**Pros**:
- ✅ Clean deployment (no test files)
- ✅ Build from source
- ✅ Minimal footprint

**Cons**:
- ❌ Extra build step
- ❌ Must understand git archive

---

### Strategy 3: Git Submodule

**Best for**: Development, contributing back to gateway

**How it works**:
1. Add Bolt as Git submodule
2. Submodule clones **FULL repository** (this is normal!)
3. Build or reference from gateway subdirectory

**Setup**:
```bash
# In your project
git submodule add https://github.com/tj-hand/bolt.git bolt
git submodule update --init --recursive

# Build from gateway subdirectory
docker build -f bolt/gateway/docker/Dockerfile -t myproject-gateway:latest bolt/gateway/
```

**Important**: You WILL get all files (test/, .claude/, docs/, etc.)

**Pros**:
- ✅ Easy updates (git submodule update)
- ✅ Full source for development
- ✅ Can contribute back

**Cons**:
- ❌ Large footprint (includes test files)
- ❌ Submodule management complexity

---

## Understanding Git Behavior

### ⚠️ Common Misconception

**WRONG**: "export-ignore prevents test files when using git submodule"

**CORRECT**: "export-ignore only affects `git archive` command"

### Git Submodule vs Git Archive

```bash
# Git submodule → Clones ENTIRE repository
git submodule add <url> gateway
ls gateway/
# Result: docker/, nginx/, test-frontend/, test-backend/, .claude/, etc.
# ALL files are present - this is NORMAL Git behavior!

# Git archive → Respects export-ignore
cd gateway
git archive --format=tar HEAD | tar -x -C ../gateway-clean
ls ../gateway-clean/
# Result: docker/, nginx/, .env.example, README.md
# NO test-frontend/, test-backend/, .claude/ (excluded by export-ignore)
```

### Which Files Are Excluded by export-ignore?

See `.gitattributes`:
- `.claude/` - Internal development (AI agent orchestration)
- `PROJECT_REPORT.md` - Delivery report
- `test-frontend/` - Test frontend implementation
- `test-backend/` - Test backend implementation
- `tests/` - Playwright & Bash E2E tests
- `playwright.config.js` - Test configuration
- `package.json`, `package-lock.json` - Test dependencies
- `Makefile` - Development commands

**When does this matter?**
- ✅ Using `git archive` for clean deployments
- ✅ Creating release archives
- ❌ NOT when using git submodule (you get everything)

---

## Configuration

### Required Environment Variables

```bash
# .env.gateway
BACKEND_1_HOST=your-backend-service
BACKEND_1_PORT=8000
FRONTEND_URL=https://your-app.com
```

### All Available Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `BACKEND_1_HOST` | Yes | - | Primary backend hostname |
| `BACKEND_1_PORT` | Yes | - | Primary backend port |
| `BACKEND_2_HOST` | No | - | Secondary backend (optional) |
| `BACKEND_2_PORT` | No | - | Secondary backend port |
| `FRONTEND_URL` | Yes | - | Frontend CORS origin (CRITICAL) |
| `MAX_UPLOAD_SIZE` | No | 100M | File upload size limit |

### Docker Compose Example

```yaml
services:
  bolt:
    image: ghcr.io/tj-hand/bolt:latest
    env_file: .env.gateway  # Load all variables
    ports:
      - "80:80"
      - "8081:8080"
    # OR inline:
    environment:
      - BACKEND_1_HOST=backend
      - BACKEND_1_PORT=3000
      - FRONTEND_URL=http://localhost
    networks:
      - app-network
```

---

## Custom Routes

### Using the Extension Point

The gateway includes `/etc/nginx/conf.d/custom-routes/*.conf` at runtime.

**Step 1**: Create your custom route file

```nginx
# custom-routes/auth-routes.conf

upstream backend_auth {
    server auth-service:4000;
    keepalive 32;
}

location /api/v1/auth/login {
    limit_req zone=auth_limit burst=10 nodelay;
    
    if ($request_method = 'OPTIONS') {
        add_header Access-Control-Allow-Origin "${FRONTEND_URL}" always;
        add_header Access-Control-Allow-Methods "GET, POST" always;
        add_header Access-Control-Allow-Headers "Authorization, Content-Type" always;
        return 204;
    }
    
    proxy_pass http://backend_auth/api/v1/auth/login;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header Authorization $http_authorization;
}
```

**Step 2**: Mount in Docker Compose

```yaml
services:
  bolt:
    image: ghcr.io/tj-hand/bolt:latest
    ports:
      - "80:80"
      - "8081:8080"
    volumes:
      - ./custom-routes/auth-routes.conf:/etc/nginx/conf.d/custom-routes/auth-routes.conf:ro
    networks:
      - app-network
```

**Complete Template**: See `docs/custom-routes-example.conf`

---

## File Classification

### Files You Should NEVER Modify

| File | Why Immutable |
|------|---------------|
| `nginx/nginx.conf` | Core performance, security, logging |
| `docker/Dockerfile` | Gateway container image definition |
| `docker/docker-entrypoint.sh` | Template processing logic |

### Files You MUST Customize

| File | How |
|------|-----|
| `.env` | Copy to your project as `.env.gateway` |
| `docker-compose.yml` | Copy and modify for your services |

### Files You CAN Add (via Extension)

| Type | Method |
|------|--------|
| Custom routes | Mount to `/etc/nginx/conf.d/custom-routes/*.conf` |

**Details**: See `docs/FILE_CLASSIFICATION.md`

---

## Troubleshooting

### Issue: "I'm using submodule and getting test files"

**This is normal!** Git submodules clone the full repository.

**Solutions**:
1. Use Strategy 1 (pre-built images) - No source needed
2. Use Strategy 2 (git archive) - Clean extraction
3. Accept test files (they don't affect runtime, only repo size)

### Issue: "CORS errors"

**Check**: `FRONTEND_URL` matches your frontend domain exactly

```bash
# Must match (including protocol, no trailing slash)
FRONTEND_URL=https://app.example.com  # ✅
FRONTEND_URL=http://app.example.com   # ❌ Wrong protocol
FRONTEND_URL=https://app.example.com/ # ❌ Trailing slash
```

### Issue: "502 Bad Gateway"

**Cause**: Gateway can't reach backend

**Check**:
```bash
# Verify backend service name matches
docker-compose ps
# BACKEND_1_HOST must match service name
```

### Issue: "File upload fails (413)"

**Cause**: File exceeds `MAX_UPLOAD_SIZE`

**Solution**:
```bash
# In .env.gateway
MAX_UPLOAD_SIZE=500M
```

---

## Quick Reference

### Deployment Decision Tree

```
Q: Do you need source code in your project?
├─ No  → Use Strategy 1 (Pre-built images) ⭐
└─ Yes → Q: Do you need minimal files?
         ├─ Yes → Use Strategy 2 (Git archive)
         └─ No  → Use Strategy 3 (Git submodule)
```

### File Organization

```
your-project/
├── .env.gateway              # Your configuration
├── docker-compose.yml        # Your orchestration
├── custom-routes/            # Your custom routes (optional)
│   └── auth-routes.conf
├── backend/                  # Your backend code
└── gateway/                  # Git submodule (Strategy 3 only)
    ├── docker/               # IMMUTABLE
    ├── nginx/                # IMMUTABLE
    ├── test-frontend/        # Ignore (development only)
    └── test-backend/         # Ignore (development only)
```

### Environment Variables Checklist

```bash
# Minimum required
✅ BACKEND_1_HOST=?
✅ BACKEND_1_PORT=?
✅ FRONTEND_URL=?

# Optional
⭕ BACKEND_2_HOST=?
⭕ BACKEND_2_PORT=?
⭕ MAX_UPLOAD_SIZE=?
```

---

## Related Documentation

- **[Submodule Details](SUBMODULE_USAGE.md)** - Deep dive on Git submodule usage
- **[File Classification](FILE_CLASSIFICATION.md)** - Complete file-by-file breakdown
- **[Custom Routes Template](custom-routes-example.conf)** - Production-ready examples
- **[Main README](../README.md)** - Gateway features and capabilities

---

**Need help?** Check the troubleshooting section above or open an issue.
