# Using NGINX API Gateway as a Git Submodule

## Overview

This guide explains how to integrate the NGINX API Gateway into your project as a Git submodule.

**⚠️ Important**: Git submodules clone the **FULL repository** including test files, .claude/, and development artifacts. This is normal Git behavior. The `export-ignore` pattern documented here only affects the `git archive` command, not submodule pulls.

**For cleaner deployments**, consider using [pre-built Docker images](INTEGRATION_GUIDE.md#strategy-1-pre-built-docker-images) instead.

### What Git Submodules Provide

- Full gateway source code (including test files - this is normal!)
- Ability to track specific versions
- Updates from gateway repository
- Separation between gateway core and project configuration

## Table of Contents

- [Quick Start](#quick-start)
- [Understanding Git Submodules](#understanding-git-submodules)
- [Understanding export-ignore](#understanding-export-ignore)
- [Initial Setup](#initial-setup)
- [Configuration](#configuration)
- [Deployment Strategies](#deployment-strategies)
- [Updating the Gateway](#updating-the-gateway)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)

## Quick Start

```bash
# 1. Add gateway as submodule
cd your-project
git submodule add https://github.com/yourorg/nginx_api_gateway.git gateway
git submodule update --init --recursive

# 2. Create project-specific configuration
cp gateway/.env.example .env.gateway
# Edit .env.gateway with your backends and frontend URL

# 3. Create docker-compose.yml in your project root
cat > docker-compose.yml <<EOF
version: '3.9'
services:
  api-gateway:
    image: yourregistry/nginx-gateway:1.0.0
    env_file: .env.gateway
    ports:
      - "8080:80"
    depends_on:
      - your-backend

  your-backend:
    build: ./backend
    # your backend configuration
EOF

# 4. Deploy
docker-compose up -d
```

## Understanding Git Submodules

### What is a Git Submodule?

A Git submodule is a repository embedded inside another repository. It allows you to:

- Include external code/projects in your repository
- Track specific versions of the external project
- Keep the external project's history separate
- Update independently from your main project

### How Submodules Work

```
your-project/                    # Your main repository
├── .git/                        # Your git metadata
├── .gitmodules                  # Submodule configuration
├── gateway/                     # Submodule (NGINX gateway)
│   ├── .git                     # Points to gateway repository
│   ├── docker/                  # Gateway files
│   ├── nginx/                   # Gateway NGINX config
│   └── ...                      # Other gateway files
├── your-backend/                # Your application code
├── docker-compose.yml           # Your orchestration (references gateway/)
└── .env.gateway                 # Your gateway configuration
```

**Key Points**:
- The `gateway/` directory is a **link** to the external gateway repository
- Your repository only stores a **reference** to a specific commit in the gateway repo
- Changes to `gateway/` files don't affect your repository unless you commit the reference update
- The gateway repository and your repository have separate git histories

## Understanding export-ignore

### What is export-ignore?

The `.gitattributes` file in the gateway repository marks certain files with `export-ignore`. This tells Git to **exclude these files from archives** created with `git archive`.

### Why is This Useful for Submodules?

When you pull the gateway as a submodule, you get the **full repository** including:
- Core gateway files (needed ✅)
- Test implementations (not needed for production ❌)
- Development tools (not needed for production ❌)
- Internal documentation (not needed for production ❌)

The `export-ignore` pattern allows you to create **clean deployment archives** with only the files you need.

### Files Marked as export-ignore

The gateway repository excludes these from archives:

```
.claude/                  # AI agent orchestration (internal development)
PROJECT_REPORT.md         # Delivery report (internal documentation)
test-frontend/            # Test frontend (you have your own frontend)
test-backend/             # Test backend (you have your own backend)
tests/                    # Playwright & Bash E2E tests (gateway validation)
playwright.config.js      # Test configuration
package.json              # Test dependencies
package-lock.json         # Test dependencies lockfile
Makefile                  # Development commands
.gitignore                # Git configuration
.gitattributes            # Git configuration
```

### Creating Clean Archives

**Option 1: Full Repository (Development)**
```bash
# Clone full submodule (includes test files)
git submodule update --init --recursive
cd gateway
ls -la
# You see: test-frontend/, test-backend/, tests/, etc.
```

**Option 2: Clean Archive (Production)**
```bash
# Create archive without test files
cd gateway
git archive --format=tar HEAD | tar -x -C ../gateway-clean
cd ../gateway-clean
ls -la
# You see: ONLY docker/, nginx/, .env.example, README.md, etc.
# NO test-frontend/, test-backend/, tests/
```

**Option 3: Automated Clean Extraction**
```bash
# In your project's deployment script
#!/bin/bash
# deploy.sh

# Extract only production files from submodule
cd gateway
git archive --format=tar --prefix=gateway-prod/ HEAD | tar -x -C ..
cd ..

# Now use gateway-prod/ for Docker build
docker build -f gateway-prod/docker/Dockerfile -t myapp-gateway:latest gateway-prod/

# Deploy
docker-compose up -d
```

## Initial Setup

### Step 1: Add Submodule to Your Project

```bash
# Navigate to your project root
cd /path/to/your-project

# Add gateway as submodule
git submodule add https://github.com/yourorg/nginx_api_gateway.git gateway

# Initialize and fetch submodule content
git submodule update --init --recursive

# Commit the submodule reference
git add .gitmodules gateway
git commit -m "Add NGINX API Gateway as submodule"
```

**Result**: You now have a `gateway/` directory in your project containing the full gateway repository.

### Step 2: Verify Submodule

```bash
# Check submodule status
git submodule status

# Expected output:
# abc123def456 gateway (v1.0.0)

# Verify files are present
ls gateway/
# Expected: docker/, nginx/, .env.example, README.md, test-frontend/, test-backend/, etc.
```

### Step 3: Create Project-Specific Configuration

The gateway configuration should live **outside the submodule** in your project root:

```bash
# Create environment configuration for gateway
cp gateway/.env.example .env.gateway

# Edit with your values
nano .env.gateway
```

**`.env.gateway`** (example):
```bash
# Backend Services (YOUR backends, not test backends)
BACKEND_1_HOST=auth-service
BACKEND_1_PORT=8000
BACKEND_2_HOST=api-service
BACKEND_2_PORT=8001

# Frontend CORS Origin (YOUR frontend domain)
FRONTEND_URL=https://app.yourcompany.com

# Optional: File upload limit
MAX_UPLOAD_SIZE=200M
```

### Step 4: Create Docker Compose Orchestration

Create `docker-compose.yml` in your **project root** (not in the submodule):

```yaml
# your-project/docker-compose.yml
version: '3.9'

services:
  # NGINX API Gateway (from submodule)
  api-gateway:
    # Option A: Use pre-built image (RECOMMENDED)
    image: yourregistry.azurecr.io/nginx-gateway:1.0.0

    # Option B: Build from submodule (development only)
    # build:
    #   context: ./gateway
    #   dockerfile: docker/Dockerfile

    container_name: myapp-gateway
    restart: unless-stopped

    # Load gateway configuration from project root
    env_file:
      - .env.gateway

    ports:
      - "8080:80"      # Gateway API traffic
      - "9090:8080"    # Health check endpoint

    depends_on:
      auth-service:
        condition: service_healthy
      api-service:
        condition: service_healthy

    networks:
      - app-network

    # Optional: Volume for file uploads
    volumes:
      - uploads:/var/www/uploads

  # Your backend services
  auth-service:
    build: ./backend/auth-service
    environment:
      - DATABASE_URL=postgresql://...
    networks:
      - app-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 10s
      timeout: 5s
      retries: 3

  api-service:
    build: ./backend/api-service
    environment:
      - DATABASE_URL=postgresql://...
    networks:
      - app-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8001/health"]
      interval: 10s
      timeout: 5s
      retries: 3

networks:
  app-network:
    driver: bridge

volumes:
  uploads:
```

**Important Notes**:
- Configuration files (`.env.gateway`, `docker-compose.yml`) are in **your project root**
- The `gateway/` submodule directory is only referenced for Docker build context
- Never modify files inside `gateway/` submodule

### Step 5: Test the Setup

```bash
# Start all services
docker-compose up -d

# Check gateway health
curl http://localhost:9090/health
# Expected: OK

# Test routing to your backend
curl http://localhost:8080/api/users/ping
# Should route to auth-service

# Check logs
docker-compose logs -f api-gateway
```

## Configuration

### Environment Variables (Required)

Create `.env.gateway` in your project root with these **required** variables:

```bash
# Backend 1 (typically user/auth service)
BACKEND_1_HOST=your-auth-service-name
BACKEND_1_PORT=8000

# Backend 2 (optional - additional service)
BACKEND_2_HOST=your-api-service-name
BACKEND_2_PORT=8001

# Frontend CORS origin (CRITICAL for security)
FRONTEND_URL=https://your-frontend-domain.com
```

### Optional Configuration

```bash
# File upload size limit (default: 100M)
MAX_UPLOAD_SIZE=500M

# Additional backends (if needed)
BACKEND_3_HOST=analytics-service
BACKEND_3_PORT=8002
```

### Customizing NGINX Routes (Advanced)

If your API paths differ from the defaults, you may need to customize NGINX configuration:

**Option 1: Use Templates (Recommended)**

The gateway uses environment variable templating. Routes are defined in `gateway/nginx/conf.d/default.conf.template`.

**Option 2: Fork and Customize**

If you need significant routing changes:

1. Fork the gateway repository
2. Modify `nginx/conf.d/default.conf.template`
3. Use your forked repository as the submodule source
4. See [FILE_CLASSIFICATION.md](FILE_CLASSIFICATION.md) for what can be safely modified

## Deployment Strategies

### Strategy 1: Pre-Built Images (Production - Recommended)

**Best for**: Production environments, multiple projects, CI/CD pipelines

```yaml
# docker-compose.yml
services:
  api-gateway:
    image: yourregistry/nginx-gateway:1.0.0  # Use versioned image
    env_file: .env.gateway
```

**Workflow**:
1. Gateway maintainers build and publish images to container registry
2. Your project pulls versioned images
3. Configuration via environment variables only
4. No build time in your deployment pipeline

**Pros**:
- Fast deployment (no build time)
- Consistent across environments
- Easy rollback (change image tag)
- Semantic versioning

**Cons**:
- Requires container registry
- Depends on gateway maintainers for releases

### Strategy 2: Build from Submodule (Development)

**Best for**: Local development, testing gateway changes

```yaml
# docker-compose.yml
services:
  api-gateway:
    build:
      context: ./gateway
      dockerfile: docker/Dockerfile
    image: myapp-gateway:dev
    env_file: .env.gateway
```

**Workflow**:
1. Submodule contains full gateway source
2. Docker Compose builds image locally
3. Useful for testing gateway updates before they're published

**Pros**:
- No external dependencies
- Test gateway changes locally
- Full control over build process

**Cons**:
- Slower deployment (build time)
- Larger repository size
- Not recommended for production

### Strategy 3: Clean Archive Extraction (Advanced)

**Best for**: Restricted environments, air-gapped deployments

```bash
#!/bin/bash
# deploy.sh

# Extract only production files (uses export-ignore)
cd gateway
git archive --format=tar --prefix=gateway-prod/ HEAD | tar -x -C ..
cd ..

# Build from clean archive
docker build -f gateway-prod/docker/Dockerfile -t myapp-gateway:latest gateway-prod/

# Deploy
docker-compose -f docker-compose.prod.yml up -d
```

**Workflow**:
1. Create archive excluding test files
2. Build image from clean archive
3. Deploy without test overhead

**Pros**:
- Minimal deployment size
- Clean separation of concerns
- No test files in production

**Cons**:
- More complex deployment script
- Requires git archive support

## Updating the Gateway

### Checking for Updates

```bash
# Navigate to submodule
cd gateway

# Fetch latest changes
git fetch

# Check what's new
git log HEAD..origin/main --oneline

# View changelog
git show origin/main:CHANGELOG.md
```

### Updating to Latest Version

```bash
# In submodule directory
cd gateway

# Pull latest changes
git checkout main
git pull origin main

# Return to project root
cd ..

# Commit the updated submodule reference
git add gateway
git commit -m "Update NGINX gateway to v1.2.0"

# Test the updated gateway
docker-compose up --build -d
docker-compose exec api-gateway nginx -t
```

### Updating to Specific Version

```bash
# In submodule directory
cd gateway

# Fetch all tags
git fetch --tags

# Checkout specific version
git checkout v1.2.0

# Return to project root
cd ..

# Commit the version reference
git add gateway
git commit -m "Update NGINX gateway to v1.2.0"
```

### Keeping Track of Gateway Version

```bash
# Check current gateway version
git submodule status

# Output:
# f1a2b3c4d5e6f7g8h9i0j1k2 gateway (v1.2.0)
#                                      ^^^^^^ Version tag
```

## Best Practices

### 1. Never Modify Submodule Files Directly

**❌ DON'T**:
```bash
# Don't edit files inside submodule
cd gateway
nano nginx/nginx.conf  # ❌ Changes will be lost on update
```

**✅ DO**:
```bash
# Configure via environment variables in project root
nano .env.gateway  # ✅ Your project-specific config
```

**Why**: Modifications inside the submodule will conflict with upstream updates.

### 2. Keep Configuration Outside Submodule

**Project Structure**:
```
your-project/
├── gateway/                     # Submodule (DON'T MODIFY)
│   ├── docker/
│   ├── nginx/
│   └── ...
├── .env.gateway                 # ✅ Your configuration
├── docker-compose.yml           # ✅ Your orchestration
└── backend/                     # Your application code
```

### 3. Pin Gateway Versions in Production

```yaml
# ❌ Bad - uses latest
services:
  api-gateway:
    image: yourregistry/nginx-gateway:latest

# ✅ Good - pins specific version
services:
  api-gateway:
    image: yourregistry/nginx-gateway:1.2.0
```

### 4. Test Gateway Updates Before Production

```bash
# Test in development environment first
cd your-project
git checkout develop
cd gateway
git pull origin main
cd ..
docker-compose up --build -d

# Run tests
./run-integration-tests.sh

# If successful, promote to production
git checkout main
git merge develop
git push origin main
```

### 5. Document Your Gateway Configuration

Create a `GATEWAY_CONFIG.md` in your project:

```markdown
# Gateway Configuration for MyApp

## Current Version
- Gateway Version: v1.2.0
- Last Updated: 2025-11-06

## Backend Services
- BACKEND_1: auth-service (port 8000) - User authentication
- BACKEND_2: api-service (port 8001) - Main API

## Frontend
- FRONTEND_URL: https://app.mycompany.com

## Custom Routes
- /api/users/* → auth-service
- /api/products/* → api-service
- /api/public/* → api-service (no auth required)

## File Upload
- MAX_UPLOAD_SIZE: 200M
- Upload route: /api/upload

## Known Issues
- None

## Update History
- 2025-11-06: Updated to v1.2.0 (added WebSocket support)
- 2025-10-15: Initial integration v1.0.0
```

### 6. Use .gitignore for Environment Files

```bash
# your-project/.gitignore

# Gateway configuration (contains secrets)
.env.gateway
.env.gateway.local
.env.gateway.production

# Docker volumes
uploads/
```

### 7. Automate Submodule Updates in CI/CD

```yaml
# .github/workflows/update-gateway.yml
name: Update Gateway

on:
  schedule:
    - cron: '0 0 * * 0'  # Weekly on Sunday

jobs:
  update-gateway:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
        with:
          submodules: recursive

      - name: Update gateway submodule
        run: |
          cd gateway
          git checkout main
          git pull origin main
          cd ..

      - name: Test updated gateway
        run: |
          docker-compose up -d
          sleep 10
          curl -f http://localhost:9090/health
          docker-compose down

      - name: Create PR if updated
        uses: peter-evans/create-pull-request@v4
        with:
          commit-message: 'chore: Update NGINX gateway submodule'
          title: 'Update NGINX Gateway to Latest'
          body: 'Automated update of NGINX gateway submodule'
          branch: update-gateway
```

## Troubleshooting

### Issue 1: Submodule Directory is Empty

**Symptom**:
```bash
ls gateway/
# Empty directory
```

**Solution**:
```bash
# Initialize submodule
git submodule update --init --recursive

# Or if already initialized
git submodule update --recursive --remote
```

### Issue 2: "Cannot Modify Files in Submodule"

**Symptom**: You need to customize gateway configuration

**Solution**: Don't modify submodule files. Use environment variables:

```bash
# Configure via .env.gateway in project root
cp gateway/.env.example .env.gateway
nano .env.gateway  # Edit your configuration

# Reference in docker-compose.yml
services:
  api-gateway:
    env_file: .env.gateway
```

### Issue 3: Gateway Update Breaks Your Deployment

**Symptom**: After updating gateway submodule, deployment fails

**Solution**: Rollback to previous version

```bash
# Find previous working version
git log -p gateway

# Revert to specific commit
cd gateway
git checkout f1a2b3c4  # Previous working commit
cd ..

# Commit the rollback
git add gateway
git commit -m "Revert gateway to v1.1.0 (v1.2.0 breaks deployment)"

# Report issue to gateway maintainers
```

### Issue 4: "CORS Errors After Gateway Update"

**Symptom**: Frontend can't access API after gateway update

**Solution**: Verify FRONTEND_URL matches exactly

```bash
# Check current configuration
cat .env.gateway | grep FRONTEND_URL

# Ensure exact match (including protocol, port, no trailing slash)
FRONTEND_URL=https://app.mycompany.com  # ✅ Correct
FRONTEND_URL=http://app.mycompany.com   # ❌ Wrong protocol
FRONTEND_URL=https://app.mycompany.com/ # ❌ Trailing slash
```

### Issue 5: "File Upload Fails After Update"

**Symptom**: File uploads return 413 Request Entity Too Large

**Solution**: Verify MAX_UPLOAD_SIZE is set

```bash
# Check configuration
cat .env.gateway | grep MAX_UPLOAD_SIZE

# If not set, add it
echo "MAX_UPLOAD_SIZE=500M" >> .env.gateway

# Restart gateway
docker-compose restart api-gateway
```

### Issue 6: "Backend Service Not Found"

**Symptom**: Gateway returns 502 Bad Gateway

**Solution**: Ensure backend service names match

```bash
# Check docker-compose.yml service names
docker-compose ps

# Ensure BACKEND_1_HOST matches service name
# In .env.gateway:
BACKEND_1_HOST=auth-service  # Must match service name in docker-compose.yml

# In docker-compose.yml:
services:
  auth-service:  # Service name must match BACKEND_1_HOST
    build: ./backend/auth
```

## Summary

### Key Takeaways

1. **Submodule = External Repository Link**: The `gateway/` directory is a reference to the gateway repository
2. **export-ignore = Clean Archives**: Use `git archive` to extract only production files
3. **Configuration Outside Submodule**: Keep `.env.gateway` and `docker-compose.yml` in project root
4. **Never Modify Submodule Files**: Configure via environment variables only
5. **Use Pre-Built Images in Production**: Faster, more reliable deployments
6. **Pin Versions**: Never use `:latest` in production
7. **Test Updates**: Always test gateway updates in development before production

### Quick Reference Commands

```bash
# Add submodule
git submodule add <gateway-repo-url> gateway

# Initialize submodule (first time)
git submodule update --init --recursive

# Update submodule to latest
cd gateway && git pull origin main && cd ..

# Create clean archive (without test files)
cd gateway && git archive --format=tar HEAD | tar -x -C ../gateway-clean

# Check submodule version
git submodule status

# Test gateway
docker-compose exec api-gateway nginx -t

# View gateway logs
docker-compose logs -f api-gateway
```

### Next Steps

- Read [FILE_CLASSIFICATION.md](FILE_CLASSIFICATION.md) to understand what can be customized
- Review [README.md](README.md) for gateway features and capabilities
- Check [docker/README.md](docker/README.md) for Docker-specific details
- Review [nginx/README.md](nginx/README.md) for NGINX configuration details

---

**Need Help?**

- Gateway Issues: Open issue in gateway repository
- Integration Issues: Check this document's Troubleshooting section
- Configuration Questions: See [FILE_CLASSIFICATION.md](FILE_CLASSIFICATION.md)
