# NGINX API Gateway - Documentation Index

## Quick Links

- **[Integration Guide](INTEGRATION_GUIDE.md)** - All-in-one guide for using this gateway in your project
- **[Submodule Usage](SUBMODULE_USAGE.md)** - Detailed Git submodule setup and management
- **[File Classification](FILE_CLASSIFICATION.md)** - Understanding immutable vs customizable files
- **[Custom Routes Example](custom-routes-example.conf)** - Template for adding custom routes

## Deployment Strategies

### 1. Pre-Built Docker Images (Recommended for Production)
**Best for**: Production deployments, CI/CD pipelines

- Pull versioned images from registry
- Configure via environment variables only
- No source code needed in your project
- **Result**: Clean, fast deployments

See: [Integration Guide - Docker Images Strategy](INTEGRATION_GUIDE.md#strategy-1-pre-built-docker-images)

### 2. Git Archive Extraction (Clean Source Deployment)
**Best for**: Building from source without test files

- Uses `.gitattributes` export-ignore pattern
- Extracts only production files
- Test files, .claude/, etc. excluded
- **Result**: Minimal source footprint

See: [Integration Guide - Git Archive Strategy](INTEGRATION_GUIDE.md#strategy-2-git-archive-extraction)

### 3. Git Submodule (Full Repository)
**Best for**: Development, contributing back to gateway

- **Important**: Submodules clone the FULL repository
- `export-ignore` does NOT affect submodule pulls
- You WILL get test files, .claude/, etc. (this is normal Git behavior)
- **Result**: Complete gateway source for development

See: [Submodule Usage Guide](SUBMODULE_USAGE.md)

## Understanding Git Behavior

### Git Submodule vs Git Archive

**Common Misconception**: "export-ignore prevents test files in submodules"

**Reality**:
```bash
# Git submodule → Clones FULL repository
git submodule add <url> gateway
# Result: ALL files (test/, .claude/, docs/, everything)

# Git archive → Respects export-ignore
cd gateway && git archive --format=tar HEAD | tar -x -C ../clean
# Result: ONLY production files (excludes test/, .claude/, etc.)
```

**Key Point**: Use the right tool for your use case:
- Want full source? → Git submodule
- Want clean deployment? → Git archive or pre-built images

## Which Guide Should I Read?

| Your Situation | Recommended Reading |
|----------------|---------------------|
| "I want to deploy this gateway quickly" | [Integration Guide](INTEGRATION_GUIDE.md) |
| "I'm using this as a Git submodule" | [Submodule Usage](SUBMODULE_USAGE.md) |
| "Which files can I modify?" | [File Classification](FILE_CLASSIFICATION.md) |
| "I need custom routes" | [Custom Routes Example](custom-routes-example.conf) |
| "I want all info in one place" | [Integration Guide](INTEGRATION_GUIDE.md) |

## Documentation Organization

```
docs/
├── README.md (this file)           # Documentation index
├── INTEGRATION_GUIDE.md            # All-in-one deployment guide
├── SUBMODULE_USAGE.md              # Detailed Git submodule guide  
├── FILE_CLASSIFICATION.md          # Immutable vs customizable files
└── custom-routes-example.conf      # Custom routes template
```

## Quick Start

**For most projects**:
1. Read [Integration Guide](INTEGRATION_GUIDE.md) - 5 min
2. Choose deployment strategy
3. Follow strategy-specific steps
4. Deploy!

**For Git submodule users**:
1. Understand that submodules pull ALL files (this is normal)
2. Follow [Submodule Usage](SUBMODULE_USAGE.md)
3. Use git archive for clean deployments if needed

---

**Back to**: [Main README](../README.md)
