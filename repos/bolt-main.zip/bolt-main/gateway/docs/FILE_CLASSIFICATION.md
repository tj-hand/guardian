# File Classification: Immutable vs Customizable

## Overview

This document classifies all files in the NGINX API Gateway project into three categories for multi-project usage:

1. **IMMUTABLE**: Core gateway functionality that must NEVER be modified
2. **CUSTOMIZABLE**: Configuration that should be adapted per project
3. **OPTIONAL**: Test/development files not needed in production

**Purpose**: Help projects understand what provides value (don't touch) vs what needs configuration (customize).

## Table of Contents

- [Quick Reference](#quick-reference)
- [NGINX Configuration Files](#nginx-configuration-files)
- [Docker Configuration Files](#docker-configuration-files)
- [Environment Configuration](#environment-configuration)
- [Test Files](#test-files)
- [Documentation Files](#documentation-files)
- [Customization Strategies](#customization-strategies)
- [What Makes This Gateway Valuable](#what-makes-this-gateway-valuable)

## Quick Reference

### Files You Should NEVER Modify

| File | Why Immutable | Modification Impact |
|------|---------------|---------------------|
| `nginx/nginx.conf` | Core performance, security, and operational settings | Breaks gateway optimizations |
| `docker/Dockerfile` | Gateway container image definition | Breaks security and build process |
| `docker/docker-entrypoint.sh` | Runtime template processing logic | Breaks configuration system |
| `.dockerignore` | Build optimization | Increases image size |

### Files You MUST Customize

| File | How to Customize | Required Changes |
|------|------------------|------------------|
| `.env` (copy from `.env.example`) | Copy to project root as `.env.gateway` | Set BACKEND_*_HOST, FRONTEND_URL |
| `docker-compose.yml` | Copy to project root and edit | Replace test services with your backends |

### Files You CAN Customize (Advanced)

| File | Customization Level | When to Customize |
|------|---------------------|-------------------|
| `nginx/conf.d/default.conf.template` | Moderate | Add routes, adjust rate limiting |

### Files You Should IGNORE

| File/Directory | Category | Reason |
|----------------|----------|--------|
| `test-frontend/` | Test Implementation | You have your own frontend |
| `test-backend/` | Test Implementation | You have your own backend |
| `tests/` | Test Suite | Gateway validation only |
| `.claude/` | Internal Development | Development workflow |
| `PROJECT_REPORT.md` | Internal Documentation | Delivery artifact |

## NGINX Configuration Files

### nginx/nginx.conf - Main NGINX Configuration

**Classification**: **IMMUTABLE (99%)** - Core Gateway Foundation

**Purpose**: Defines global NGINX settings that provide the gateway's core value.

**Immutable Aspects** (DO NOT MODIFY):

| Section | Lines | What It Does | Why Immutable |
|---------|-------|--------------|---------------|
| Worker Processes | 11-12 | Auto-scales to CPU cores | Already optimal |
| Events Block | 24-35 | Uses `epoll` for Linux performance | Optimized for throughput |
| MIME Types | 44-45 | Standard file type handling | Industry standard |
| Custom Log Format | 51-58 | Logs timing, proxy, upstream metrics | Provides observability |
| Performance Settings | 62-83 | `sendfile`, `tcp_nopush`, keepalive | Performance tuned |
| Gzip Compression | 110-130 | 60-80% bandwidth reduction | Standard optimization |
| Proxy Defaults | 133-147 | HTTP/1.1, connection pooling | Correct for all backends |
| Rate Limiting Zones | 161-176 | Defines `api_limit`, `auth_limit`, `upload_limit` | Used by location blocks |
| WebSocket Map | 189-193 | Enables WebSocket upgrade | Required for WS support |

**Why These Settings Matter**:

1. **Performance**: Gzip compression, sendfile, TCP optimizations reduce latency and bandwidth
2. **Security**: Rate limiting zones protect against abuse
3. **Observability**: Custom log format helps debug issues
4. **Compatibility**: Proper WebSocket and HTTP/1.1 support

**Buffer Sizes** (OPTIONAL to customize):
```nginx
# Lines 86-107
client_body_buffer_size 128k;      # API request buffering
proxy_buffers 32 8k;               # Proxy response buffering
```

**Only customize if**: Handling very large requests/responses (e.g., huge JSON payloads).

**File Upload Size** (CUSTOMIZABLE via environment):
```nginx
# Line 94 (handled via template in default.conf.template)
client_max_body_size 100m;  # Set via MAX_UPLOAD_SIZE env var
```

**Verdict**: **Leave this file unchanged.** All necessary customization happens via environment variables in `default.conf.template`.

---

### nginx/conf.d/default.conf.template - Server Block Configuration

**Classification**: **HYBRID** - 70% Immutable Structure, 30% Customizable Values

**Purpose**: Defines routing logic, backend connections, and request handling patterns.

#### Immutable Aspects (DO NOT MODIFY)

**1. Upstream Keepalive Configuration**
```nginx
# Lines 40-44, 57-60
upstream backend_1 {
    server ${BACKEND_1_HOST}:${BACKEND_1_PORT};
    keepalive 32;                    # ← IMMUTABLE: Performance optimization
    keepalive_requests 100;          # ← IMMUTABLE: Reduces connection overhead
    keepalive_timeout 60s;           # ← IMMUTABLE: Connection reuse
}
```
**Why**: These settings optimize backend connections, reducing latency and resource usage.

**2. Security Headers**
```nginx
# Lines 107-128
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Content-Security-Policy "default-src 'self'" always;
```
**Why**: These headers protect against XSS, clickjacking, and MIME sniffing attacks. **Core security value.**

**3. CORS Header Control**
```nginx
# Lines 137-142
proxy_hide_header Access-Control-Allow-Origin;
proxy_hide_header Access-Control-Allow-Methods;
proxy_hide_header Access-Control-Allow-Headers;
proxy_hide_header Access-Control-Allow-Credentials;
```
**Why**: Prevents duplicate CORS headers when backend also sets them. **Prevents CORS errors.**

**4. CORS Response Headers**
```nginx
# Lines 144-158
add_header Access-Control-Allow-Origin "${FRONTEND_URL}" always;
add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS" always;
add_header Access-Control-Allow-Headers "Authorization, Content-Type" always;
add_header Access-Control-Max-Age "3600" always;
```
**Why**: Centralizes CORS control at gateway. **Critical for frontend-backend communication.**

**5. OPTIONS Preflight Handling**
```nginx
# Pattern repeated in multiple location blocks
if ($request_method = 'OPTIONS') {
    add_header Access-Control-Allow-Origin "${FRONTEND_URL}" always;
    add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE" always;
    add_header Access-Control-Allow-Headers "Authorization, Content-Type" always;
    add_header Access-Control-Max-Age "3600" always;
    add_header Content-Length 0;
    return 204;
}
```
**Why**: CORS preflight requests must be handled correctly or browsers will block requests. **Critical pattern.**

**6. Authorization Header Forwarding**
```nginx
# Pattern repeated in all authenticated routes
proxy_set_header Authorization $http_authorization;
```
**Why**: Transparently forwards authentication tokens to backend. **Core gateway feature.**

**7. Proxy Header Preservation**
```nginx
# Pattern repeated in all routes
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
```
**Why**: Preserves client information for backend logging and logic. **Standard reverse proxy pattern.**

**8. Proxy Performance Settings**
```nginx
# Pattern repeated in routes
proxy_http_version 1.1;
proxy_set_header Connection "";
proxy_buffering on;
proxy_connect_timeout 60s;
proxy_send_timeout 60s;
proxy_read_timeout 60s;
```
**Why**: Optimized for HTTP/1.1 keepalive and reasonable timeouts. **Performance tuned.**

**9. Rate Limiting Application**
```nginx
# Applied per location block
limit_req zone=api_limit burst=20 nodelay;    # API routes: 10 req/s
limit_req zone=auth_limit burst=10 nodelay;   # Auth routes: 5 req/s
limit_req zone=upload_limit burst=2 nodelay;  # Upload routes: 2 req/s
```
**Why**: Protects against abuse and DDoS. **Security pattern.**

**10. File Upload Optimization**
```nginx
# Lines 553-590
location /api/upload {
    proxy_buffering off;                    # ← IMMUTABLE: Stream large uploads
    proxy_request_buffering off;            # ← IMMUTABLE: Don't buffer to disk
    client_max_body_size ${MAX_UPLOAD_SIZE};  # ← CUSTOMIZABLE via env var
    proxy_connect_timeout 300s;             # ← IMMUTABLE: Extended timeout
    proxy_send_timeout 300s;
    proxy_read_timeout 300s;
}
```
**Why**: Optimized for large file uploads without memory/disk issues. **Performance critical.**

**11. Health Check Endpoint**
```nginx
# Lines 743-775 - Separate server block
server {
    listen 8080;
    location /health {
        access_log off;
        return 200 "OK\n";
    }
}
```
**Why**: Separate port for orchestration health checks (Docker, Kubernetes, etc.). **Standard pattern.**

#### Customizable Aspects (MODIFY FOR YOUR PROJECT)

**1. Backend Upstream Addresses**
```nginx
# Lines 30-87
upstream backend_1 {
    server ${BACKEND_1_HOST}:${BACKEND_1_PORT};  # ← CUSTOMIZE via env vars
}

upstream backend_2 {
    server ${BACKEND_2_HOST}:${BACKEND_2_PORT};  # ← CUSTOMIZE via env vars
}
```
**How to Customize**: Set in `.env` file:
```bash
BACKEND_1_HOST=your-auth-service
BACKEND_1_PORT=8000
BACKEND_2_HOST=your-api-service
BACKEND_2_PORT=8001
```

**2. Frontend CORS Origin**
```nginx
# Lines 144-158
add_header Access-Control-Allow-Origin "${FRONTEND_URL}" always;  # ← CUSTOMIZE
```
**How to Customize**: Set in `.env` file:
```bash
FRONTEND_URL=https://app.yourcompany.com
```
**CRITICAL**: Must match frontend domain exactly (protocol, no trailing slash).

**3. Route Paths** (Advanced)
```nginx
# Example: Change API prefix from /api/users to /v1/users
location /v1/users/ {
    # Keep pattern, change path only
    proxy_pass http://backend_1/v1/users/;
    # ... keep all proxy settings
}
```
**When to Customize**: Your API uses different path conventions.

**4. File Upload Size Limit**
```nginx
# Line 567
client_max_body_size ${MAX_UPLOAD_SIZE};  # ← CUSTOMIZE via env var
```
**How to Customize**: Set in `.env` file:
```bash
MAX_UPLOAD_SIZE=500M  # For video uploads
```

**5. Additional Routes**

Add new location blocks following existing patterns:

```nginx
# Add after existing routes
location /api/your-new-service/ {
    # Apply rate limiting (choose appropriate zone)
    limit_req zone=api_limit burst=20 nodelay;

    # Handle OPTIONS (COPY PATTERN - DON'T MODIFY)
    if ($request_method = 'OPTIONS') {
        add_header Access-Control-Allow-Origin "${FRONTEND_URL}" always;
        add_header Access-Control-Allow-Methods "GET, POST" always;
        add_header Access-Control-Allow-Headers "Authorization, Content-Type" always;
        return 204;
    }

    # Proxy to backend (KEEP PATTERN - CHANGE TARGET ONLY)
    proxy_pass http://backend_1/api/your-new-service/;

    # Proxy headers (COPY EXACTLY - DON'T MODIFY)
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header Authorization $http_authorization;

    # Performance settings (COPY EXACTLY)
    proxy_http_version 1.1;
    proxy_set_header Connection "";
    proxy_buffering on;
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;
}
```

**Verdict**: **Template structure is immutable (patterns), values are customizable (via environment variables or careful route additions).**

---

## Docker Configuration Files

### docker/Dockerfile - Gateway Container Image

**Classification**: **IMMUTABLE (100%)** - Core Image Definition

**Purpose**: Builds production-ready NGINX gateway container with security hardening and optimization.

**Key Features**:
```dockerfile
# Line 5: Base image
FROM nginx:1.27-alpine AS base  # ← IMMUTABLE: Minimal, secure, 25MB

# Lines 9-12: Essential tools
RUN apk add --no-cache \
    curl \              # ← Health checks
    ca-certificates \   # ← HTTPS backend support
    gettext \           # ← envsubst for templates

# Lines 19-22: NGINX configuration
COPY nginx/nginx.conf /etc/nginx/nginx.conf
COPY nginx/conf.d/default.conf.template /etc/nginx/conf.d/

# Lines 29-33: Security (non-root user)
USER nginx

# Lines 40-43: Health check
HEALTHCHECK --interval=30s --timeout=10s --retries=3 \
  CMD curl -f http://localhost:8080/health || exit 1

# Line 46: Entrypoint
ENTRYPOINT ["/docker-entrypoint.sh"]
CMD ["nginx", "-g", "daemon off;"]
```

**Why Immutable**:
1. **Security**: Non-root user, minimal attack surface
2. **Performance**: Multi-stage build, layer optimization
3. **Reliability**: Health checks, fail-fast behavior
4. **Standardization**: Consistent across all projects

**What Projects Should Do**:
- **Pull pre-built images**: `image: yourregistry/nginx-gateway:1.0.0`
- **Never modify**: Use as-is
- **If customization needed**: Fork repository, maintain separate version

**Verdict**: **100% immutable. Projects should use pre-built images, not modify Dockerfile.**

---

### docker/docker-entrypoint.sh - Container Startup Script

**Classification**: **IMMUTABLE (100%)** - Runtime Template Processor

**Purpose**: Processes NGINX template files with environment variable substitution at container startup.

**Key Functions**:
```bash
# Lines 28-42: Set default environment variables
: ${BACKEND_1_HOST:=test-backend-1}
: ${BACKEND_1_PORT:=3001}
: ${FRONTEND_URL:=http://localhost}
: ${MAX_UPLOAD_SIZE:=100M}

# Lines 52-59: Process templates
envsubst '$BACKEND_1_HOST $BACKEND_1_PORT $FRONTEND_URL ...' \
  < /etc/nginx/conf.d/default.conf.template \
  > /etc/nginx/conf.d/default.conf

# Lines 63-69: NGINX variable escaping
sed -i 's/\$\$/$/g' /etc/nginx/conf.d/default.conf

# Lines 73-79: Validate configuration
nginx -t

# Lines 83-86: Start NGINX
exec nginx -g 'daemon off;'
```

**Why Immutable**:
1. **Critical Logic**: Template substitution enables environment-based configuration
2. **Fail-Fast**: Validates config before starting NGINX
3. **Variable Escaping**: Prevents NGINX variables from being substituted
4. **Signal Handling**: Proper shutdown via `exec`

**What Projects Should Do**:
- **Understand**: Know that this processes `*.conf.template` files
- **Provide Variables**: Set environment variables in docker-compose or cloud platform
- **Never Modify**: Script is baked into Docker image

**Verdict**: **100% immutable. Customization via environment variables only.**

---

### docker-compose.yml - Service Orchestration

**Classification**: **CUSTOMIZABLE REFERENCE** - Copy & Modify

**Purpose**: Example orchestration showing how to deploy gateway with test services.

**What to Keep** (Pattern):
```yaml
services:
  api-gateway:
    # Gateway service definition pattern
    ports:
      - "8080:80"     # Main traffic
      - "9090:8080"   # Health checks
    env_file:
      - .env          # ← Pattern: Load from env file
    depends_on:
      - backend-service
    networks:
      - app-network
    volumes:
      - uploads:/var/www/uploads
```

**What to Change** (Values):
```yaml
services:
  api-gateway:
    # Change: Use pre-built image instead of build
    image: yourregistry/nginx-gateway:1.0.0  # ← CHANGE THIS

    # Change: Your env file location
    env_file:
      - .env.gateway  # ← Your project-specific env file

    # Change: Your backend services
    depends_on:
      your-auth-service:      # ← Your real services
        condition: service_healthy
      your-api-service:
        condition: service_healthy

  # Remove: Test services (NOT NEEDED IN PRODUCTION)
  # test-frontend:
  # test-backend-1:
  # test-backend-2:

  # Add: Your backend services
  your-auth-service:
    build: ./backend/auth
    # ... your configuration

  your-api-service:
    build: ./backend/api
    # ... your configuration
```

**What Projects Should Do**:
1. **Copy** `docker-compose.yml` to project root (outside submodule)
2. **Replace** test services with real backends
3. **Update** environment configuration
4. **Adjust** ports to avoid conflicts
5. **Add** project-specific services

**Verdict**: **Use as reference template, customize completely for your project.**

---

## Environment Configuration

### .env.example - Configuration Template

**Classification**: **CUSTOMIZABLE (100%)** - Primary Configuration Interface

**Purpose**: Documents all environment variables supported by the gateway.

**Required Variables** (MUST CUSTOMIZE):

| Variable | Description | Example | Security Impact |
|----------|-------------|---------|-----------------|
| `BACKEND_1_HOST` | Primary backend hostname | `auth-service` | Medium - routing |
| `BACKEND_1_PORT` | Primary backend port | `8000` | Low |
| `FRONTEND_URL` | CORS origin | `https://app.example.com` | **HIGH** - Who can access gateway |

**Optional Variables** (Sensible Defaults):

| Variable | Default | When to Change |
|----------|---------|----------------|
| `MAX_UPLOAD_SIZE` | `100M` | Handling larger files (videos, archives) |
| `BACKEND_2_HOST` | `test-backend-2` | Multiple backend services |
| `BACKEND_2_PORT` | `3002` | Multiple backend services |

**How to Use**:
```bash
# In your project root (OUTSIDE submodule)
cp gateway/.env.example .env.gateway

# Edit with your values
nano .env.gateway

# Reference in docker-compose.yml
services:
  api-gateway:
    env_file: .env.gateway
```

**Verdict**: **Copy to project root as `.env.gateway` and customize all values.**

---

## Test Files

### Test Implementation Files

**Classification**: **OPTIONAL TEST** - Ignore for Production

| File/Directory | Purpose | Production Needed? |
|----------------|---------|-------------------|
| `test-frontend/` | Minimal frontend for testing CORS, file uploads | ❌ No (you have your own frontend) |
| `test-backend/` | Minimal Node.js backend for testing routing | ❌ No (you have your own backend) |
| `tests/` | Playwright & Bash E2E test suites | ❌ No (gateway validation only) |
| `playwright.config.js` | Playwright configuration | ❌ No (test tooling) |
| `package.json` | Test dependencies (Playwright) | ❌ No (development only) |
| `package-lock.json` | Lockfile for test dependencies | ❌ No (development only) |
| `Makefile` | Development commands | ❌ No (developer convenience) |

**What Projects Should Do**:
- **Ignore completely**: These files are for gateway development/testing
- **Not needed**: Projects have their own frontend, backend, and tests
- **Already excluded**: Marked with `export-ignore` in `.gitattributes`

**Clean Deployment**:
```bash
# Create archive without test files
cd gateway
git archive --format=tar HEAD | tar -x -C ../gateway-clean
cd ../gateway-clean
ls
# Output: docker/, nginx/, .env.example, README.md (NO test files)
```

**Verdict**: **Ignore all test files. Only useful for gateway maintainers.**

---

## Documentation Files

### Documentation Classification

| File | Category | Production Needed? | Purpose |
|------|----------|-------------------|---------|
| `README.md` | **KEEP** | ✅ Yes | Usage instructions, configuration guide |
| `SUBMODULE_USAGE.md` | **KEEP** | ✅ Yes | How to use as Git submodule |
| `FILE_CLASSIFICATION.md` | **KEEP** | ✅ Yes | This file - understanding customization |
| `.claude/CLAUDE.md` | **IGNORE** | ❌ No | AI agent orchestration (internal) |
| `PROJECT_REPORT.md` | **IGNORE** | ❌ No | Delivery report (internal) |
| `docker/README.md` | **KEEP** | ✅ Optional | Docker-specific details |
| `nginx/README.md` | **KEEP** | ✅ Optional | NGINX-specific details |

**What Projects Should Do**:
- **Read**: README.md, SUBMODULE_USAGE.md, FILE_CLASSIFICATION.md
- **Reference**: Keep documentation accessible for troubleshooting
- **Ignore**: .claude/, PROJECT_REPORT.md (internal development)

---

## Customization Strategies

### Strategy 1: Environment Variables Only (Recommended)

**Best for**: 90% of projects

**What to Customize**:
- `.env.gateway` (copy from `gateway/.env.example`)

**What NOT to Touch**:
- Any files inside `gateway/` submodule

**Example**:
```bash
# In your project root
cp gateway/.env.example .env.gateway

# Customize
cat > .env.gateway <<EOF
BACKEND_1_HOST=auth-service
BACKEND_1_PORT=8000
BACKEND_2_HOST=api-service
BACKEND_2_PORT=8001
FRONTEND_URL=https://app.mycompany.com
MAX_UPLOAD_SIZE=200M
EOF

# Reference in docker-compose.yml
services:
  api-gateway:
    image: yourregistry/nginx-gateway:1.0.0
    env_file: .env.gateway
```

**Pros**:
- Simple, no code changes
- Easy to update gateway version
- Clean separation of concerns

**Cons**:
- Limited to predefined configuration options

---

### Strategy 2: Add Routes to Template (Advanced)

**Best for**: Projects with custom API paths or additional backends

**What to Customize**:
- `nginx/conf.d/default.conf.template` (carefully)

**Rules**:
1. **Keep all immutable patterns** (CORS, proxy headers, security)
2. **Only add new location blocks** or modify route paths
3. **Test thoroughly** before deploying

**Example**:
```nginx
# Add after existing routes in default.conf.template

# Custom route for analytics service
location /api/analytics/ {
    # KEEP: Rate limiting pattern
    limit_req zone=api_limit burst=20 nodelay;

    # KEEP: OPTIONS handling (COPY EXACTLY)
    if ($request_method = 'OPTIONS') {
        add_header Access-Control-Allow-Origin "${FRONTEND_URL}" always;
        add_header Access-Control-Allow-Methods "GET, POST" always;
        add_header Access-Control-Allow-Headers "Authorization, Content-Type" always;
        return 204;
    }

    # CUSTOMIZE: Proxy target only
    proxy_pass http://backend_2/analytics/;

    # KEEP: All proxy headers and settings (COPY EXACTLY)
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header Authorization $http_authorization;

    proxy_http_version 1.1;
    proxy_set_header Connection "";
    proxy_buffering on;
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;
}
```

**Pros**:
- Full control over routing
- Can add custom backends

**Cons**:
- Requires understanding NGINX patterns
- Must maintain on gateway updates
- Risk of breaking immutable patterns

---

### Strategy 3: Fork Repository (Expert)

**Best for**: Projects needing major structural changes

**When to Use**:
- Need different base image
- Require additional NGINX modules
- Fundamentally different routing architecture

**Process**:
1. Fork gateway repository
2. Make changes in your fork
3. Use your fork as submodule source
4. Maintain your version separately

**Example**:
```bash
# Fork repository on GitHub
# Clone your fork
git clone https://github.com/yourorg/nginx_api_gateway-custom.git

# Add as submodule in project
git submodule add https://github.com/yourorg/nginx_api_gateway-custom.git gateway
```

**Pros**:
- Complete control
- Can make structural changes

**Cons**:
- Responsibility for maintenance
- Harder to merge upstream updates
- Lose benefit of upstream improvements

---

## What Makes This Gateway Valuable

### Core Value Propositions (IMMUTABLE)

These are the reasons to use this gateway. Modifying these aspects removes the gateway's value:

1. **Production-Ready Security**
   - Security headers (X-Content-Type-Options, CSP, X-Frame-Options)
   - CORS header centralization (prevents duplicates)
   - Rate limiting patterns (prevents abuse)
   - Non-root container execution

2. **Performance Optimization**
   - Gzip compression (60-80% bandwidth reduction)
   - HTTP/1.1 keepalive (reduces connection overhead)
   - Optimal buffer sizes (low memory usage)
   - Efficient file upload/download handling

3. **Transparent Authentication**
   - Forwards Authorization headers to backends
   - No token validation at gateway (backend responsibility)
   - Supports any authentication scheme (JWT, Bearer, etc.)

4. **Multi-Backend Routing**
   - Path-based routing to multiple services
   - Upstream connection pooling
   - Health-check aware dependencies

5. **Cloud-Native Design**
   - Container health checks
   - Environment-based configuration
   - Separate health check port (8080)
   - Graceful shutdown handling

6. **Observability**
   - Custom access logs with timing metrics
   - Error logging with context
   - Request/response size tracking

### What Projects Must Provide (CUSTOMIZABLE)

These are project-specific values that the gateway cannot provide:

1. **Backend Service Addresses**
   - Your microservices hostnames and ports
   - Backend health check endpoints

2. **Frontend Domain**
   - CORS origin for your frontend
   - Exact domain match (protocol, no trailing slash)

3. **Business Logic Routes** (Optional)
   - API paths matching your application
   - Rate limiting per endpoint

4. **File Upload Limits**
   - Size limits based on use case
   - Video uploads vs document uploads

## Summary Tables

### Files Never to Modify

| File | Immutable % | Reason |
|------|-------------|--------|
| `nginx/nginx.conf` | 99% | Core performance, security, operational settings |
| `docker/Dockerfile` | 100% | Gateway container image definition |
| `docker/docker-entrypoint.sh` | 100% | Runtime template processor |
| `.dockerignore` | 100% | Build optimization |

### Files to Customize

| File | Customization Method | When |
|------|---------------------|------|
| `.env.example` | Copy to `.env.gateway`, edit values | Always (required) |
| `docker-compose.yml` | Copy to project root, modify | Always (orchestration) |
| `nginx/conf.d/default.conf.template` | Carefully add routes | Optional (advanced) |

### Files to Ignore

| File/Directory | Reason to Ignore |
|----------------|------------------|
| `test-frontend/`, `test-backend/`, `tests/` | Test implementations (not production) |
| `.claude/`, `PROJECT_REPORT.md` | Internal development artifacts |
| `package.json`, `playwright.config.js`, `Makefile` | Development tooling |

### Configuration Hierarchy

```
Immutable Core (Gateway Value)
    ↓
nginx/nginx.conf                    # Global NGINX settings
    ↓
nginx/conf.d/default.conf.template  # Routing patterns
    ↓
Customizable Values (Project-Specific)
    ↓
.env.gateway                        # Backend URLs, CORS origin
    ↓
docker-compose.yml                  # Service orchestration
```

## Best Practices

### ✅ DO

1. **Configure via Environment Variables**
   - Set all values in `.env.gateway`
   - Never hardcode in docker-compose.yml

2. **Copy Configuration Files to Project Root**
   - `.env.gateway` (from `gateway/.env.example`)
   - `docker-compose.yml` (customized version)

3. **Use Pre-Built Images in Production**
   - `image: yourregistry/nginx-gateway:1.0.0`
   - Pin specific versions (not `:latest`)

4. **Test Gateway Updates in Development First**
   - Pull new gateway version
   - Test thoroughly
   - Then promote to production

5. **Document Your Customizations**
   - Which routes you added
   - Which backends you configured
   - Any deviations from defaults

### ❌ DON'T

1. **Don't Modify Files Inside `gateway/` Submodule**
   - Changes will be lost on update
   - Breaks upstream sync

2. **Don't Remove Immutable Patterns**
   - CORS header hiding
   - OPTIONS preflight handling
   - Security headers
   - Proxy header forwarding

3. **Don't Use `:latest` Tag in Production**
   - Pin specific versions
   - Easier rollback on issues

4. **Don't Include Test Files in Production**
   - Use `git archive` for clean extraction
   - Or pull pre-built images (no source needed)

5. **Don't Skip Testing After Updates**
   - Always test in dev/staging first
   - Verify CORS, routing, file uploads

## Next Steps

1. **Understand Submodule Usage**: Read [SUBMODULE_USAGE.md](SUBMODULE_USAGE.md)
2. **Review Gateway Features**: Read [README.md](README.md)
3. **Examine NGINX Config**: Check `nginx/conf.d/default.conf.template` patterns
4. **Plan Your Customization**: Decide which strategy (env vars only, add routes, or fork)
5. **Test Integration**: Set up in development environment first

---

**Questions?**

- **Configuration**: See `.env.example` for all available options
- **Routing**: See `nginx/conf.d/default.conf.template` for patterns
- **Deployment**: See [SUBMODULE_USAGE.md](SUBMODULE_USAGE.md) for integration guide
- **Issues**: Check README.md troubleshooting section
