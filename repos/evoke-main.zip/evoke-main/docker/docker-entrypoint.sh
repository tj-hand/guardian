#!/bin/sh
set -e

# Evoke Docker Entrypoint
# Processes nginx configuration template with environment variables

# Default values for environment variables
export BOLT_GATEWAY_HOST="${BOLT_GATEWAY_HOST:-bolt-gateway}"
export BOLT_GATEWAY_PORT="${BOLT_GATEWAY_PORT:-80}"
export API_PATH_PREFIX="${API_PATH_PREFIX:-/api}"

echo "Evoke API Client - Starting..."
echo "  BOLT_GATEWAY_HOST: ${BOLT_GATEWAY_HOST}"
echo "  BOLT_GATEWAY_PORT: ${BOLT_GATEWAY_PORT}"
echo "  API_PATH_PREFIX: ${API_PATH_PREFIX}"

# Process nginx template with envsubst
# Only substitute our custom variables, preserving nginx's $host, $remote_addr, etc.
envsubst '${BOLT_GATEWAY_HOST} ${BOLT_GATEWAY_PORT} ${API_PATH_PREFIX}' \
    < /etc/nginx/templates/default.conf.template \
    > /etc/nginx/conf.d/default.conf

echo "  Nginx configuration generated from template"

# Check if custom routes directory has any configurations
if [ -d /etc/nginx/conf.d/custom-routes ] && [ "$(ls -A /etc/nginx/conf.d/custom-routes/*.conf 2>/dev/null)" ]; then
    echo "  Custom routes loaded from /etc/nginx/conf.d/custom-routes/"
fi

# Test nginx configuration
nginx -t

echo "  Nginx configuration test passed"
echo "  Starting nginx..."

# Execute the CMD (nginx)
exec "$@"
