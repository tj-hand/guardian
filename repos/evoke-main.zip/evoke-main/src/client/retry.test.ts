/**
 * Retry Logic Tests
 * EVOKE-019: Auto-retry failed requests with exponential backoff
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import {
  isRetryableError,
  calculateBackoff,
  parseRetryAfter,
  delay,
  shouldRetry,
  getRetryDelay,
  mergeRetryConfig,
  withRetry,
  createRetryWrapper,
  DEFAULT_RETRY_CONFIG,
  type RetryConfig,
} from './retry'
import { ApiError, ErrorCode, NetworkError, TimeoutError } from '../types'

describe('Retry Utilities', () => {
  describe('isRetryableError', () => {
    it('should return true for network errors', () => {
      const error = new NetworkError('Network failed')
      expect(isRetryableError(error)).toBe(true)
    })

    it('should return true for timeout errors', () => {
      const error = new TimeoutError('Request timed out')
      expect(isRetryableError(error)).toBe(true)
    })

    it('should return true for 500 internal server error', () => {
      const error = new ApiError('Server error', ErrorCode.INTERNAL_SERVER_ERROR, { status: 500 })
      expect(isRetryableError(error)).toBe(true)
    })

    it('should return true for 502 bad gateway', () => {
      const error = new ApiError('Bad gateway', ErrorCode.UNKNOWN_ERROR, { status: 502 })
      expect(isRetryableError(error)).toBe(true)
    })

    it('should return true for 503 service unavailable', () => {
      const error = new ApiError('Service unavailable', ErrorCode.SERVICE_UNAVAILABLE, { status: 503 })
      expect(isRetryableError(error)).toBe(true)
    })

    it('should return true for 504 gateway timeout', () => {
      const error = new ApiError('Gateway timeout', ErrorCode.UNKNOWN_ERROR, { status: 504 })
      expect(isRetryableError(error)).toBe(true)
    })

    it('should return true for 429 too many requests', () => {
      const error = new ApiError('Rate limited', ErrorCode.TOO_MANY_REQUESTS, { status: 429 })
      expect(isRetryableError(error)).toBe(true)
    })

    it('should return false for 400 bad request', () => {
      const error = new ApiError('Bad request', ErrorCode.BAD_REQUEST, { status: 400 })
      expect(isRetryableError(error)).toBe(false)
    })

    it('should return false for 401 unauthorized', () => {
      const error = new ApiError('Unauthorized', ErrorCode.UNAUTHORIZED, { status: 401 })
      expect(isRetryableError(error)).toBe(false)
    })

    it('should return false for 403 forbidden', () => {
      const error = new ApiError('Forbidden', ErrorCode.FORBIDDEN, { status: 403 })
      expect(isRetryableError(error)).toBe(false)
    })

    it('should return false for 404 not found', () => {
      const error = new ApiError('Not found', ErrorCode.NOT_FOUND, { status: 404 })
      expect(isRetryableError(error)).toBe(false)
    })

    it('should return false for 422 validation error', () => {
      const error = new ApiError('Validation failed', ErrorCode.VALIDATION_ERROR, { status: 422 })
      expect(isRetryableError(error)).toBe(false)
    })
  })

  describe('calculateBackoff', () => {
    const config: RetryConfig = {
      maxRetries: 3,
      baseDelay: 1000,
      maxDelay: 30000,
      backoffMultiplier: 2,
      jitter: false,
    }

    it('should calculate exponential backoff correctly', () => {
      expect(calculateBackoff(0, config)).toBe(1000) // 1000 * 2^0
      expect(calculateBackoff(1, config)).toBe(2000) // 1000 * 2^1
      expect(calculateBackoff(2, config)).toBe(4000) // 1000 * 2^2
      expect(calculateBackoff(3, config)).toBe(8000) // 1000 * 2^3
    })

    it('should cap delay at maxDelay', () => {
      const shortMaxConfig = { ...config, maxDelay: 3000 }
      expect(calculateBackoff(0, shortMaxConfig)).toBe(1000)
      expect(calculateBackoff(1, shortMaxConfig)).toBe(2000)
      expect(calculateBackoff(2, shortMaxConfig)).toBe(3000) // Capped
      expect(calculateBackoff(3, shortMaxConfig)).toBe(3000) // Capped
    })

    it('should add jitter when enabled', () => {
      const jitterConfig = { ...config, jitter: true }
      const results: number[] = []

      // Run multiple times to check randomness
      for (let i = 0; i < 10; i++) {
        results.push(calculateBackoff(1, jitterConfig))
      }

      // With jitter, delay should be within ±25% of base (1500 to 2500 for attempt 1)
      results.forEach((result) => {
        expect(result).toBeGreaterThanOrEqual(1500)
        expect(result).toBeLessThanOrEqual(2500)
      })

      // Check that not all values are the same (randomness)
      const uniqueValues = new Set(results)
      expect(uniqueValues.size).toBeGreaterThan(1)
    })
  })

  describe('parseRetryAfter', () => {
    it('should parse seconds value', () => {
      expect(parseRetryAfter('30')).toBe(30000) // 30 seconds in ms
      expect(parseRetryAfter('1')).toBe(1000)
      expect(parseRetryAfter('120')).toBe(120000)
    })

    it('should return null for zero or negative seconds', () => {
      expect(parseRetryAfter('0')).toBe(null)
      expect(parseRetryAfter('-5')).toBe(null)
    })

    it('should return null for invalid values', () => {
      expect(parseRetryAfter(undefined)).toBe(null)
      expect(parseRetryAfter(null)).toBe(null)
      expect(parseRetryAfter('')).toBe(null)
      expect(parseRetryAfter('invalid')).toBe(null)
    })

    it('should parse HTTP date format', () => {
      // Create a date 30 seconds in the future
      const futureDate = new Date(Date.now() + 30000)
      const httpDate = futureDate.toUTCString()

      const result = parseRetryAfter(httpDate)
      expect(result).not.toBeNull()
      // Allow some tolerance for test execution time
      expect(result!).toBeGreaterThan(25000)
      expect(result!).toBeLessThan(35000)
    })

    it('should return null for past HTTP dates', () => {
      const pastDate = new Date(Date.now() - 30000)
      const httpDate = pastDate.toUTCString()

      expect(parseRetryAfter(httpDate)).toBe(null)
    })
  })

  describe('delay', () => {
    beforeEach(() => {
      vi.useFakeTimers()
    })

    afterEach(() => {
      vi.useRealTimers()
    })

    it('should resolve after specified delay', async () => {
      const promise = delay(1000)

      vi.advanceTimersByTime(999)
      expect(vi.getTimerCount()).toBe(1)

      vi.advanceTimersByTime(1)
      await promise

      expect(vi.getTimerCount()).toBe(0)
    })
  })

  describe('shouldRetry', () => {
    const config: RetryConfig = {
      maxRetries: 3,
      baseDelay: 1000,
      maxDelay: 30000,
      backoffMultiplier: 2,
      jitter: false,
    }

    it('should return true for retryable errors below max retries', () => {
      const error = new NetworkError('Network failed')
      expect(shouldRetry(error, 0, config)).toBe(true)
      expect(shouldRetry(error, 1, config)).toBe(true)
      expect(shouldRetry(error, 2, config)).toBe(true)
    })

    it('should return false when max retries exceeded', () => {
      const error = new NetworkError('Network failed')
      expect(shouldRetry(error, 3, config)).toBe(false)
      expect(shouldRetry(error, 4, config)).toBe(false)
    })

    it('should return false for non-retryable errors', () => {
      const error = new ApiError('Not found', ErrorCode.NOT_FOUND, { status: 404 })
      expect(shouldRetry(error, 0, config)).toBe(false)
    })

    it('should use custom retryCondition if provided', () => {
      const customCondition = vi.fn().mockReturnValue(true)
      const customConfig = { ...config, retryCondition: customCondition }

      const error = new ApiError('Not found', ErrorCode.NOT_FOUND, { status: 404 })
      expect(shouldRetry(error, 0, customConfig)).toBe(true)
      expect(customCondition).toHaveBeenCalledWith(error, 0)
    })

    it('should respect custom retryCondition returning false', () => {
      const customCondition = vi.fn().mockReturnValue(false)
      const customConfig = { ...config, retryCondition: customCondition }

      const error = new NetworkError('Network failed')
      expect(shouldRetry(error, 0, customConfig)).toBe(false)
    })
  })

  describe('getRetryDelay', () => {
    const config: RetryConfig = {
      maxRetries: 3,
      baseDelay: 1000,
      maxDelay: 30000,
      backoffMultiplier: 2,
      jitter: false,
    }

    it('should return exponential backoff delay', () => {
      const error = new NetworkError('Network failed')
      expect(getRetryDelay(error, 0, config)).toBe(1000)
      expect(getRetryDelay(error, 1, config)).toBe(2000)
      expect(getRetryDelay(error, 2, config)).toBe(4000)
    })

    it('should respect Retry-After header if present', () => {
      const error = new ApiError('Rate limited', ErrorCode.TOO_MANY_REQUESTS, {
        status: 429,
        response: { retryAfter: '5' } as never,
      })
      expect(getRetryDelay(error, 0, config)).toBe(5000)
    })

    it('should cap Retry-After at maxDelay', () => {
      const shortMaxConfig = { ...config, maxDelay: 3000 }
      const error = new ApiError('Rate limited', ErrorCode.TOO_MANY_REQUESTS, {
        status: 429,
        response: { retryAfter: '10' } as never,
      })
      expect(getRetryDelay(error, 0, shortMaxConfig)).toBe(3000)
    })
  })

  describe('mergeRetryConfig', () => {
    const baseConfig: RetryConfig = {
      maxRetries: 3,
      baseDelay: 1000,
      maxDelay: 30000,
      backoffMultiplier: 2,
      jitter: true,
    }

    it('should return null if noRetry is true', () => {
      expect(mergeRetryConfig(baseConfig, { noRetry: true })).toBe(null)
    })

    it('should return base config if no options provided', () => {
      expect(mergeRetryConfig(baseConfig, undefined)).toEqual(baseConfig)
    })

    it('should override maxRetries', () => {
      const result = mergeRetryConfig(baseConfig, { maxRetries: 5 })
      expect(result?.maxRetries).toBe(5)
      expect(result?.baseDelay).toBe(1000) // Other values unchanged
    })

    it('should override retryCondition', () => {
      const customCondition = () => true
      const result = mergeRetryConfig(baseConfig, { retryCondition: customCondition })
      expect(result?.retryCondition).toBe(customCondition)
    })
  })

  describe('withRetry', () => {
    beforeEach(() => {
      vi.useFakeTimers()
    })

    afterEach(() => {
      vi.useRealTimers()
    })

    const config: RetryConfig = {
      maxRetries: 3,
      baseDelay: 100,
      maxDelay: 1000,
      backoffMultiplier: 2,
      jitter: false,
    }

    it('should return result on success', async () => {
      const fn = vi.fn().mockResolvedValue('success')

      const result = await withRetry(fn, config)

      expect(result).toBe('success')
      expect(fn).toHaveBeenCalledTimes(1)
    })

    it('should retry on retryable errors', async () => {
      const fn = vi.fn()
        .mockRejectedValueOnce(new NetworkError('Failed'))
        .mockRejectedValueOnce(new NetworkError('Failed again'))
        .mockResolvedValue('success')

      const promise = withRetry(fn, config)

      // First call fails
      await vi.advanceTimersByTimeAsync(0)
      expect(fn).toHaveBeenCalledTimes(1)

      // Wait for first retry delay (100ms)
      await vi.advanceTimersByTimeAsync(100)
      expect(fn).toHaveBeenCalledTimes(2)

      // Wait for second retry delay (200ms)
      await vi.advanceTimersByTimeAsync(200)
      expect(fn).toHaveBeenCalledTimes(3)

      const result = await promise
      expect(result).toBe('success')
    })

    it('should throw after max retries exceeded', async () => {
      vi.useRealTimers() // Use real timers for rejection tests to avoid unhandled rejection warnings

      const shortConfig: RetryConfig = {
        maxRetries: 2,
        baseDelay: 1,
        maxDelay: 10,
        backoffMultiplier: 2,
        jitter: false,
      }

      const fn = vi.fn().mockRejectedValue(new NetworkError('Always fails'))

      await expect(withRetry(fn, shortConfig)).rejects.toThrow('Always fails')
      expect(fn).toHaveBeenCalledTimes(3) // Initial + 2 retries

      vi.useFakeTimers() // Restore fake timers
    })

    it('should not retry non-retryable errors', async () => {
      const fn = vi.fn().mockRejectedValue(
        new ApiError('Not found', ErrorCode.NOT_FOUND, { status: 404 })
      )

      await expect(withRetry(fn, config)).rejects.toThrow('Not found')
      expect(fn).toHaveBeenCalledTimes(1)
    })

    it('should call onRetry callback before each retry', async () => {
      const onRetry = vi.fn()
      const configWithCallback = { ...config, onRetry }

      const fn = vi.fn()
        .mockRejectedValueOnce(new NetworkError('Failed'))
        .mockResolvedValue('success')

      const promise = withRetry(fn, configWithCallback)

      await vi.advanceTimersByTimeAsync(0)
      expect(onRetry).toHaveBeenCalledTimes(1)
      expect(onRetry).toHaveBeenCalledWith(expect.any(NetworkError), 1, 100)

      await vi.advanceTimersByTimeAsync(100)
      await promise

      expect(fn).toHaveBeenCalledTimes(2)
    })

    it('should wrap non-ApiError exceptions', async () => {
      const fn = vi.fn().mockRejectedValue(new Error('Generic error'))

      await expect(withRetry(fn, config)).rejects.toBeInstanceOf(ApiError)
    })
  })

  describe('createRetryWrapper', () => {
    beforeEach(() => {
      vi.useFakeTimers()
    })

    afterEach(() => {
      vi.useRealTimers()
    })

    it('should create a wrapper with custom config', async () => {
      const wrapper = createRetryWrapper({ maxRetries: 1, baseDelay: 50, jitter: false })

      const fn = vi.fn()
        .mockRejectedValueOnce(new NetworkError('Failed'))
        .mockResolvedValue('success')

      const promise = wrapper(fn)

      await vi.advanceTimersByTimeAsync(0)
      await vi.advanceTimersByTimeAsync(50)

      const result = await promise
      expect(result).toBe('success')
      expect(fn).toHaveBeenCalledTimes(2)
    })

    it('should allow per-request noRetry override', async () => {
      const wrapper = createRetryWrapper({ maxRetries: 3 })

      const fn = vi.fn().mockRejectedValue(new NetworkError('Failed'))

      await expect(wrapper(fn, { noRetry: true })).rejects.toThrow('Failed')
      expect(fn).toHaveBeenCalledTimes(1)
    })

    it('should allow per-request maxRetries override', async () => {
      vi.useRealTimers() // Use real timers for rejection tests to avoid unhandled rejection warnings

      const wrapper = createRetryWrapper({ maxRetries: 5, baseDelay: 1, jitter: false })

      const fn = vi.fn().mockRejectedValue(new NetworkError('Failed'))

      await expect(wrapper(fn, { maxRetries: 1 })).rejects.toThrow('Failed')
      expect(fn).toHaveBeenCalledTimes(2) // Initial + 1 retry

      vi.useFakeTimers() // Restore fake timers
    })
  })

  describe('DEFAULT_RETRY_CONFIG', () => {
    it('should have sensible defaults', () => {
      expect(DEFAULT_RETRY_CONFIG.maxRetries).toBe(3)
      expect(DEFAULT_RETRY_CONFIG.baseDelay).toBe(1000)
      expect(DEFAULT_RETRY_CONFIG.maxDelay).toBe(30000)
      expect(DEFAULT_RETRY_CONFIG.backoffMultiplier).toBe(2)
      expect(DEFAULT_RETRY_CONFIG.jitter).toBe(true)
    })
  })
})
