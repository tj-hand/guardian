/**
 * Client exports for Evoke API Client
 * Layer 0: Frontend API Service
 */

export { createClient, EvokeClient } from './client'

// Retry utilities
export {
  withRetry,
  isRetryableError,
  calculateBackoff,
  parseRetryAfter,
  delay,
  shouldRetry,
  getRetryDelay,
  mergeRetryConfig,
  createRetryWrapper,
  DEFAULT_RETRY_CONFIG,
} from './retry'
export type { RetryConfig, RequestRetryOptions } from './retry'
