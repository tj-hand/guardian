/**
 * Evoke Client Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import axios, { type InternalAxiosRequestConfig, type AxiosResponse } from 'axios'
import { createClient, EvokeClient } from './client'
import { ApiError, ErrorCode, NetworkError, TimeoutError, AuthenticationError } from '../types'

// Mock axios
vi.mock('axios', () => {
  const mockAxiosInstance = {
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    patch: vi.fn(),
    delete: vi.fn(),
    interceptors: {
      request: { use: vi.fn() },
      response: { use: vi.fn() },
    },
  }

  return {
    default: {
      create: vi.fn(() => mockAxiosInstance),
    },
    AxiosError: class MockAxiosError extends Error {
      response?: {
        status: number
        data: unknown
      }
      code?: string
      config: Record<string, unknown>

      constructor(message: string) {
        super(message)
        this.name = 'AxiosError'
        this.config = {}
      }
    },
  }
})

// Mock localStorage
const createLocalStorageMock = () => {
  const store: Record<string, string> = {}
  return {
    store,
    getItem: vi.fn((key: string): string | null => store[key] || null),
    setItem: vi.fn((key: string, value: string): void => {
      store[key] = value
    }),
    removeItem: vi.fn((key: string): void => {
      delete store[key]
    }),
    clear: vi.fn((): void => {
      Object.keys(store).forEach((key) => delete store[key])
    }),
  }
}
const localStorageMock = createLocalStorageMock()

Object.defineProperty(global, 'window', {
  value: { localStorage: localStorageMock, sessionStorage: localStorageMock },
  writable: true,
})

Object.defineProperty(global, 'localStorage', {
  value: localStorageMock,
  writable: true,
})

describe('createClient', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    localStorageMock.clear()
  })

  it('should create an EvokeClient instance', () => {
    const client = createClient({ baseURL: '/api' })
    expect(client).toBeInstanceOf(EvokeClient)
  })

  it('should configure axios with baseURL', () => {
    createClient({ baseURL: 'https://api.example.com' })

    expect(axios.create).toHaveBeenCalledWith(
      expect.objectContaining({
        baseURL: 'https://api.example.com',
      })
    )
  })

  it('should use default timeout', () => {
    createClient({ baseURL: '/api' })

    expect(axios.create).toHaveBeenCalledWith(
      expect.objectContaining({
        timeout: 30000,
      })
    )
  })

  it('should allow custom timeout', () => {
    createClient({ baseURL: '/api', timeout: 5000 })

    expect(axios.create).toHaveBeenCalledWith(
      expect.objectContaining({
        timeout: 5000,
      })
    )
  })

  it('should set default Content-Type header', () => {
    createClient({ baseURL: '/api' })

    expect(axios.create).toHaveBeenCalledWith(
      expect.objectContaining({
        headers: expect.objectContaining({
          'Content-Type': 'application/json',
        }),
      })
    )
  })

  it('should merge custom headers', () => {
    createClient({
      baseURL: '/api',
      headers: { 'X-Custom': 'value' },
    })

    expect(axios.create).toHaveBeenCalledWith(
      expect.objectContaining({
        headers: expect.objectContaining({
          'Content-Type': 'application/json',
          'X-Custom': 'value',
        }),
      })
    )
  })
})

describe('EvokeClient', () => {
  let client: EvokeClient
  let mockAxiosInstance: {
    get: ReturnType<typeof vi.fn>
    post: ReturnType<typeof vi.fn>
    put: ReturnType<typeof vi.fn>
    patch: ReturnType<typeof vi.fn>
    delete: ReturnType<typeof vi.fn>
  }

  beforeEach(() => {
    vi.clearAllMocks()
    localStorageMock.clear()
    client = createClient({ baseURL: '/api' })
    const mockResults = (axios.create as ReturnType<typeof vi.fn>).mock.results[0]
    mockAxiosInstance = mockResults?.value
  })

  describe('token management', () => {
    it('should set token', () => {
      client.setToken('test-token')

      expect(client.getToken()).toBe('test-token')
      expect(client.hasToken()).toBe(true)
    })

    it('should store token in localStorage', () => {
      client.setToken('test-token')

      expect(localStorageMock.setItem).toHaveBeenCalledWith(
        'evoke_access_token',
        'test-token'
      )
    })

    it('should clear token', () => {
      client.setToken('test-token')
      client.clearToken()

      expect(client.getToken()).toBeNull()
      expect(client.hasToken()).toBe(false)
    })

    it('should load token from storage on init', () => {
      localStorageMock.store['evoke_access_token'] = 'stored-token'
      const newClient = createClient({ baseURL: '/api' })

      expect(newClient.getToken()).toBe('stored-token')
    })
  })

  describe('HTTP methods', () => {
    const mockResponse = (data: unknown): AxiosResponse => ({
      data,
      status: 200,
      statusText: 'OK',
      headers: {},
      config: { headers: {} } as InternalAxiosRequestConfig,
    })

    describe('get()', () => {
      it('should make GET request', async () => {
        mockAxiosInstance.get.mockResolvedValue(mockResponse({ users: [] }))

        const result = await client.get('/users')

        expect(mockAxiosInstance.get).toHaveBeenCalledWith('/users', expect.any(Object))
        expect(result.data).toEqual({ users: [] })
      })

      it('should pass query params', async () => {
        mockAxiosInstance.get.mockResolvedValue(mockResponse([]))

        await client.get('/users', { params: { page: 1, limit: 10 } })

        expect(mockAxiosInstance.get).toHaveBeenCalledWith('/users', expect.objectContaining({
          params: { page: 1, limit: 10 },
        }))
      })
    })

    describe('post()', () => {
      it('should make POST request', async () => {
        const newUser = { name: 'John', email: 'john@test.com' }
        mockAxiosInstance.post.mockResolvedValue(mockResponse({ id: '1', ...newUser }))

        const result = await client.post('/users', newUser)

        expect(mockAxiosInstance.post).toHaveBeenCalledWith('/users', newUser, expect.any(Object))
        expect(result.data).toEqual({ id: '1', ...newUser })
      })
    })

    describe('put()', () => {
      it('should make PUT request', async () => {
        const userData = { name: 'Updated' }
        mockAxiosInstance.put.mockResolvedValue(mockResponse(userData))

        const result = await client.put('/users/1', userData)

        expect(mockAxiosInstance.put).toHaveBeenCalledWith('/users/1', userData, expect.any(Object))
        expect(result.data).toEqual(userData)
      })
    })

    describe('patch()', () => {
      it('should make PATCH request', async () => {
        const patchData = { name: 'Patched' }
        mockAxiosInstance.patch.mockResolvedValue(mockResponse(patchData))

        const result = await client.patch('/users/1', patchData)

        expect(mockAxiosInstance.patch).toHaveBeenCalledWith('/users/1', patchData, expect.any(Object))
        expect(result.data).toEqual(patchData)
      })
    })

    describe('delete()', () => {
      it('should make DELETE request', async () => {
        mockAxiosInstance.delete.mockResolvedValue(mockResponse(undefined))

        await client.delete('/users/1')

        expect(mockAxiosInstance.delete).toHaveBeenCalledWith('/users/1', expect.any(Object))
      })
    })
  })

  describe('public methods', () => {
    const mockResponse = (data: unknown): AxiosResponse => ({
      data,
      status: 200,
      statusText: 'OK',
      headers: {},
      config: { headers: {} } as InternalAxiosRequestConfig,
    })

    it('publicGet should skip auth', async () => {
      mockAxiosInstance.get.mockResolvedValue(mockResponse({}))

      await client.publicGet('/config')

      expect(mockAxiosInstance.get).toHaveBeenCalledWith('/config', expect.objectContaining({
        skipAuth: true,
      }))
    })

    it('publicPost should skip auth', async () => {
      mockAxiosInstance.post.mockResolvedValue(mockResponse({}))

      await client.publicPost('/login', { email: 'test@test.com' })

      expect(mockAxiosInstance.post).toHaveBeenCalledWith(
        '/login',
        { email: 'test@test.com' },
        expect.objectContaining({ skipAuth: true })
      )
    })
  })

  describe('buildQuery()', () => {
    it('should build query string from params', () => {
      const query = client.buildQuery({ name: 'john', age: 30 })
      expect(query).toBe('name=john&age=30')
    })

    it('should handle array values', () => {
      const query = client.buildQuery({ tags: ['a', 'b', 'c'] })
      expect(query).toBe('tags=a&tags=b&tags=c')
    })

    it('should skip null/undefined values', () => {
      const query = client.buildQuery({
        name: 'john',
        empty: null,
        missing: undefined,
      })
      expect(query).toBe('name=john')
    })
  })

  describe('createAbortController()', () => {
    it('should return signal and abort function', () => {
      const [signal, abort] = client.createAbortController()

      expect(signal).toBeInstanceOf(AbortSignal)
      expect(typeof abort).toBe('function')
    })

    it('should abort the signal when abort is called', () => {
      const [signal, abort] = client.createAbortController()

      expect(signal.aborted).toBe(false)
      abort()
      expect(signal.aborted).toBe(true)
    })
  })

  describe('getAxios()', () => {
    it('should return the underlying axios instance', () => {
      const axiosInstance = client.getAxios()
      expect(axiosInstance).toBe(mockAxiosInstance)
    })
  })
})

describe('Error classes', () => {
  describe('ApiError', () => {
    it('should create error with message and code', () => {
      const error = new ApiError('Test error', ErrorCode.BAD_REQUEST)

      expect(error.message).toBe('Test error')
      expect(error.code).toBe(ErrorCode.BAD_REQUEST)
      expect(error.name).toBe('ApiError')
    })

    it('should include optional properties', () => {
      const error = new ApiError('Test', ErrorCode.BAD_REQUEST, {
        status: 400,
        response: { message: 'Bad request' },
      })

      expect(error.status).toBe(400)
      expect(error.response).toEqual({ message: 'Bad request' })
    })

    it('isNetworkError() should return true for network errors', () => {
      const networkError = new ApiError('Network', ErrorCode.NETWORK_ERROR)
      const timeoutError = new ApiError('Timeout', ErrorCode.TIMEOUT)
      const otherError = new ApiError('Other', ErrorCode.BAD_REQUEST)

      expect(networkError.isNetworkError()).toBe(true)
      expect(timeoutError.isNetworkError()).toBe(true)
      expect(otherError.isNetworkError()).toBe(false)
    })

    it('isAuthError() should return true for auth errors', () => {
      const unauthorizedError = new ApiError('Unauthorized', ErrorCode.UNAUTHORIZED)
      const forbiddenError = new ApiError('Forbidden', ErrorCode.FORBIDDEN)
      const otherError = new ApiError('Other', ErrorCode.BAD_REQUEST)

      expect(unauthorizedError.isAuthError()).toBe(true)
      expect(forbiddenError.isAuthError()).toBe(true)
      expect(otherError.isAuthError()).toBe(false)
    })

    it('isValidationError() should return true for validation errors', () => {
      const validationError = new ApiError('Validation', ErrorCode.VALIDATION_ERROR)
      const unprocessableError = new ApiError('Unprocessable', ErrorCode.UNPROCESSABLE_ENTITY)
      const otherError = new ApiError('Other', ErrorCode.BAD_REQUEST)

      expect(validationError.isValidationError()).toBe(true)
      expect(unprocessableError.isValidationError()).toBe(true)
      expect(otherError.isValidationError()).toBe(false)
    })

    it('isServerError() should return true for 5xx status', () => {
      const serverError = new ApiError('Server', ErrorCode.INTERNAL_SERVER_ERROR, { status: 500 })
      const clientError = new ApiError('Client', ErrorCode.BAD_REQUEST, { status: 400 })
      const noStatus = new ApiError('No status', ErrorCode.UNKNOWN_ERROR)

      expect(serverError.isServerError()).toBe(true)
      expect(clientError.isServerError()).toBe(false)
      expect(noStatus.isServerError()).toBe(false)
    })

    it('getFieldError() should return field error message', () => {
      const error = new ApiError('Validation', ErrorCode.VALIDATION_ERROR, {
        validationErrors: [
          { field: 'email', message: 'Invalid email' },
          { field: 'name', message: 'Required' },
        ],
      })

      expect(error.getFieldError('email')).toBe('Invalid email')
      expect(error.getFieldError('name')).toBe('Required')
      expect(error.getFieldError('missing')).toBeUndefined()
    })

    it('toJSON() should serialize error', () => {
      const error = new ApiError('Test', ErrorCode.BAD_REQUEST, { status: 400 })
      const json = error.toJSON()

      expect(json).toEqual({
        name: 'ApiError',
        message: 'Test',
        code: ErrorCode.BAD_REQUEST,
        status: 400,
        validationErrors: undefined,
        response: undefined,
      })
    })
  })

  describe('NetworkError', () => {
    it('should create network error', () => {
      const error = new NetworkError('Connection failed')

      expect(error.name).toBe('NetworkError')
      expect(error.code).toBe(ErrorCode.NETWORK_ERROR)
      expect(error.isNetworkError()).toBe(true)
    })
  })

  describe('TimeoutError', () => {
    it('should create timeout error', () => {
      const error = new TimeoutError('Request timed out')

      expect(error.name).toBe('TimeoutError')
      expect(error.code).toBe(ErrorCode.TIMEOUT)
      expect(error.isNetworkError()).toBe(true)
    })
  })

  describe('AuthenticationError', () => {
    it('should create authentication error', () => {
      const error = new AuthenticationError('Invalid token')

      expect(error.name).toBe('AuthenticationError')
      expect(error.code).toBe(ErrorCode.UNAUTHORIZED)
      expect(error.status).toBe(401)
      expect(error.isAuthError()).toBe(true)
    })
  })
})
