/**
 * Retry Logic for Evoke API Client
 * EVOKE-019: Auto-retry failed requests with exponential backoff
 */

import { ApiError, ErrorCode, DEFAULT_RETRY_CONFIG } from '../types'
import type { RetryConfig, RequestRetryOptions } from '../types'

// Re-export from types for backwards compatibility
export { DEFAULT_RETRY_CONFIG }
export type { RetryConfig, RequestRetryOptions }

/**
 * HTTP status codes that should trigger retry
 */
const RETRYABLE_STATUS_CODES = new Set([
  408, // Request Timeout
  429, // Too Many Requests
  500, // Internal Server Error
  502, // Bad Gateway
  503, // Service Unavailable
  504, // Gateway Timeout
])

/**
 * Error codes that should trigger retry
 */
const RETRYABLE_ERROR_CODES = new Set([
  ErrorCode.NETWORK_ERROR,
  ErrorCode.TIMEOUT,
  ErrorCode.SERVICE_UNAVAILABLE,
  ErrorCode.INTERNAL_SERVER_ERROR,
  ErrorCode.TOO_MANY_REQUESTS,
])

/**
 * Check if an error is retryable based on default conditions
 *
 * @category Retry
 */
export function isRetryableError(error: ApiError): boolean {
  // Network and timeout errors are always retryable
  if (error.isNetworkError()) {
    return true
  }

  // Check error code
  if (RETRYABLE_ERROR_CODES.has(error.code)) {
    return true
  }

  // Check HTTP status
  if (error.status !== undefined && RETRYABLE_STATUS_CODES.has(error.status)) {
    return true
  }

  return false
}

/**
 * Calculate delay with exponential backoff
 *
 * @category Retry
 * @param attempt - Current attempt number (0-indexed)
 * @param config - Retry configuration
 * @returns Delay in milliseconds
 */
export function calculateBackoff(attempt: number, config: RetryConfig): number {
  // Exponential backoff: baseDelay * (multiplier ^ attempt)
  const exponentialDelay = config.baseDelay * Math.pow(config.backoffMultiplier, attempt)

  // Cap at maxDelay
  const cappedDelay = Math.min(exponentialDelay, config.maxDelay)

  // Add jitter if enabled (±25% randomness)
  if (config.jitter) {
    const jitterFactor = 0.75 + Math.random() * 0.5 // 0.75 to 1.25
    return Math.floor(cappedDelay * jitterFactor)
  }

  return cappedDelay
}

/**
 * Parse Retry-After header value
 *
 * @category Retry
 * @param retryAfter - Header value (seconds or HTTP date)
 * @returns Delay in milliseconds, or null if invalid
 */
export function parseRetryAfter(retryAfter: string | undefined | null): number | null {
  if (!retryAfter) {
    return null
  }

  // Try parsing as seconds
  const seconds = parseInt(retryAfter, 10)
  if (!isNaN(seconds) && seconds > 0) {
    return seconds * 1000
  }

  // Try parsing as HTTP date
  const date = Date.parse(retryAfter)
  if (!isNaN(date)) {
    const delay = date - Date.now()
    return delay > 0 ? delay : null
  }

  return null
}

/**
 * Create a promise that resolves after a delay
 *
 * @category Utilities
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/**
 * Determine if should retry based on config and error
 *
 * @category Retry
 */
export function shouldRetry(
  error: ApiError,
  attempt: number,
  config: RetryConfig
): boolean {
  // Check if we've exceeded max retries
  if (attempt >= config.maxRetries) {
    return false
  }

  // Use custom condition if provided
  if (config.retryCondition) {
    return config.retryCondition(error, attempt)
  }

  // Use default retryable check
  return isRetryableError(error)
}

/**
 * Get the delay for a retry attempt, considering Retry-After header
 *
 * @category Retry
 */
export function getRetryDelay(
  error: ApiError,
  attempt: number,
  config: RetryConfig
): number {
  // Check for Retry-After header in response
  const response = error.response as Record<string, unknown> | undefined
  const retryAfter = response?.retryAfter as string | undefined

  const retryAfterDelay = parseRetryAfter(retryAfter)
  if (retryAfterDelay !== null) {
    // Respect Retry-After header but cap at maxDelay
    return Math.min(retryAfterDelay, config.maxDelay)
  }

  // Use exponential backoff
  return calculateBackoff(attempt, config)
}

/**
 * Merge request-level retry options with client config
 *
 * @category Retry
 */
export function mergeRetryConfig(
  baseConfig: RetryConfig,
  requestOptions?: RequestRetryOptions
): RetryConfig | null {
  // If retry is disabled for this request, return null
  if (requestOptions?.noRetry) {
    return null
  }

  // If no overrides, return base config
  if (!requestOptions?.maxRetries && !requestOptions?.retryCondition) {
    return baseConfig
  }

  // Merge options
  return {
    ...baseConfig,
    ...(requestOptions.maxRetries !== undefined && { maxRetries: requestOptions.maxRetries }),
    ...(requestOptions.retryCondition && { retryCondition: requestOptions.retryCondition }),
  }
}

/**
 * Execute a function with retry logic
 *
 * @category Retry
 * @param fn - Async function to execute
 * @param config - Retry configuration
 * @returns Result of the function
 *
 * @example
 * ```typescript
 * const result = await withRetry(
 *   () => client.get('/data'),
 *   { maxRetries: 3, baseDelay: 1000 }
 * )
 * ```
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  config: RetryConfig
): Promise<T> {
  let lastError: ApiError | undefined

  for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
    try {
      return await fn()
    } catch (error) {
      // Ensure error is an ApiError
      const apiError = error instanceof ApiError
        ? error
        : new ApiError(
            error instanceof Error ? error.message : 'Unknown error',
            ErrorCode.UNKNOWN_ERROR,
            { originalError: error instanceof Error ? error : undefined }
          )

      lastError = apiError

      // Check if we should retry
      if (!shouldRetry(apiError, attempt, config)) {
        throw apiError
      }

      // This is not the last attempt, so we'll retry
      if (attempt < config.maxRetries) {
        const retryDelay = getRetryDelay(apiError, attempt, config)

        // Call onRetry callback if provided
        config.onRetry?.(apiError, attempt + 1, retryDelay)

        // Wait before retrying
        await delay(retryDelay)
      }
    }
  }

  // Should never reach here, but TypeScript needs this
  throw lastError ?? new ApiError('Retry failed', ErrorCode.UNKNOWN_ERROR)
}

/**
 * Create a retry wrapper with pre-configured options
 *
 * @category Retry
 */
export function createRetryWrapper(config: Partial<RetryConfig> = {}) {
  const mergedConfig: RetryConfig = {
    ...DEFAULT_RETRY_CONFIG,
    ...config,
  }

  return <T>(fn: () => Promise<T>, requestOptions?: RequestRetryOptions): Promise<T> => {
    const finalConfig = mergeRetryConfig(mergedConfig, requestOptions)

    // If retry is disabled, just execute the function
    if (!finalConfig) {
      return fn()
    }

    return withRetry(fn, finalConfig)
  }
}
