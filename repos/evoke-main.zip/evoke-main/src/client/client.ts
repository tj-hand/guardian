/**
 * Evoke API Client
 * Layer 0: Frontend API Service
 *
 * Centralized axios instance with interceptors for authentication,
 * error handling, and request/response transformation.
 */

import axios, {
  type AxiosInstance,
  type AxiosResponse,
  type InternalAxiosRequestConfig,
  AxiosError,
} from 'axios'
import type {
  EvokeConfig,
  ApiResponse,
  GetRequestOptions,
  MutationRequestOptions,
  QueryParams,
  UploadRequestOptions,
  DownloadRequestOptions,
  RetryConfig,
  RequestRetryOptions,
} from '../types'
import {
  DEFAULT_CONFIG,
  DEFAULT_RETRY_CONFIG,
  ApiError,
  ErrorCode,
  NetworkError,
  TimeoutError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ValidationErrorClass,
} from '../types'
import { withRetry, mergeRetryConfig } from './retry'

/**
 * Extended request config with Evoke-specific properties
 */
interface EvokeRequestConfig extends InternalAxiosRequestConfig {
  skipAuth?: boolean
  metadata?: {
    startTime?: number
    [key: string]: unknown
  }
}

/**
 * Creates and configures the Evoke API client
 *
 * @category Client
 *
 * @example
 * ```typescript
 * const client = createClient({
 *   baseURL: '/api',
 *   onAuthError: () => router.push('/login'),
 * })
 * ```
 */
export function createClient(config: EvokeConfig): EvokeClient {
  const client = new EvokeClient(config)
  return client
}

/**
 * Evoke API Client class
 *
 * The main client for making HTTP requests with automatic authentication,
 * retry logic, error handling, and request/response transformation.
 *
 * @category Client
 *
 * @example
 * ```typescript
 * const client = new EvokeClient({
 *   baseURL: '/api',
 *   retry: { maxRetries: 3 },
 * })
 *
 * // Authenticated GET request
 * const { data } = await client.get<User[]>('/users')
 *
 * // POST with data
 * const { data: user } = await client.post<User>('/users', {
 *   name: 'John',
 *   email: 'john@example.com'
 * })
 * ```
 */
export class EvokeClient {
  private readonly axios: AxiosInstance
  private readonly config: EvokeConfig
  private readonly retryConfig: RetryConfig | null
  private accessToken: string | null = null

  constructor(config: EvokeConfig) {
    this.config = {
      ...config,
      timeout: config.timeout ?? DEFAULT_CONFIG.timeout,
      withCredentials: config.withCredentials ?? DEFAULT_CONFIG.withCredentials,
      debug: config.debug ?? DEFAULT_CONFIG.debug,
      tokenStorage: {
        ...DEFAULT_CONFIG.tokenStorage,
        ...config.tokenStorage,
      },
    }

    // Configure retry: false disables, undefined uses defaults, object merges with defaults
    if (config.retry === false) {
      this.retryConfig = null
    } else {
      this.retryConfig = {
        ...DEFAULT_RETRY_CONFIG,
        ...config.retry,
      }
    }

    this.axios = axios.create({
      baseURL: this.config.baseURL,
      timeout: this.config.timeout ?? DEFAULT_CONFIG.timeout,
      withCredentials: this.config.withCredentials ?? DEFAULT_CONFIG.withCredentials,
      headers: {
        'Content-Type': 'application/json',
        ...this.config.headers,
      },
    })

    this.setupInterceptors()
    this.loadStoredToken()
  }

  /**
   * Setup request and response interceptors
   */
  private setupInterceptors(): void {
    // Request interceptor
    this.axios.interceptors.request.use(
      (config: EvokeRequestConfig) => {
        // Add request timing metadata
        config.metadata = {
          ...config.metadata,
          startTime: Date.now(),
        }

        // Inject auth token if available and not skipped
        if (!config.skipAuth && this.accessToken) {
          config.headers.Authorization = `Bearer ${this.accessToken}`
        }

        // Debug logging
        if (this.config.debug) {
          console.log(`[Evoke] ${config.method?.toUpperCase()} ${config.url}`, {
            params: config.params,
            data: config.data,
          })
        }

        return config
      },
      (error) => Promise.reject(this.transformError(error))
    )

    // Response interceptor
    this.axios.interceptors.response.use(
      (response: AxiosResponse) => {
        const config = response.config as EvokeRequestConfig
        const duration = config.metadata?.startTime
          ? Date.now() - config.metadata.startTime
          : undefined

        // Debug logging
        if (this.config.debug) {
          console.log(`[Evoke] Response ${response.status}`, {
            duration: duration ? `${duration}ms` : undefined,
            data: response.data,
          })
        }

        return response
      },
      (error: AxiosError) => {
        const apiError = this.transformError(error)

        // Handle authentication errors
        if (apiError.code === ErrorCode.UNAUTHORIZED) {
          this.clearToken()
          this.config.onAuthError?.(apiError)
        }

        // Handle network errors
        if (apiError.isNetworkError()) {
          this.config.onNetworkError?.(apiError)
        }

        // Debug logging
        if (this.config.debug) {
          console.error(`[Evoke] Error`, apiError.toJSON())
        }

        return Promise.reject(apiError)
      }
    )
  }

  /**
   * Transform axios error to ApiError
   */
  private transformError(error: AxiosError | Error): ApiError {
    if (!(error instanceof AxiosError)) {
      return new ApiError(error.message, ErrorCode.UNKNOWN_ERROR, {
        originalError: error,
      })
    }

    // Network error (no response)
    if (!error.response) {
      if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        return new TimeoutError(error.message, error)
      }
      if (error.code === 'ERR_CANCELED') {
        return new ApiError('Request was cancelled', ErrorCode.ABORTED, {
          originalError: error,
        })
      }
      return new NetworkError(error.message, error)
    }

    const { status, data } = error.response
    const responseData = data as Record<string, unknown> | undefined
    const message = (responseData?.message as string) || error.message

    switch (status) {
      case 400:
        return new ApiError(message, ErrorCode.BAD_REQUEST, {
          status,
          response: responseData as never,
          originalError: error,
        })

      case 401:
        return new AuthenticationError(message, responseData as never)

      case 403:
        return new AuthorizationError(message, responseData as never)

      case 404:
        return new NotFoundError(message, responseData as never)

      case 409:
        return new ApiError(message, ErrorCode.CONFLICT, {
          status,
          response: responseData as never,
          originalError: error,
        })

      case 422:
        return new ValidationErrorClass(
          message,
          (responseData?.errors as never) ?? [],
          responseData as never
        )

      case 429:
        return new ApiError(message, ErrorCode.TOO_MANY_REQUESTS, {
          status,
          response: responseData as never,
          originalError: error,
        })

      case 500:
        return new ApiError(message, ErrorCode.INTERNAL_SERVER_ERROR, {
          status,
          response: responseData as never,
          originalError: error,
        })

      case 503:
        return new ApiError(message, ErrorCode.SERVICE_UNAVAILABLE, {
          status,
          response: responseData as never,
          originalError: error,
        })

      default:
        return new ApiError(message, ErrorCode.UNKNOWN_ERROR, {
          status,
          response: responseData as never,
          originalError: error,
        })
    }
  }

  /**
   * Load token from storage
   */
  private loadStoredToken(): void {
    const storageConfig = this.config.tokenStorage ?? DEFAULT_CONFIG.tokenStorage
    const storage = this.getStorage(storageConfig.type)

    if (storage) {
      this.accessToken = storage.getItem(storageConfig.accessTokenKey ?? DEFAULT_CONFIG.tokenStorage.accessTokenKey)
    }
  }

  /**
   * Get storage instance based on type
   */
  private getStorage(type: 'localStorage' | 'sessionStorage' | 'memory'): Storage | null {
    if (typeof window === 'undefined') return null

    switch (type) {
      case 'localStorage':
        return window.localStorage
      case 'sessionStorage':
        return window.sessionStorage
      case 'memory':
        return null // Memory storage handled internally
      default:
        return null
    }
  }

  /**
   * Set authentication token
   */
  setToken(token: string): void {
    this.accessToken = token
    const storageConfig = this.config.tokenStorage ?? DEFAULT_CONFIG.tokenStorage
    const storage = this.getStorage(storageConfig.type)

    if (storage) {
      storage.setItem(
        storageConfig.accessTokenKey ?? DEFAULT_CONFIG.tokenStorage.accessTokenKey,
        token
      )
    }
  }

  /**
   * Clear authentication token
   */
  clearToken(): void {
    this.accessToken = null
    const storageConfig = this.config.tokenStorage ?? DEFAULT_CONFIG.tokenStorage
    const storage = this.getStorage(storageConfig.type)

    if (storage) {
      storage.removeItem(storageConfig.accessTokenKey ?? DEFAULT_CONFIG.tokenStorage.accessTokenKey)
      storage.removeItem(storageConfig.refreshTokenKey ?? DEFAULT_CONFIG.tokenStorage.refreshTokenKey)
    }
  }

  /**
   * Get current token (for debugging/testing)
   */
  getToken(): string | null {
    return this.accessToken
  }

  /**
   * Check if client has a token
   */
  hasToken(): boolean {
    return this.accessToken !== null
  }

  /**
   * Get the current retry configuration
   */
  getRetryConfig(): RetryConfig | null {
    return this.retryConfig ? { ...this.retryConfig } : null
  }

  /**
   * Execute a request with retry logic
   */
  private async executeWithRetry<T>(
    fn: () => Promise<AxiosResponse<T>>,
    requestRetryOptions?: RequestRetryOptions
  ): Promise<ApiResponse<T>> {
    // Determine effective retry config
    const effectiveConfig = this.getEffectiveRetryConfig(requestRetryOptions)

    // If retry is disabled, execute directly
    if (!effectiveConfig) {
      const response = await fn()
      return this.wrapResponse(response)
    }

    // Execute with retry
    return withRetry(
      async () => {
        const response = await fn()
        return this.wrapResponse(response)
      },
      effectiveConfig
    )
  }

  /**
   * Get effective retry config considering request-level overrides
   */
  private getEffectiveRetryConfig(requestOptions?: RequestRetryOptions): RetryConfig | null {
    // If client-level retry is disabled, check if request wants to enable it
    if (!this.retryConfig) {
      return null
    }

    // If request explicitly disables retry
    if (requestOptions?.noRetry) {
      return null
    }

    // Merge request options with client config
    return mergeRetryConfig(this.retryConfig, requestOptions)
  }

  /**
   * GET request
   */
  async get<T>(url: string, options?: GetRequestOptions): Promise<ApiResponse<T>> {
    return this.executeWithRetry(
      () => this.axios.get<T>(url, {
        params: options?.params,
        ...options,
      }),
      options?.retry
    )
  }

  /**
   * POST request
   */
  async post<T, D = unknown>(
    url: string,
    data?: D,
    options?: MutationRequestOptions<D>
  ): Promise<ApiResponse<T>> {
    return this.executeWithRetry(
      () => this.axios.post<T>(url, data, {
        params: options?.params,
        ...options,
      }),
      options?.retry
    )
  }

  /**
   * PUT request
   */
  async put<T, D = unknown>(
    url: string,
    data?: D,
    options?: MutationRequestOptions<D>
  ): Promise<ApiResponse<T>> {
    return this.executeWithRetry(
      () => this.axios.put<T>(url, data, {
        params: options?.params,
        ...options,
      }),
      options?.retry
    )
  }

  /**
   * PATCH request
   */
  async patch<T, D = unknown>(
    url: string,
    data?: D,
    options?: MutationRequestOptions<D>
  ): Promise<ApiResponse<T>> {
    return this.executeWithRetry(
      () => this.axios.patch<T>(url, data, {
        params: options?.params,
        ...options,
      }),
      options?.retry
    )
  }

  /**
   * DELETE request
   */
  async delete<T>(url: string, options?: GetRequestOptions): Promise<ApiResponse<T>> {
    return this.executeWithRetry(
      () => this.axios.delete<T>(url, {
        params: options?.params,
        ...options,
      }),
      options?.retry
    )
  }

  /**
   * Public GET request (no auth token)
   */
  async publicGet<T>(url: string, options?: GetRequestOptions): Promise<ApiResponse<T>> {
    return this.get<T>(url, { ...options, skipAuth: true })
  }

  /**
   * Public POST request (no auth token)
   */
  async publicPost<T, D = unknown>(
    url: string,
    data?: D,
    options?: MutationRequestOptions<D>
  ): Promise<ApiResponse<T>> {
    return this.post<T, D>(url, data, { ...options, skipAuth: true })
  }

  // ==========================================
  // File Operations (Sprint 3)
  // ==========================================

  /**
   * Upload a single file with progress tracking
   */
  async upload<T = unknown>(
    url: string,
    file: File,
    options?: UploadRequestOptions & { fieldName?: string }
  ): Promise<ApiResponse<T>> {
    const formData = new FormData()
    formData.append(options?.fieldName ?? 'file', file)

    const config: Parameters<AxiosInstance['post']>[2] = {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }

    if (options?.signal) {
      config.signal = options.signal
    }

    if (options?.onProgress) {
      const progressCallback = options.onProgress
      config.onUploadProgress = (event) => {
        if (event.total) {
          const progress = Math.round((event.loaded * 100) / event.total)
          progressCallback(progress)
        }
      }
    }

    const response = await this.axios.post<T>(url, formData, config)
    return this.wrapResponse(response)
  }

  /**
   * Upload multiple files with progress tracking
   */
  async uploadMultiple<T = unknown>(
    url: string,
    files: File[],
    options?: UploadRequestOptions & { fieldName?: string }
  ): Promise<ApiResponse<T>> {
    const formData = new FormData()
    const fieldName = options?.fieldName ?? 'files'

    files.forEach((file) => {
      formData.append(fieldName, file)
    })

    const config: Parameters<AxiosInstance['post']>[2] = {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }

    if (options?.signal) {
      config.signal = options.signal
    }

    if (options?.onProgress) {
      const progressCallback = options.onProgress
      config.onUploadProgress = (event) => {
        if (event.total) {
          const progress = Math.round((event.loaded * 100) / event.total)
          progressCallback(progress)
        }
      }
    }

    const response = await this.axios.post<T>(url, formData, config)
    return this.wrapResponse(response)
  }

  /**
   * Upload files with individual field names (for forms with multiple file inputs)
   */
  async uploadWithFields<T = unknown>(
    url: string,
    files: Record<string, File | File[]>,
    options?: UploadRequestOptions
  ): Promise<ApiResponse<T>> {
    const formData = new FormData()

    for (const [fieldName, fileOrFiles] of Object.entries(files)) {
      if (Array.isArray(fileOrFiles)) {
        fileOrFiles.forEach((file) => formData.append(fieldName, file))
      } else {
        formData.append(fieldName, fileOrFiles)
      }
    }

    const config: Parameters<AxiosInstance['post']>[2] = {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }

    if (options?.signal) {
      config.signal = options.signal
    }

    if (options?.onProgress) {
      const progressCallback = options.onProgress
      config.onUploadProgress = (event) => {
        if (event.total) {
          const progress = Math.round((event.loaded * 100) / event.total)
          progressCallback(progress)
        }
      }
    }

    const response = await this.axios.post<T>(url, formData, config)
    return this.wrapResponse(response)
  }

  /**
   * Download a file with progress tracking
   * Returns the file as a Blob
   */
  async download(
    url: string,
    options?: DownloadRequestOptions
  ): Promise<ApiResponse<Blob>> {
    const config: Parameters<AxiosInstance['get']>[1] = {
      responseType: options?.responseType ?? 'blob',
    }

    if (options?.onProgress) {
      const progressCallback = options.onProgress
      config.onDownloadProgress = (event) => {
        if (event.total) {
          const progress = Math.round((event.loaded * 100) / event.total)
          progressCallback(progress)
        }
      }
    }

    const response = await this.axios.get<Blob>(url, config)
    return this.wrapResponse(response)
  }

  /**
   * Download a file and trigger browser download
   */
  async downloadAndSave(
    url: string,
    filename: string,
    options?: DownloadRequestOptions
  ): Promise<void> {
    const response = await this.download(url, options)

    // Create blob URL and trigger download
    const blobUrl = URL.createObjectURL(response.data)
    const link = document.createElement('a')
    link.href = blobUrl
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(blobUrl)
  }

  /**
   * Create an AbortController for cancellable requests
   * Returns a tuple of [signal, abort function]
   */
  createAbortController(): [AbortSignal, () => void] {
    const controller = new AbortController()
    return [controller.signal, () => controller.abort()]
  }

  // ==========================================
  // Utility Methods
  // ==========================================

  /**
   * Build query string from params object
   */
  buildQuery(params: QueryParams): string {
    const searchParams = new URLSearchParams()

    for (const [key, value] of Object.entries(params)) {
      if (value === null || value === undefined) continue

      if (Array.isArray(value)) {
        value.forEach((v) => searchParams.append(key, String(v)))
      } else {
        searchParams.append(key, String(value))
      }
    }

    return searchParams.toString()
  }

  /**
   * Get the underlying axios instance (for advanced use cases)
   */
  getAxios(): AxiosInstance {
    return this.axios
  }

  /**
   * Wrap axios response in ApiResponse
   */
  private wrapResponse<T>(response: AxiosResponse<T>): ApiResponse<T> {
    const config = response.config as EvokeRequestConfig
    const duration = config.metadata?.startTime
      ? Date.now() - config.metadata.startTime
      : undefined

    return {
      data: response.data,
      status: response.status,
      headers: response.headers as Record<string, string>,
      duration,
    }
  }
}
