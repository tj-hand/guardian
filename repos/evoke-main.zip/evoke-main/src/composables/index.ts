/**
 * Vue 3 Composables for Evoke API Client
 *
 * Provides reactive wrappers for API operations using the Composition API.
 *
 * @example
 * ```typescript
 * import { useApi, useCrud, useList } from '@evoke/client'
 *
 * // Generic API call
 * const { data, loading, execute } = useApi(
 *   (id: string) => client.get<User>(`/users/${id}`)
 * )
 *
 * // CRUD operations
 * const userService = createCrudService<User>(client, { basePath: '/users' })
 * const { items, create, update, remove } = useCrud(userService)
 *
 * // Simple list
 * const { items, fetch } = useList(() => client.get<User[]>('/users'))
 * ```
 */

// useApi composable and utilities
export {
  useApi,
  useLazyApi,
  useApiStates,
  type UseApiOptions,
  type UseApiReturn,
  type UseLazyApiOptions,
  type UseApiStatesOptions,
  type UseApiStatesReturn,
} from './useApi'

// useCrud composable and utilities
export {
  useCrud,
  useList,
  type UseCrudOptions,
  type UseCrudReturn,
  type CrudOperation,
  type PaginationState,
  type UseListOptions,
  type UseListReturn,
} from './useCrud'
