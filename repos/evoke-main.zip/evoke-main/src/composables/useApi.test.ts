/**
 * Tests for useApi Composable
 */

import { describe, it, expect, vi } from 'vitest'
import { nextTick } from 'vue'
import { useApi, useLazyApi, useApiStates } from './useApi'
import type { ApiResponse } from '../types'
import { ApiError, ErrorCode } from '../types'

// Helper to create mock API response
function createMockResponse<T>(data: T, status = 200): ApiResponse<T> {
  return {
    data,
    status,
    headers: {},
    duration: 100,
  }
}

// Helper to create mock API error
function createMockError(message: string, code: ErrorCode = ErrorCode.UNKNOWN_ERROR): ApiError {
  return new ApiError(message, code, {})
}

// Helper to wait for promises to resolve
async function flushPromises(): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 0))
  await nextTick()
}

describe('useApi', () => {
  describe('initial state', () => {
    it('should have correct initial state', () => {
      const { data, error, loading, response } = useApi(
        () => Promise.resolve(createMockResponse({ id: 1 }))
      )

      expect(data.value).toBeNull()
      expect(error.value).toBeNull()
      expect(loading.value).toBe(false)
      expect(response.value).toBeNull()
    })

    it('should use initialData when provided', () => {
      const { data } = useApi(
        () => Promise.resolve(createMockResponse({ id: 1 })),
        { initialData: { id: 0 } }
      )

      expect(data.value).toEqual({ id: 0 })
    })
  })

  describe('execute', () => {
    it('should execute the API call and update state', async () => {
      const mockFn = vi.fn().mockResolvedValue(createMockResponse({ name: 'Test' }))
      const { data, loading, execute } = useApi(mockFn)

      const promise = execute()
      expect(loading.value).toBe(true)

      const result = await promise
      expect(loading.value).toBe(false)
      expect(data.value).toEqual({ name: 'Test' })
      expect(result.data).toEqual({ name: 'Test' })
      expect(mockFn).toHaveBeenCalledTimes(1)
    })

    it('should pass arguments to the API function', async () => {
      const mockFn = vi.fn().mockResolvedValue(createMockResponse({ id: 1 }))
      const { execute } = useApi(mockFn)

      await execute('arg1', 123, { key: 'value' })
      expect(mockFn).toHaveBeenCalledWith('arg1', 123, { key: 'value' })
    })

    it('should handle errors correctly', async () => {
      const mockError = createMockError('Request failed', ErrorCode.BAD_REQUEST)
      const mockFn = vi.fn().mockRejectedValue(mockError)
      const { error, loading, execute } = useApi(mockFn)

      await expect(execute()).rejects.toThrow('Request failed')
      expect(loading.value).toBe(false)
      expect(error.value).toBe(mockError)
    })

    it('should reset data before execute when resetOnExecute is true', async () => {
      const mockFn = vi.fn().mockResolvedValue(createMockResponse({ name: 'New' }))
      const { data, execute } = useApi(mockFn, {
        initialData: { name: 'Initial' },
        resetOnExecute: true,
      })

      expect(data.value).toEqual({ name: 'Initial' })

      const promise = execute()
      expect(data.value).toEqual({ name: 'Initial' }) // Reset to initialData

      await promise
      expect(data.value).toEqual({ name: 'New' })
    })

    it('should clear previous error on new execute', async () => {
      let shouldFail = true
      const mockFn = vi.fn().mockImplementation(() => {
        if (shouldFail) {
          return Promise.reject(createMockError('Failed'))
        }
        return Promise.resolve(createMockResponse({ success: true }))
      })

      const { error, execute } = useApi(mockFn)

      await expect(execute()).rejects.toThrow()
      expect(error.value).not.toBeNull()

      shouldFail = false
      await execute()
      expect(error.value).toBeNull()
    })
  })

  describe('refresh', () => {
    it('should re-execute with last arguments', async () => {
      const mockFn = vi.fn().mockResolvedValue(createMockResponse({ id: 1 }))
      const { execute, refresh } = useApi(mockFn)

      await execute('test-arg')
      expect(mockFn).toHaveBeenCalledWith('test-arg')

      await refresh()
      expect(mockFn).toHaveBeenCalledTimes(2)
      expect(mockFn).toHaveBeenLastCalledWith('test-arg')
    })

    it('should throw if execute was never called', async () => {
      const { refresh } = useApi(
        () => Promise.resolve(createMockResponse({ id: 1 }))
      )

      await expect(refresh()).rejects.toThrow('Cannot refresh: execute() has not been called yet')
    })
  })

  describe('abort', () => {
    it('should abort in-progress request', async () => {
      let resolvePromise: (value: ApiResponse<{ id: number }>) => void
      const mockFn = vi.fn().mockImplementation(() => {
        return new Promise(resolve => {
          resolvePromise = resolve
        })
      })

      const { loading, abort, execute } = useApi(mockFn)

      const promise = execute()
      expect(loading.value).toBe(true)

      abort()
      expect(loading.value).toBe(false)

      // Resolve the promise to avoid unhandled rejection
      resolvePromise!(createMockResponse({ id: 1 }))
      await expect(promise).rejects.toThrow('Request was aborted')
    })

    it('should not update state after abort', async () => {
      let resolvePromise: (value: ApiResponse<{ name: string }>) => void
      const mockFn = vi.fn().mockImplementation(() => {
        return new Promise(resolve => {
          resolvePromise = resolve
        })
      })

      const { data, error, abort, execute } = useApi(mockFn)

      execute().catch(() => {}) // Ignore the error from abort
      abort()

      // Try to resolve after abort
      resolvePromise!(createMockResponse({ name: 'Should not appear' }))
      await flushPromises()

      expect(data.value).toBeNull()
      expect(error.value).toBeNull()
    })
  })

  describe('reset', () => {
    it('should reset all state to initial values', async () => {
      const mockFn = vi.fn().mockResolvedValue(createMockResponse({ name: 'Test' }))
      const { data, response, execute, reset } = useApi(mockFn, {
        initialData: { name: 'Initial' },
      })

      await execute()
      expect(data.value).toEqual({ name: 'Test' })
      expect(response.value).not.toBeNull()

      reset()
      expect(data.value).toEqual({ name: 'Initial' })
      expect(response.value).toBeNull()
    })
  })

  describe('clearError', () => {
    it('should clear only the error state', async () => {
      const mockFn = vi.fn().mockRejectedValue(createMockError('Failed'))
      const { data, error, execute, clearError } = useApi(mockFn, {
        initialData: { id: 1 },
      })

      await expect(execute()).rejects.toThrow()
      expect(error.value).not.toBeNull()
      expect(data.value).toEqual({ id: 1 })

      clearError()
      expect(error.value).toBeNull()
      expect(data.value).toEqual({ id: 1 }) // Data unchanged
    })
  })

  describe('callbacks', () => {
    it('should call onSuccess callback on success', async () => {
      const onSuccess = vi.fn()
      const mockResponse = createMockResponse({ name: 'Test' })
      const mockFn = vi.fn().mockResolvedValue(mockResponse)

      const { execute } = useApi(mockFn, { onSuccess })

      await execute()
      expect(onSuccess).toHaveBeenCalledWith({ name: 'Test' }, mockResponse)
    })

    it('should call onError callback on error', async () => {
      const onError = vi.fn()
      const mockError = createMockError('Failed')
      const mockFn = vi.fn().mockRejectedValue(mockError)

      const { execute } = useApi(mockFn, { onError })

      await expect(execute()).rejects.toThrow()
      expect(onError).toHaveBeenCalledWith(mockError)
    })

    it('should call onFinally callback always', async () => {
      const onFinally = vi.fn()

      // On success
      const { execute: executeSuccess } = useApi(
        () => Promise.resolve(createMockResponse({ id: 1 })),
        { onFinally }
      )
      await executeSuccess()
      expect(onFinally).toHaveBeenCalledTimes(1)

      // On error
      const { execute: executeError } = useApi(
        () => Promise.reject(createMockError('Failed')),
        { onFinally }
      )
      await expect(executeError()).rejects.toThrow()
      expect(onFinally).toHaveBeenCalledTimes(2)
    })
  })

  describe('immediate option', () => {
    it('should execute immediately when immediate is true', async () => {
      const mockFn = vi.fn().mockResolvedValue(createMockResponse({ id: 1 }))

      const { data } = useApi(mockFn, { immediate: true })

      await flushPromises()
      expect(mockFn).toHaveBeenCalledTimes(1)
      expect(data.value).toEqual({ id: 1 })
    })
  })

  describe('readonly state', () => {
    it('should return readonly refs', () => {
      const { data, error, loading, response } = useApi(
        () => Promise.resolve(createMockResponse({ id: 1 }))
      )

      // These should be readonly - attempting to assign should be a type error
      // We can't test compile-time errors, but we can verify they work as expected
      expect(data.value).toBeNull()
      expect(error.value).toBeNull()
      expect(loading.value).toBe(false)
      expect(response.value).toBeNull()
    })
  })
})

describe('useLazyApi', () => {
  it('should not execute immediately', async () => {
    const mockFn = vi.fn().mockResolvedValue(createMockResponse({ id: 1 }))

    useLazyApi(mockFn)

    await flushPromises()
    expect(mockFn).not.toHaveBeenCalled()
  })

  it('should work the same as useApi otherwise', async () => {
    const mockFn = vi.fn().mockResolvedValue(createMockResponse({ name: 'Test' }))
    const { data, execute } = useLazyApi(mockFn)

    await execute()
    expect(data.value).toEqual({ name: 'Test' })
  })
})

describe('useApiStates', () => {
  it('should track loading states', () => {
    const states = useApiStates()

    expect(states.isLoading('users')).toBe(false)
    expect(states.isAnyLoading()).toBe(false)

    states.setLoading('users', true)
    expect(states.isLoading('users')).toBe(true)
    expect(states.isAnyLoading()).toBe(true)

    states.setLoading('users', false)
    expect(states.isLoading('users')).toBe(false)
    expect(states.isAnyLoading()).toBe(false)
  })

  it('should track multiple loading states', () => {
    const states = useApiStates()

    states.setLoading('users', true)
    states.setLoading('posts', true)
    expect(states.isAnyLoading()).toBe(true)

    states.setLoading('users', false)
    expect(states.isAnyLoading()).toBe(true) // posts still loading

    states.setLoading('posts', false)
    expect(states.isAnyLoading()).toBe(false)
  })

  it('should track error states', () => {
    const states = useApiStates()
    const mockError = createMockError('Failed')

    expect(states.getError('users')).toBeNull()

    states.setError('users', mockError)
    expect(states.getError('users')).toBe(mockError)

    states.setError('users', null)
    expect(states.getError('users')).toBeNull()
  })

  it('should call onError callback when error is set', () => {
    const onError = vi.fn()
    const states = useApiStates({ onError })
    const mockError = createMockError('Failed')

    states.setError('users', mockError)
    expect(onError).toHaveBeenCalledWith('users', mockError)
  })

  it('should reset all states', () => {
    const states = useApiStates()
    const mockError = createMockError('Failed')

    states.setLoading('users', true)
    states.setLoading('posts', true)
    states.setError('users', mockError)

    states.reset()

    expect(states.isLoading('users')).toBe(false)
    expect(states.isLoading('posts')).toBe(false)
    expect(states.getError('users')).toBeNull()
  })
})
