/**
 * useCrud Composable
 * Vue 3 Composition API wrapper for CRUD operations
 *
 * Provides reactive state management for common Create, Read, Update, Delete
 * operations with built-in pagination support.
 */

import { ref, computed, readonly, type Ref, type ComputedRef, type DeepReadonly } from 'vue'
import type { CrudService, Entity, ListOptions, FilterParams } from '../services/crud-service'
import type { ApiResponse, PaginatedResponse } from '../types'
import type { ApiError } from '../types/errors'

/**
 * Options for configuring the useCrud composable
 */
export interface UseCrudOptions<T extends Entity> {
  /**
   * Fetch the list immediately when the composable is created
   * @default false
   */
  immediate?: boolean

  /**
   * Initial list options (page, pageSize, filters, etc.)
   */
  initialOptions?: ListOptions

  /**
   * Default page size for list requests
   * @default 20
   */
  defaultPageSize?: number

  /**
   * Callback when any operation succeeds
   */
  onSuccess?: (operation: CrudOperation, data: T | T[] | void) => void

  /**
   * Callback when any operation fails
   */
  onError?: (operation: CrudOperation, error: ApiError) => void

  /**
   * Transform list response before storing
   */
  transformList?: (response: PaginatedResponse<T>) => PaginatedResponse<T>

  /**
   * Transform single item response before storing
   */
  transformItem?: (item: T) => T
}

/**
 * CRUD operation types
 */
export type CrudOperation = 'list' | 'get' | 'create' | 'update' | 'patch' | 'delete'

/**
 * Pagination state
 */
export interface PaginationState {
  page: number
  pageSize: number
  total: number
  totalPages: number
  hasMore: boolean
  hasPrev: boolean
  hasNext: boolean
}

/**
 * Return type for the useCrud composable
 */
export interface UseCrudReturn<T extends Entity, CreateDTO, UpdateDTO> {
  // === List State ===
  /**
   * Array of items from the last list request
   */
  items: DeepReadonly<Ref<T[]>>

  /**
   * Pagination state computed from list response
   */
  pagination: ComputedRef<PaginationState>

  // === Single Item State ===
  /**
   * Single item from the last get request
   */
  item: DeepReadonly<Ref<T | null>>

  // === Loading States ===
  /**
   * True if any operation is in progress
   */
  loading: ComputedRef<boolean>

  /**
   * True if list operation is in progress
   */
  listLoading: DeepReadonly<Ref<boolean>>

  /**
   * True if get operation is in progress
   */
  itemLoading: DeepReadonly<Ref<boolean>>

  /**
   * True if create operation is in progress
   */
  creating: DeepReadonly<Ref<boolean>>

  /**
   * True if update/patch operation is in progress
   */
  updating: DeepReadonly<Ref<boolean>>

  /**
   * True if delete operation is in progress
   */
  deleting: DeepReadonly<Ref<boolean>>

  // === Error State ===
  /**
   * Error from the last failed operation
   */
  error: DeepReadonly<Ref<ApiError | null>>

  /**
   * The operation that caused the last error
   */
  errorOperation: DeepReadonly<Ref<CrudOperation | null>>

  // === CRUD Operations ===
  /**
   * Fetch paginated list of items
   */
  list: (options?: ListOptions) => Promise<PaginatedResponse<T>>

  /**
   * Fetch all items (non-paginated)
   */
  getAll: () => Promise<T[]>

  /**
   * Fetch a single item by ID
   */
  get: (id: string | number) => Promise<T>

  /**
   * Create a new item
   */
  create: (data: CreateDTO) => Promise<T>

  /**
   * Update an item (full replacement)
   */
  update: (id: string | number, data: UpdateDTO) => Promise<T>

  /**
   * Partially update an item
   */
  patch: (id: string | number, data: UpdateDTO) => Promise<T>

  /**
   * Delete an item
   * Named 'remove' to avoid conflict with JS delete keyword
   */
  remove: (id: string | number) => Promise<void>

  // === Pagination Helpers ===
  /**
   * Go to the next page
   */
  nextPage: () => Promise<PaginatedResponse<T>>

  /**
   * Go to the previous page
   */
  prevPage: () => Promise<PaginatedResponse<T>>

  /**
   * Go to a specific page
   */
  goToPage: (page: number) => Promise<PaginatedResponse<T>>

  /**
   * Change page size (resets to page 1)
   */
  setPageSize: (size: number) => Promise<PaginatedResponse<T>>

  /**
   * Update filters and refresh the list
   */
  setFilters: (filters: FilterParams) => Promise<PaginatedResponse<T>>

  // === Refresh & State Management ===
  /**
   * Refresh the current list with the same options
   */
  refresh: () => Promise<PaginatedResponse<T>>

  /**
   * Refresh a single item by ID
   */
  refreshItem: (id: string | number) => Promise<T>

  /**
   * Reset all state to initial values
   */
  reset: () => void

  /**
   * Clear only the error state
   */
  clearError: () => void

  /**
   * Clear the current item
   */
  clearItem: () => void

  // === Local State Updates ===
  /**
   * Optimistically add an item to the list (without API call)
   */
  addItem: (item: T) => void

  /**
   * Optimistically update an item in the list (without API call)
   */
  updateItem: (id: string | number, updates: Partial<T>) => void

  /**
   * Optimistically remove an item from the list (without API call)
   */
  removeItem: (id: string | number) => void

  /**
   * Find an item in the list by ID
   */
  findItem: (id: string | number) => T | undefined
}

/**
 * Create a reactive CRUD operations wrapper
 *
 * @category Composables
 * @param service - CrudService instance to wrap
 * @param options - Configuration options
 * @returns Reactive state and CRUD methods
 *
 * @example
 * ```typescript
 * // Setup
 * const userService = createCrudService<User, CreateUserDTO>(client, {
 *   basePath: '/users'
 * })
 *
 * const {
 *   items,
 *   pagination,
 *   loading,
 *   error,
 *   list,
 *   create,
 *   update,
 *   remove,
 *   nextPage,
 * } = useCrud(userService, { immediate: true })
 *
 * // In template
 * <div v-if="loading">Loading...</div>
 * <div v-else-if="error">{{ error.message }}</div>
 * <ul v-else>
 *   <li v-for="user in items" :key="user.id">{{ user.name }}</li>
 * </ul>
 * <button @click="nextPage" :disabled="!pagination.hasNext">Next</button>
 * ```
 */
export function useCrud<
  T extends Entity,
  CreateDTO = Omit<T, 'id'>,
  UpdateDTO = Partial<Omit<T, 'id'>>,
>(
  service: CrudService<T, CreateDTO, UpdateDTO>,
  options: UseCrudOptions<T> = {}
): UseCrudReturn<T, CreateDTO, UpdateDTO> {
  const {
    immediate = false,
    initialOptions,
    defaultPageSize = 20,
    onSuccess,
    onError,
    transformList,
    transformItem,
  } = options

  // === List State ===
  const items = ref<T[]>([]) as Ref<T[]>
  const total = ref(0)
  const page = ref(initialOptions?.page ?? 1)
  const pageSize = ref(initialOptions?.pageSize ?? defaultPageSize)
  const totalPages = ref(0)
  const hasMore = ref(false)

  // === Single Item State ===
  const item = ref<T | null>(null) as Ref<T | null>

  // === Loading States ===
  const listLoading = ref(false)
  const itemLoading = ref(false)
  const creating = ref(false)
  const updating = ref(false)
  const deleting = ref(false)

  // === Error State ===
  const error = ref<ApiError | null>(null)
  const errorOperation = ref<CrudOperation | null>(null)

  // === Current Options ===
  let currentFilters: FilterParams = initialOptions?.filters ?? {}
  let currentParams = initialOptions?.params ?? {}
  let currentSort = {
    sortBy: initialOptions?.sortBy,
    sortOrder: initialOptions?.sortOrder,
  }

  // === Computed Properties ===
  const loading = computed(() =>
    listLoading.value ||
    itemLoading.value ||
    creating.value ||
    updating.value ||
    deleting.value
  )

  const pagination = computed<PaginationState>(() => ({
    page: page.value,
    pageSize: pageSize.value,
    total: total.value,
    totalPages: totalPages.value,
    hasMore: hasMore.value,
    hasPrev: page.value > 1,
    hasNext: hasMore.value || page.value < totalPages.value,
  }))

  // === Helper Functions ===
  function handleError(operation: CrudOperation, err: unknown): never {
    const apiError = err as ApiError
    error.value = apiError
    errorOperation.value = operation
    onError?.(operation, apiError)
    throw apiError
  }

  function handleSuccess(operation: CrudOperation, data: T | T[] | void): void {
    error.value = null
    errorOperation.value = null
    onSuccess?.(operation, data)
  }

  function buildListOptions(): ListOptions {
    const options: ListOptions = {
      page: page.value,
      pageSize: pageSize.value,
      filters: currentFilters,
      params: currentParams,
    }

    // Only include sort options if they are defined
    if (currentSort.sortBy !== undefined) {
      options.sortBy = currentSort.sortBy
    }
    if (currentSort.sortOrder !== undefined) {
      options.sortOrder = currentSort.sortOrder
    }

    return options
  }

  function updatePaginationState(response: PaginatedResponse<T>): void {
    total.value = response.total
    page.value = response.page
    pageSize.value = response.pageSize
    totalPages.value = response.totalPages
    hasMore.value = response.hasMore
  }

  // === CRUD Operations ===
  async function list(listOptions?: ListOptions): Promise<PaginatedResponse<T>> {
    listLoading.value = true

    // Update current options if provided
    if (listOptions) {
      if (listOptions.page !== undefined) page.value = listOptions.page
      if (listOptions.pageSize !== undefined) pageSize.value = listOptions.pageSize
      if (listOptions.filters !== undefined) currentFilters = listOptions.filters
      if (listOptions.params !== undefined) currentParams = listOptions.params
      if (listOptions.sortBy !== undefined) currentSort.sortBy = listOptions.sortBy
      if (listOptions.sortOrder !== undefined) currentSort.sortOrder = listOptions.sortOrder
    }

    try {
      const response = await service.list(buildListOptions())
      let data = response.data

      // Apply transform if provided
      if (transformList) {
        data = transformList(data)
      }

      // Update state
      items.value = data.items
      updatePaginationState(data)

      handleSuccess('list', data.items)
      return data
    } catch (err) {
      handleError('list', err)
    } finally {
      listLoading.value = false
    }
  }

  async function getAll(): Promise<T[]> {
    listLoading.value = true

    try {
      const response = await service.getAll()
      items.value = response.data

      handleSuccess('list', response.data)
      return response.data
    } catch (err) {
      handleError('list', err)
    } finally {
      listLoading.value = false
    }
  }

  async function get(id: string | number): Promise<T> {
    itemLoading.value = true

    try {
      const response = await service.get(id)
      let data = response.data

      // Apply transform if provided
      if (transformItem) {
        data = transformItem(data)
      }

      item.value = data

      handleSuccess('get', data)
      return data
    } catch (err) {
      handleError('get', err)
    } finally {
      itemLoading.value = false
    }
  }

  async function create(data: CreateDTO): Promise<T> {
    creating.value = true

    try {
      const response = await service.create(data)
      let created = response.data

      // Apply transform if provided
      if (transformItem) {
        created = transformItem(created)
      }

      // Add to list if loaded
      items.value = [...items.value, created]
      total.value += 1

      handleSuccess('create', created)
      return created
    } catch (err) {
      handleError('create', err)
    } finally {
      creating.value = false
    }
  }

  async function update(id: string | number, data: UpdateDTO): Promise<T> {
    updating.value = true

    try {
      const response = await service.update(id, data)
      let updated = response.data

      // Apply transform if provided
      if (transformItem) {
        updated = transformItem(updated)
      }

      // Update in list
      updateItemInList(id, updated)

      // Update current item if same
      if (item.value && item.value.id === id) {
        item.value = updated
      }

      handleSuccess('update', updated)
      return updated
    } catch (err) {
      handleError('update', err)
    } finally {
      updating.value = false
    }
  }

  async function patch(id: string | number, data: UpdateDTO): Promise<T> {
    updating.value = true

    try {
      const response = await service.patch(id, data)
      let patched = response.data

      // Apply transform if provided
      if (transformItem) {
        patched = transformItem(patched)
      }

      // Update in list
      updateItemInList(id, patched)

      // Update current item if same
      if (item.value && item.value.id === id) {
        item.value = patched
      }

      handleSuccess('patch', patched)
      return patched
    } catch (err) {
      handleError('patch', err)
    } finally {
      updating.value = false
    }
  }

  async function remove(id: string | number): Promise<void> {
    deleting.value = true

    try {
      await service.delete(id)

      // Remove from list
      removeItemFromList(id)

      // Clear current item if same
      if (item.value && item.value.id === id) {
        item.value = null
      }

      handleSuccess('delete', undefined)
    } catch (err) {
      handleError('delete', err)
    } finally {
      deleting.value = false
    }
  }

  // === Pagination Helpers ===
  async function nextPage(): Promise<PaginatedResponse<T>> {
    if (page.value < totalPages.value) {
      return list({ page: page.value + 1 })
    }
    return {
      items: items.value,
      total: total.value,
      page: page.value,
      pageSize: pageSize.value,
      totalPages: totalPages.value,
      hasMore: hasMore.value,
    }
  }

  async function prevPage(): Promise<PaginatedResponse<T>> {
    if (page.value > 1) {
      return list({ page: page.value - 1 })
    }
    return {
      items: items.value,
      total: total.value,
      page: page.value,
      pageSize: pageSize.value,
      totalPages: totalPages.value,
      hasMore: hasMore.value,
    }
  }

  async function goToPage(targetPage: number): Promise<PaginatedResponse<T>> {
    const validPage = Math.max(1, Math.min(targetPage, totalPages.value || targetPage))
    return list({ page: validPage })
  }

  async function setPageSize(size: number): Promise<PaginatedResponse<T>> {
    return list({ pageSize: size, page: 1 })
  }

  async function setFilters(filters: FilterParams): Promise<PaginatedResponse<T>> {
    currentFilters = filters
    return list({ page: 1 })
  }

  // === Refresh & State Management ===
  async function refresh(): Promise<PaginatedResponse<T>> {
    return list()
  }

  async function refreshItem(id: string | number): Promise<T> {
    return get(id)
  }

  function reset(): void {
    items.value = []
    item.value = null
    total.value = 0
    page.value = initialOptions?.page ?? 1
    pageSize.value = initialOptions?.pageSize ?? defaultPageSize
    totalPages.value = 0
    hasMore.value = false
    error.value = null
    errorOperation.value = null
    currentFilters = initialOptions?.filters ?? {}
    currentParams = initialOptions?.params ?? {}
    currentSort = {
      sortBy: initialOptions?.sortBy,
      sortOrder: initialOptions?.sortOrder,
    }
  }

  function clearError(): void {
    error.value = null
    errorOperation.value = null
  }

  function clearItem(): void {
    item.value = null
  }

  // === Local State Updates (Optimistic Updates) ===
  function addItem(newItem: T): void {
    items.value = [...items.value, newItem]
    total.value += 1
  }

  function updateItem(id: string | number, updates: Partial<T>): void {
    const index = items.value.findIndex(i => i.id === id)
    if (index !== -1) {
      const updatedItem = { ...items.value[index], ...updates } as T
      items.value = [
        ...items.value.slice(0, index),
        updatedItem,
        ...items.value.slice(index + 1),
      ]
    }
  }

  function updateItemInList(id: string | number, updated: T): void {
    const index = items.value.findIndex(i => i.id === id)
    if (index !== -1) {
      items.value = [
        ...items.value.slice(0, index),
        updated,
        ...items.value.slice(index + 1),
      ]
    }
  }

  function removeItem(id: string | number): void {
    removeItemFromList(id)
  }

  function removeItemFromList(id: string | number): void {
    items.value = items.value.filter(i => i.id !== id)
    total.value = Math.max(0, total.value - 1)
  }

  function findItem(id: string | number): T | undefined {
    return items.value.find(i => i.id === id)
  }

  // Execute immediately if configured
  if (immediate) {
    list()
  }

  return {
    // List State
    items: readonly(items) as DeepReadonly<Ref<T[]>>,
    pagination,

    // Single Item State
    item: readonly(item) as DeepReadonly<Ref<T | null>>,

    // Loading States
    loading,
    listLoading: readonly(listLoading),
    itemLoading: readonly(itemLoading),
    creating: readonly(creating),
    updating: readonly(updating),
    deleting: readonly(deleting),

    // Error State
    error: readonly(error) as DeepReadonly<Ref<ApiError | null>>,
    errorOperation: readonly(errorOperation) as DeepReadonly<Ref<CrudOperation | null>>,

    // CRUD Operations
    list,
    getAll,
    get,
    create,
    update,
    patch,
    remove,

    // Pagination Helpers
    nextPage,
    prevPage,
    goToPage,
    setPageSize,
    setFilters,

    // Refresh & State Management
    refresh,
    refreshItem,
    reset,
    clearError,
    clearItem,

    // Local State Updates
    addItem,
    updateItem,
    removeItem,
    findItem,
  }
}

/**
 * Lightweight version of useCrud for simple list operations only
 *
 * @example
 * ```typescript
 * const { items, loading, fetch } = useList(
 *   () => client.get<User[]>('/users')
 * )
 * ```
 */
export interface UseListOptions<T> {
  immediate?: boolean
  initialData?: T[]
  onSuccess?: (data: T[]) => void
  onError?: (error: ApiError) => void
}

export interface UseListReturn<T> {
  items: DeepReadonly<Ref<T[]>>
  loading: DeepReadonly<Ref<boolean>>
  error: DeepReadonly<Ref<ApiError | null>>
  fetch: () => Promise<T[]>
  reset: () => void
}

/**
 * Lightweight composable for simple list operations
 *
 * @category Composables
 */
export function useList<T>(
  fn: () => Promise<ApiResponse<T[]>>,
  options: UseListOptions<T> = {}
): UseListReturn<T> {
  const {
    immediate = false,
    initialData = [],
    onSuccess,
    onError,
  } = options

  const items = ref<T[]>(initialData) as Ref<T[]>
  const loading = ref(false)
  const error = ref<ApiError | null>(null)

  async function fetch(): Promise<T[]> {
    loading.value = true
    error.value = null

    try {
      const response = await fn()
      items.value = response.data
      onSuccess?.(response.data)
      return response.data
    } catch (err) {
      const apiError = err as ApiError
      error.value = apiError
      onError?.(apiError)
      throw apiError
    } finally {
      loading.value = false
    }
  }

  function reset(): void {
    items.value = initialData
    error.value = null
  }

  if (immediate) {
    fetch()
  }

  return {
    items: readonly(items) as DeepReadonly<Ref<T[]>>,
    loading: readonly(loading),
    error: readonly(error) as DeepReadonly<Ref<ApiError | null>>,
    fetch,
    reset,
  }
}
