/**
 * useApi Composable
 * Vue 3 Composition API wrapper for reactive API calls
 *
 * Provides reactive state management for async API operations
 * with loading states, error handling, and lifecycle hooks.
 */

import { ref, shallowRef, readonly, type Ref, type DeepReadonly } from 'vue'
import type { ApiResponse } from '../types'
import type { ApiError } from '../types/errors'

/**
 * Options for configuring the useApi composable
 */
export interface UseApiOptions<T> {
  /**
   * Execute the API call immediately when the composable is created
   * @default false
   */
  immediate?: boolean

  /**
   * Initial value for the data ref before any request
   */
  initialData?: T

  /**
   * Reset data to initialData/null before executing a new request
   * @default false
   */
  resetOnExecute?: boolean

  /**
   * Callback when request succeeds
   */
  onSuccess?: (data: T, response: ApiResponse<T>) => void

  /**
   * Callback when request fails
   */
  onError?: (error: ApiError) => void

  /**
   * Callback when request finishes (success or failure)
   */
  onFinally?: () => void
}

/**
 * Return type for the useApi composable
 */
export interface UseApiReturn<T, Args extends unknown[]> {
  /**
   * The response data (reactive)
   */
  data: DeepReadonly<Ref<T | null>>

  /**
   * Error from the last failed request (reactive)
   */
  error: DeepReadonly<Ref<ApiError | null>>

  /**
   * Whether a request is currently in progress (reactive)
   */
  loading: DeepReadonly<Ref<boolean>>

  /**
   * Full API response from the last successful request
   */
  response: DeepReadonly<Ref<ApiResponse<T> | null>>

  /**
   * Execute the API call with the provided arguments
   * Returns the ApiResponse on success, throws on error
   */
  execute: (...args: Args) => Promise<ApiResponse<T>>

  /**
   * Re-execute with the last used arguments
   * Throws if execute() was never called
   */
  refresh: () => Promise<ApiResponse<T>>

  /**
   * Abort any in-progress request
   */
  abort: () => void

  /**
   * Reset all state to initial values
   */
  reset: () => void

  /**
   * Clear only the error state
   */
  clearError: () => void
}

/**
 * Create a reactive API call wrapper
 *
 * @category Composables
 * @param fn - Async function that returns an ApiResponse
 * @param options - Configuration options
 * @returns Reactive state and control methods
 *
 * @example
 * ```typescript
 * // Basic usage
 * const { data, loading, error, execute } = useApi(
 *   (id: string) => client.get<User>(`/users/${id}`)
 * )
 *
 * // Execute the request
 * await execute('123')
 *
 * // With immediate execution
 * const { data, loading } = useApi(
 *   () => client.get<User[]>('/users'),
 *   { immediate: true }
 * )
 *
 * // With callbacks
 * const { execute } = useApi(
 *   (data: CreateUserDTO) => client.post<User>('/users', data),
 *   {
 *     onSuccess: (user) => console.log('Created:', user),
 *     onError: (error) => toast.error(error.message),
 *   }
 * )
 * ```
 */
export function useApi<T, Args extends unknown[] = []>(
  fn: (...args: Args) => Promise<ApiResponse<T>>,
  options: UseApiOptions<T> = {}
): UseApiReturn<T, Args> {
  const {
    immediate = false,
    initialData,
    resetOnExecute = false,
    onSuccess,
    onError,
    onFinally,
  } = options

  // State
  const data = shallowRef<T | null>(initialData ?? null) as Ref<T | null>
  const error = ref<ApiError | null>(null)
  const loading = ref(false)
  const response = shallowRef<ApiResponse<T> | null>(null)

  // Track last arguments for refresh
  let lastArgs: Args | null = null

  // AbortController for request cancellation
  let abortController: AbortController | null = null

  /**
   * Execute the API call
   */
  async function execute(...args: Args): Promise<ApiResponse<T>> {
    // Store args for refresh
    lastArgs = args

    // Abort any pending request
    if (abortController) {
      abortController.abort()
    }
    abortController = new AbortController()

    // Capture a local reference to check abort status
    // This is needed because abort() may set abortController to null
    const currentController = abortController

    // Reset state if configured
    if (resetOnExecute) {
      data.value = initialData ?? null
    }
    error.value = null
    loading.value = true

    try {
      const result = await fn(...args)

      // Check if aborted (use local reference)
      if (currentController.signal.aborted) {
        throw new Error('Request was aborted')
      }

      // Update state
      data.value = result.data
      response.value = result

      // Call success hook
      onSuccess?.(result.data, result)

      return result
    } catch (err) {
      // Don't update error state if aborted (use local reference)
      if (currentController.signal.aborted) {
        throw err
      }

      const apiError = err as ApiError
      error.value = apiError

      // Call error hook
      onError?.(apiError)

      throw apiError
    } finally {
      loading.value = false
      abortController = null

      // Call finally hook
      onFinally?.()
    }
  }

  /**
   * Re-execute with last used arguments
   */
  async function refresh(): Promise<ApiResponse<T>> {
    if (lastArgs === null) {
      throw new Error('Cannot refresh: execute() has not been called yet')
    }
    return execute(...lastArgs)
  }

  /**
   * Abort the current request
   */
  function abort(): void {
    if (abortController) {
      abortController.abort()
      abortController = null
      loading.value = false
    }
  }

  /**
   * Reset all state to initial values
   */
  function reset(): void {
    abort()
    data.value = initialData ?? null
    error.value = null
    loading.value = false
    response.value = null
    lastArgs = null
  }

  /**
   * Clear only the error state
   */
  function clearError(): void {
    error.value = null
  }

  // Execute immediately if configured
  if (immediate) {
    execute(...([] as unknown as Args))
  }

  return {
    data: readonly(data) as DeepReadonly<Ref<T | null>>,
    error: readonly(error) as DeepReadonly<Ref<ApiError | null>>,
    loading: readonly(loading),
    response: readonly(response) as DeepReadonly<Ref<ApiResponse<T> | null>>,
    execute,
    refresh,
    abort,
    reset,
    clearError,
  }
}

/**
 * Options for lazy API calls (deferred execution)
 */
export interface UseLazyApiOptions<T> extends Omit<UseApiOptions<T>, 'immediate'> {
  /**
   * Default arguments to use when execute() is called without args
   */
  defaultArgs?: unknown[]
}

/**
 * Create a lazy API call that must be explicitly executed
 * Alias for useApi with immediate: false
 *
 * @category Composables
 */
export function useLazyApi<T, Args extends unknown[] = []>(
  fn: (...args: Args) => Promise<ApiResponse<T>>,
  options: UseLazyApiOptions<T> = {}
): UseApiReturn<T, Args> {
  return useApi(fn, { ...options, immediate: false })
}

/**
 * Options for creating multiple API state instances
 */
export interface UseApiStatesOptions {
  /**
   * Shared error handler for all states
   */
  onError?: (key: string, error: ApiError) => void
}

/**
 * Track loading state across multiple API calls
 */
export interface UseApiStatesReturn {
  /**
   * Check if any request is loading
   */
  isAnyLoading: () => boolean

  /**
   * Check if a specific key is loading
   */
  isLoading: (key: string) => boolean

  /**
   * Get error for a specific key
   */
  getError: (key: string) => ApiError | null

  /**
   * Set loading state for a key
   */
  setLoading: (key: string, value: boolean) => void

  /**
   * Set error for a key
   */
  setError: (key: string, error: ApiError | null) => void

  /**
   * Clear all loading states and errors
   */
  reset: () => void
}

/**
 * Create a shared state tracker for multiple API calls
 *
 * @category Composables
 * @example
 * ```typescript
 * const states = useApiStates()
 *
 * async function fetchData() {
 *   states.setLoading('users', true)
 *   try {
 *     await client.get('/users')
 *   } catch (err) {
 *     states.setError('users', err)
 *   } finally {
 *     states.setLoading('users', false)
 *   }
 * }
 *
 * // In template
 * <div v-if="states.isLoading('users')">Loading...</div>
 * ```
 */
export function useApiStates(options: UseApiStatesOptions = {}): UseApiStatesReturn {
  const loadingStates = ref<Record<string, boolean>>({})
  const errorStates = ref<Record<string, ApiError | null>>({})

  function isAnyLoading(): boolean {
    return Object.values(loadingStates.value).some(Boolean)
  }

  function isLoading(key: string): boolean {
    return loadingStates.value[key] ?? false
  }

  function getError(key: string): ApiError | null {
    return errorStates.value[key] ?? null
  }

  function setLoading(key: string, value: boolean): void {
    loadingStates.value[key] = value
  }

  function setError(key: string, error: ApiError | null): void {
    errorStates.value[key] = error
    if (error && options.onError) {
      options.onError(key, error)
    }
  }

  function reset(): void {
    loadingStates.value = {}
    errorStates.value = {}
  }

  return {
    isAnyLoading,
    isLoading,
    getError,
    setLoading,
    setError,
    reset,
  }
}
