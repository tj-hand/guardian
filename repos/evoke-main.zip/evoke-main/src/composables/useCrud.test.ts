/**
 * Tests for useCrud Composable
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { nextTick } from 'vue'
import { useCrud, useList } from './useCrud'
import type { CrudService, Entity, ListOptions } from '../services/crud-service'
import type { ApiResponse, PaginatedResponse } from '../types'
import { ApiError, ErrorCode } from '../types'

// Test entity type
interface TestUser extends Entity {
  id: string
  name: string
  email: string
}

// Test DTOs
interface CreateUserDTO {
  name: string
  email: string
}

interface UpdateUserDTO {
  name?: string
  email?: string
}

// Helper to create mock API response
function createMockResponse<T>(data: T, status = 200): ApiResponse<T> {
  return {
    data,
    status,
    headers: {},
    duration: 100,
  }
}

// Helper to create paginated response
function createPaginatedResponse<T>(
  items: T[],
  page = 1,
  pageSize = 20,
  total = items.length
): PaginatedResponse<T> {
  const totalPages = Math.ceil(total / pageSize)
  return {
    items,
    total,
    page,
    pageSize,
    totalPages,
    hasMore: page < totalPages,
  }
}

// Helper to create mock error
function createMockError(message: string, code: ErrorCode = ErrorCode.UNKNOWN_ERROR): ApiError {
  return new ApiError(message, code, {})
}

// Create mock service
function createMockService(): CrudService<TestUser, CreateUserDTO, UpdateUserDTO> {
  return {
    getAll: vi.fn(),
    list: vi.fn(),
    get: vi.fn(),
    create: vi.fn(),
    update: vi.fn(),
    patch: vi.fn(),
    delete: vi.fn(),
    exists: vi.fn(),
    getBasePath: vi.fn().mockReturnValue('/users'),
  } as unknown as CrudService<TestUser, CreateUserDTO, UpdateUserDTO>
}

// Wait for promises to resolve
async function flushPromises(): Promise<void> {
  await new Promise(resolve => setTimeout(resolve, 0))
  await nextTick()
}

describe('useCrud', () => {
  let mockService: CrudService<TestUser, CreateUserDTO, UpdateUserDTO>

  beforeEach(() => {
    mockService = createMockService()
  })

  describe('initial state', () => {
    it('should have correct initial state', () => {
      const {
        items,
        item,
        pagination,
        loading,
        listLoading,
        itemLoading,
        creating,
        updating,
        deleting,
        error,
        errorOperation,
      } = useCrud(mockService)

      expect(items.value).toEqual([])
      expect(item.value).toBeNull()
      expect(pagination.value.page).toBe(1)
      expect(pagination.value.pageSize).toBe(20)
      expect(pagination.value.total).toBe(0)
      expect(loading.value).toBe(false)
      expect(listLoading.value).toBe(false)
      expect(itemLoading.value).toBe(false)
      expect(creating.value).toBe(false)
      expect(updating.value).toBe(false)
      expect(deleting.value).toBe(false)
      expect(error.value).toBeNull()
      expect(errorOperation.value).toBeNull()
    })

    it('should use initialOptions when provided', () => {
      const { pagination } = useCrud(mockService, {
        initialOptions: {
          page: 2,
          pageSize: 50,
        },
      })

      expect(pagination.value.page).toBe(2)
      expect(pagination.value.pageSize).toBe(50)
    })

    it('should use defaultPageSize when provided', () => {
      const { pagination } = useCrud(mockService, {
        defaultPageSize: 10,
      })

      expect(pagination.value.pageSize).toBe(10)
    })
  })

  describe('list operation', () => {
    it('should fetch list and update state', async () => {
      const users: TestUser[] = [
        { id: '1', name: 'Alice', email: 'alice@test.com' },
        { id: '2', name: 'Bob', email: 'bob@test.com' },
      ]
      const paginatedResponse = createPaginatedResponse(users, 1, 20, 2)
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(paginatedResponse)
      )

      const { items, pagination, listLoading, list } = useCrud(mockService)

      const promise = list()
      expect(listLoading.value).toBe(true)

      const result = await promise
      expect(listLoading.value).toBe(false)
      expect(items.value).toEqual(users)
      expect(pagination.value.total).toBe(2)
      expect(result.items).toEqual(users)
    })

    it('should update options when listing with new options', async () => {
      const paginatedResponse = createPaginatedResponse([], 2, 10, 20)
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(paginatedResponse)
      )

      const { pagination, list } = useCrud(mockService)

      await list({ page: 2, pageSize: 10 })
      expect(pagination.value.page).toBe(2)
      expect(pagination.value.pageSize).toBe(10)
    })

    it('should handle list errors', async () => {
      const mockError = createMockError('Fetch failed', ErrorCode.INTERNAL_SERVER_ERROR)
      vi.mocked(mockService.list).mockRejectedValue(mockError)

      const { error, errorOperation, list } = useCrud(mockService)

      await expect(list()).rejects.toThrow('Fetch failed')
      expect(error.value).toBe(mockError)
      expect(errorOperation.value).toBe('list')
    })

    it('should call onSuccess callback on list', async () => {
      const users: TestUser[] = [{ id: '1', name: 'Alice', email: 'alice@test.com' }]
      const onSuccess = vi.fn()
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse(users))
      )

      const { list } = useCrud(mockService, { onSuccess })

      await list()
      expect(onSuccess).toHaveBeenCalledWith('list', users)
    })

    it('should call onError callback on list error', async () => {
      const onError = vi.fn()
      const mockError = createMockError('Failed')
      vi.mocked(mockService.list).mockRejectedValue(mockError)

      const { list } = useCrud(mockService, { onError })

      await expect(list()).rejects.toThrow()
      expect(onError).toHaveBeenCalledWith('list', mockError)
    })

    it('should apply transformList when provided', async () => {
      const users: TestUser[] = [{ id: '1', name: 'Alice', email: 'alice@test.com' }]
      const transformList = vi.fn().mockImplementation(
        (response: PaginatedResponse<TestUser>) => ({
          ...response,
          items: response.items.map(u => ({ ...u, name: u.name.toUpperCase() })),
        })
      )

      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse(users))
      )

      const { items, list } = useCrud(mockService, { transformList })

      await list()
      expect(transformList).toHaveBeenCalled()
      expect(items.value[0]!.name).toBe('ALICE')
    })
  })

  describe('getAll operation', () => {
    it('should fetch all items', async () => {
      const users: TestUser[] = [
        { id: '1', name: 'Alice', email: 'alice@test.com' },
        { id: '2', name: 'Bob', email: 'bob@test.com' },
      ]
      vi.mocked(mockService.getAll).mockResolvedValue(createMockResponse(users))

      const { items, getAll } = useCrud(mockService)

      const result = await getAll()
      expect(items.value).toEqual(users)
      expect(result).toEqual(users)
    })
  })

  describe('get operation', () => {
    it('should fetch single item and update state', async () => {
      const user: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      vi.mocked(mockService.get).mockResolvedValue(createMockResponse(user))

      const { item, itemLoading, get } = useCrud(mockService)

      const promise = get('1')
      expect(itemLoading.value).toBe(true)

      const result = await promise
      expect(itemLoading.value).toBe(false)
      expect(item.value).toEqual(user)
      expect(result).toEqual(user)
    })

    it('should apply transformItem when provided', async () => {
      const user: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      const transformItem = vi.fn().mockImplementation(
        (item: TestUser) => ({ ...item, name: item.name.toUpperCase() })
      )

      vi.mocked(mockService.get).mockResolvedValue(createMockResponse(user))

      const { item, get } = useCrud(mockService, { transformItem })

      await get('1')
      expect(transformItem).toHaveBeenCalled()
      expect(item.value?.name).toBe('ALICE')
    })
  })

  describe('create operation', () => {
    it('should create item and add to list', async () => {
      const newUser: TestUser = { id: '3', name: 'Charlie', email: 'charlie@test.com' }
      vi.mocked(mockService.create).mockResolvedValue(createMockResponse(newUser))

      const { items, creating, create } = useCrud(mockService)

      const promise = create({ name: 'Charlie', email: 'charlie@test.com' })
      expect(creating.value).toBe(true)

      const result = await promise
      expect(creating.value).toBe(false)
      expect(result).toEqual(newUser)
      expect(items.value).toContainEqual(newUser)
    })

    it('should increment total on create', async () => {
      const newUser: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      vi.mocked(mockService.create).mockResolvedValue(createMockResponse(newUser))

      // Manually set initial total
      const { pagination, create } = useCrud(mockService)

      // Mock an initial list state
      expect(pagination.value.total).toBe(0)

      await create({ name: 'Alice', email: 'alice@test.com' })
      expect(pagination.value.total).toBe(1)
    })
  })

  describe('update operation', () => {
    it('should update item in list', async () => {
      const existingUser: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      const updatedUser: TestUser = { id: '1', name: 'Alice Updated', email: 'alice@test.com' }

      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse([existingUser]))
      )
      vi.mocked(mockService.update).mockResolvedValue(createMockResponse(updatedUser))

      const { items, updating, list, update } = useCrud(mockService)

      await list()
      expect(items.value[0]!.name).toBe('Alice')

      const promise = update('1', { name: 'Alice Updated' })
      expect(updating.value).toBe(true)

      await promise
      expect(updating.value).toBe(false)
      expect(items.value[0]!.name).toBe('Alice Updated')
    })

    it('should update current item if same id', async () => {
      const existingUser: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      const updatedUser: TestUser = { id: '1', name: 'Alice Updated', email: 'alice@test.com' }

      vi.mocked(mockService.get).mockResolvedValue(createMockResponse(existingUser))
      vi.mocked(mockService.update).mockResolvedValue(createMockResponse(updatedUser))

      const { item, get, update } = useCrud(mockService)

      await get('1')
      expect(item.value?.name).toBe('Alice')

      await update('1', { name: 'Alice Updated' })
      expect(item.value?.name).toBe('Alice Updated')
    })
  })

  describe('patch operation', () => {
    it('should patch item in list', async () => {
      const existingUser: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      const patchedUser: TestUser = { id: '1', name: 'Alice', email: 'alice-new@test.com' }

      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse([existingUser]))
      )
      vi.mocked(mockService.patch).mockResolvedValue(createMockResponse(patchedUser))

      const { items, list, patch } = useCrud(mockService)

      await list()
      await patch('1', { email: 'alice-new@test.com' })
      expect(items.value[0]!.email).toBe('alice-new@test.com')
    })
  })

  describe('remove operation', () => {
    it('should remove item from list', async () => {
      const users: TestUser[] = [
        { id: '1', name: 'Alice', email: 'alice@test.com' },
        { id: '2', name: 'Bob', email: 'bob@test.com' },
      ]

      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse(users, 1, 20, 2))
      )
      vi.mocked(mockService.delete).mockResolvedValue(createMockResponse(undefined as never))

      const { items, pagination, deleting, list, remove } = useCrud(mockService)

      await list()
      expect(items.value).toHaveLength(2)
      expect(pagination.value.total).toBe(2)

      const promise = remove('1')
      expect(deleting.value).toBe(true)

      await promise
      expect(deleting.value).toBe(false)
      expect(items.value).toHaveLength(1)
      expect(items.value[0]!.id).toBe('2')
      expect(pagination.value.total).toBe(1)
    })

    it('should clear current item if same id', async () => {
      const user: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }

      vi.mocked(mockService.get).mockResolvedValue(createMockResponse(user))
      vi.mocked(mockService.delete).mockResolvedValue(createMockResponse(undefined as never))

      const { item, get, remove } = useCrud(mockService)

      await get('1')
      expect(item.value).not.toBeNull()

      await remove('1')
      expect(item.value).toBeNull()
    })
  })

  describe('pagination helpers', () => {
    beforeEach(() => {
      // Setup mock for paginated responses
      vi.mocked(mockService.list).mockImplementation(async (options?: ListOptions) => {
        const page = options?.page ?? 1
        const pageSize = options?.pageSize ?? 20
        const total = 50
        const items: TestUser[] = [
          { id: `${page}-1`, name: `User ${page}-1`, email: `user${page}-1@test.com` },
        ]
        return createMockResponse(createPaginatedResponse(items, page, pageSize, total))
      })
    })

    it('should navigate to next page', async () => {
      const { pagination, list, nextPage } = useCrud(mockService)

      await list()
      expect(pagination.value.page).toBe(1)
      expect(pagination.value.hasNext).toBe(true)

      await nextPage()
      expect(pagination.value.page).toBe(2)
    })

    it('should navigate to previous page', async () => {
      const { pagination, list, prevPage } = useCrud(mockService)

      await list({ page: 2 })
      expect(pagination.value.page).toBe(2)
      expect(pagination.value.hasPrev).toBe(true)

      await prevPage()
      expect(pagination.value.page).toBe(1)
    })

    it('should not navigate below page 1', async () => {
      const { pagination, list, prevPage } = useCrud(mockService)

      await list({ page: 1 })
      const result = await prevPage()
      expect(pagination.value.page).toBe(1)
      expect(result.page).toBe(1)
    })

    it('should go to specific page', async () => {
      const { pagination, list, goToPage } = useCrud(mockService)

      await list()
      await goToPage(3)
      expect(pagination.value.page).toBe(3)
    })

    it('should change page size and reset to page 1', async () => {
      const { pagination, list, setPageSize } = useCrud(mockService)

      await list({ page: 2 })
      expect(pagination.value.page).toBe(2)

      await setPageSize(10)
      expect(pagination.value.page).toBe(1)
      expect(pagination.value.pageSize).toBe(10)
    })

    it('should update filters and reset to page 1', async () => {
      const { pagination, list, setFilters } = useCrud(mockService)

      await list({ page: 2 })
      expect(pagination.value.page).toBe(2)

      await setFilters({ status: 'active' })
      expect(pagination.value.page).toBe(1)
      expect(mockService.list).toHaveBeenLastCalledWith(
        expect.objectContaining({ filters: { status: 'active' } })
      )
    })
  })

  describe('refresh operations', () => {
    it('should refresh list with same options', async () => {
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse([], 2, 10, 20))
      )

      const { list, refresh } = useCrud(mockService)

      await list({ page: 2, pageSize: 10 })
      vi.mocked(mockService.list).mockClear()

      await refresh()
      expect(mockService.list).toHaveBeenCalledWith(
        expect.objectContaining({ page: 2, pageSize: 10 })
      )
    })

    it('should refresh single item', async () => {
      const user: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      vi.mocked(mockService.get).mockResolvedValue(createMockResponse(user))

      const { get, refreshItem } = useCrud(mockService)

      await get('1')
      vi.mocked(mockService.get).mockClear()

      await refreshItem('1')
      expect(mockService.get).toHaveBeenCalledWith('1')
    })
  })

  describe('state management', () => {
    it('should reset all state', async () => {
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse([
          { id: '1', name: 'Alice', email: 'alice@test.com' },
        ], 2, 10, 50))
      )
      vi.mocked(mockService.get).mockResolvedValue(
        createMockResponse({ id: '1', name: 'Alice', email: 'alice@test.com' })
      )

      const { items, item, pagination, list, get, reset } = useCrud(mockService)

      await list({ page: 2, pageSize: 10 })
      await get('1')

      expect(items.value).toHaveLength(1)
      expect(item.value).not.toBeNull()
      expect(pagination.value.page).toBe(2)

      reset()

      expect(items.value).toHaveLength(0)
      expect(item.value).toBeNull()
      expect(pagination.value.page).toBe(1)
      expect(pagination.value.pageSize).toBe(20) // Default page size
    })

    it('should clear error', async () => {
      const mockError = createMockError('Failed')
      vi.mocked(mockService.list).mockRejectedValue(mockError)

      const { error, errorOperation, list, clearError } = useCrud(mockService)

      await expect(list()).rejects.toThrow()
      expect(error.value).not.toBeNull()
      expect(errorOperation.value).toBe('list')

      clearError()
      expect(error.value).toBeNull()
      expect(errorOperation.value).toBeNull()
    })

    it('should clear item', async () => {
      const user: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      vi.mocked(mockService.get).mockResolvedValue(createMockResponse(user))

      const { item, get, clearItem } = useCrud(mockService)

      await get('1')
      expect(item.value).not.toBeNull()

      clearItem()
      expect(item.value).toBeNull()
    })
  })

  describe('local state updates (optimistic)', () => {
    it('should add item locally', () => {
      const { items, pagination, addItem } = useCrud(mockService)

      const newUser: TestUser = { id: '1', name: 'Alice', email: 'alice@test.com' }
      addItem(newUser)

      expect(items.value).toContainEqual(newUser)
      expect(pagination.value.total).toBe(1)
    })

    it('should update item locally', async () => {
      const users: TestUser[] = [
        { id: '1', name: 'Alice', email: 'alice@test.com' },
      ]
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse(users))
      )

      const { items, list, updateItem } = useCrud(mockService)

      await list()
      updateItem('1', { name: 'Alice Updated' })

      expect(items.value[0]!.name).toBe('Alice Updated')
    })

    it('should remove item locally', async () => {
      const users: TestUser[] = [
        { id: '1', name: 'Alice', email: 'alice@test.com' },
        { id: '2', name: 'Bob', email: 'bob@test.com' },
      ]
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse(users, 1, 20, 2))
      )

      const { items, pagination, list, removeItem } = useCrud(mockService)

      await list()
      expect(items.value).toHaveLength(2)
      expect(pagination.value.total).toBe(2)

      removeItem('1')

      expect(items.value).toHaveLength(1)
      expect(items.value[0]!.id).toBe('2')
      expect(pagination.value.total).toBe(1)
    })

    it('should find item by id', async () => {
      const users: TestUser[] = [
        { id: '1', name: 'Alice', email: 'alice@test.com' },
        { id: '2', name: 'Bob', email: 'bob@test.com' },
      ]
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse(users))
      )

      const { list, findItem } = useCrud(mockService)

      await list()

      const found = findItem('1')
      expect(found).toEqual(users[0])

      const notFound = findItem('999')
      expect(notFound).toBeUndefined()
    })
  })

  describe('computed loading state', () => {
    it('should reflect any loading operation', async () => {
      vi.mocked(mockService.list).mockImplementation(
        () => new Promise(resolve => setTimeout(() =>
          resolve(createMockResponse(createPaginatedResponse([]))), 10
        ))
      )

      const { loading, listLoading, list } = useCrud(mockService)

      expect(loading.value).toBe(false)

      const promise = list()
      expect(loading.value).toBe(true)
      expect(listLoading.value).toBe(true)

      await promise
      expect(loading.value).toBe(false)
      expect(listLoading.value).toBe(false)
    })
  })

  describe('immediate option', () => {
    it('should fetch list immediately when immediate is true', async () => {
      vi.mocked(mockService.list).mockResolvedValue(
        createMockResponse(createPaginatedResponse([
          { id: '1', name: 'Alice', email: 'alice@test.com' },
        ]))
      )

      const { items } = useCrud(mockService, { immediate: true })

      await flushPromises()
      expect(mockService.list).toHaveBeenCalledTimes(1)
      expect(items.value).toHaveLength(1)
    })
  })
})

describe('useList', () => {
  it('should fetch and store list', async () => {
    const users: TestUser[] = [
      { id: '1', name: 'Alice', email: 'alice@test.com' },
    ]
    const mockFn = vi.fn().mockResolvedValue(createMockResponse(users))

    const { items, loading, fetch } = useList(mockFn)

    expect(items.value).toEqual([])

    const promise = fetch()
    expect(loading.value).toBe(true)

    const result = await promise
    expect(loading.value).toBe(false)
    expect(items.value).toEqual(users)
    expect(result).toEqual(users)
  })

  it('should handle errors', async () => {
    const mockError = createMockError('Failed')
    const mockFn = vi.fn().mockRejectedValue(mockError)

    const { error, fetch } = useList(mockFn)

    await expect(fetch()).rejects.toThrow('Failed')
    expect(error.value).toBe(mockError)
  })

  it('should use initialData', () => {
    const initialUsers: TestUser[] = [
      { id: '0', name: 'Initial', email: 'initial@test.com' },
    ]
    const mockFn = vi.fn().mockResolvedValue(createMockResponse([]))

    const { items } = useList(mockFn, { initialData: initialUsers })

    expect(items.value).toEqual(initialUsers)
  })

  it('should call callbacks', async () => {
    const users: TestUser[] = [{ id: '1', name: 'Alice', email: 'alice@test.com' }]
    const onSuccess = vi.fn()
    const onError = vi.fn()
    const mockFn = vi.fn().mockResolvedValue(createMockResponse(users))

    const { fetch } = useList(mockFn, { onSuccess, onError })

    await fetch()
    expect(onSuccess).toHaveBeenCalledWith(users)
    expect(onError).not.toHaveBeenCalled()
  })

  it('should fetch immediately when immediate is true', async () => {
    const users: TestUser[] = [{ id: '1', name: 'Alice', email: 'alice@test.com' }]
    const mockFn = vi.fn().mockResolvedValue(createMockResponse(users))

    const { items } = useList(mockFn, { immediate: true })

    await flushPromises()
    expect(mockFn).toHaveBeenCalledTimes(1)
    expect(items.value).toEqual(users)
  })

  it('should reset to initial data', async () => {
    const initialUsers: TestUser[] = [
      { id: '0', name: 'Initial', email: 'initial@test.com' },
    ]
    const fetchedUsers: TestUser[] = [
      { id: '1', name: 'Alice', email: 'alice@test.com' },
    ]
    const mockFn = vi.fn().mockResolvedValue(createMockResponse(fetchedUsers))

    const { items, fetch, reset } = useList(mockFn, { initialData: initialUsers })

    await fetch()
    expect(items.value).toEqual(fetchedUsers)

    reset()
    expect(items.value).toEqual(initialUsers)
  })
})
