/**
 * Response Types for Evoke API Client
 * Layer 0: Frontend API Service
 */

/**
 * Standard API response wrapper
 */
export interface ApiResponse<T = unknown> {
  /** Response data */
  data: T

  /** HTTP status code */
  status: number

  /** Response headers */
  headers: Record<string, string>

  /** Request duration in milliseconds */
  duration?: number | undefined
}

/**
 * Paginated response structure (matches Bolt Gateway format)
 */
export interface PaginatedResponse<T> {
  /** Array of items */
  items: T[]

  /** Total number of items */
  total: number

  /** Current page (1-indexed) */
  page: number

  /** Items per page */
  pageSize: number

  /** Total number of pages */
  totalPages: number

  /** Whether there are more pages */
  hasMore: boolean
}

/**
 * Standard error response from Bolt Gateway
 */
export interface ErrorResponse {
  /** Error message */
  message: string

  /** Error code for programmatic handling */
  code?: string

  /** Field-specific validation errors */
  errors?: ValidationError[]

  /** Additional error details */
  details?: Record<string, unknown>
}

/**
 * Field validation error
 */
export interface ValidationError {
  /** Field name that failed validation */
  field: string

  /** Error message for this field */
  message: string

  /** Validation rule that failed */
  rule?: string
}
