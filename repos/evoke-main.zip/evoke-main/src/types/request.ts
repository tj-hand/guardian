/**
 * Request Types for Evoke API Client
 * Layer 0: Frontend API Service
 */

import type { AxiosRequestConfig } from 'axios'
import type { ApiError } from './errors'

/**
 * HTTP methods supported by the API client
 */
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'

/**
 * Per-request retry options
 */
export interface RequestRetryOptions {
  /** Disable retry for this specific request */
  noRetry?: boolean

  /** Override max retries for this specific request */
  maxRetries?: number

  /** Custom retry condition for this specific request */
  retryCondition?: (error: ApiError, attempt: number) => boolean
}

/**
 * Extended request configuration for Evoke
 */
export interface RequestConfig extends Omit<AxiosRequestConfig, 'url' | 'method' | 'data'> {
  /** Skip authentication token injection */
  skipAuth?: boolean

  /** Per-request retry options */
  retry?: RequestRetryOptions

  /** Request metadata for logging */
  metadata?: Record<string, unknown>
}

/**
 * Query parameters type
 */
export type QueryParams = Record<string, string | number | boolean | null | undefined | Array<string | number>>

/**
 * Request options for GET requests
 */
export interface GetRequestOptions extends RequestConfig {
  params?: QueryParams
}

/**
 * Request options for POST/PUT/PATCH requests
 */
export interface MutationRequestOptions<T = unknown> extends RequestConfig {
  data?: T
  params?: QueryParams
}

/**
 * File upload request options
 */
export interface UploadRequestOptions extends RequestConfig {
  /** Progress callback (0-100) */
  onProgress?: (progress: number) => void

  /** AbortController signal for cancellation */
  signal?: AbortSignal
}

/**
 * File download request options
 */
export interface DownloadRequestOptions extends RequestConfig {
  /** Expected response type */
  responseType?: 'blob' | 'arraybuffer'

  /** Progress callback (0-100) */
  onProgress?: (progress: number) => void
}
