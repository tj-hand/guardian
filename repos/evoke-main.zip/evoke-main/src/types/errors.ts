/**
 * Error Types for Evoke API Client
 * Layer 0: Frontend API Service
 */

import type { ErrorResponse, ValidationError } from './response'

/**
 * Error codes for programmatic error handling
 */
export enum ErrorCode {
  // Network errors
  NETWORK_ERROR = 'NETWORK_ERROR',
  TIMEOUT = 'TIMEOUT',
  ABORTED = 'ABORTED',

  // HTTP errors
  BAD_REQUEST = 'BAD_REQUEST',
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  NOT_FOUND = 'NOT_FOUND',
  CONFLICT = 'CONFLICT',
  UNPROCESSABLE_ENTITY = 'UNPROCESSABLE_ENTITY',
  TOO_MANY_REQUESTS = 'TOO_MANY_REQUESTS',
  INTERNAL_SERVER_ERROR = 'INTERNAL_SERVER_ERROR',
  SERVICE_UNAVAILABLE = 'SERVICE_UNAVAILABLE',

  // Client errors
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  UNKNOWN_ERROR = 'UNKNOWN_ERROR',
}

/**
 * Base API Error class
 *
 * @category Errors
 */
export class ApiError extends Error {
  readonly code: ErrorCode
  readonly status?: number | undefined
  readonly response?: ErrorResponse | undefined
  readonly validationErrors?: ValidationError[] | undefined
  readonly originalError?: Error | undefined

  constructor(
    message: string,
    code: ErrorCode,
    options?: {
      status?: number | undefined
      response?: ErrorResponse | undefined
      validationErrors?: ValidationError[] | undefined
      originalError?: Error | undefined
    }
  ) {
    super(message)
    this.name = 'ApiError'
    this.code = code
    this.status = options?.status
    this.response = options?.response
    this.validationErrors = options?.validationErrors
    this.originalError = options?.originalError

    // Maintains proper stack trace for where error was thrown
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, ApiError)
    }
  }

  /**
   * Check if this is a network-related error
   */
  isNetworkError(): boolean {
    return this.code === ErrorCode.NETWORK_ERROR || this.code === ErrorCode.TIMEOUT
  }

  /**
   * Check if this is an authentication error
   */
  isAuthError(): boolean {
    return this.code === ErrorCode.UNAUTHORIZED || this.code === ErrorCode.FORBIDDEN
  }

  /**
   * Check if this is a validation error
   */
  isValidationError(): boolean {
    return this.code === ErrorCode.VALIDATION_ERROR || this.code === ErrorCode.UNPROCESSABLE_ENTITY
  }

  /**
   * Check if this is a server error (5xx)
   */
  isServerError(): boolean {
    return this.status !== undefined && this.status >= 500
  }

  /**
   * Get validation error for a specific field
   */
  getFieldError(field: string): string | undefined {
    return this.validationErrors?.find((e) => e.field === field)?.message
  }

  /**
   * Serialize error for logging
   */
  toJSON(): Record<string, unknown> {
    return {
      name: this.name,
      message: this.message,
      code: this.code,
      status: this.status,
      validationErrors: this.validationErrors,
      response: this.response,
    }
  }
}

/**
 * Network error (no response received)
 */
export class NetworkError extends ApiError {
  constructor(message = 'Network error occurred', originalError?: Error) {
    super(message, ErrorCode.NETWORK_ERROR, { originalError })
    this.name = 'NetworkError'
  }
}

/**
 * Request timeout error
 */
export class TimeoutError extends ApiError {
  constructor(message = 'Request timed out', originalError?: Error) {
    super(message, ErrorCode.TIMEOUT, { originalError })
    this.name = 'TimeoutError'
  }
}

/**
 * Authentication error (401)
 */
export class AuthenticationError extends ApiError {
  constructor(message = 'Authentication required', response?: ErrorResponse) {
    super(message, ErrorCode.UNAUTHORIZED, { status: 401, response })
    this.name = 'AuthenticationError'
  }
}

/**
 * Authorization error (403)
 */
export class AuthorizationError extends ApiError {
  constructor(message = 'Access denied', response?: ErrorResponse) {
    super(message, ErrorCode.FORBIDDEN, { status: 403, response })
    this.name = 'AuthorizationError'
  }
}

/**
 * Not found error (404)
 */
export class NotFoundError extends ApiError {
  constructor(message = 'Resource not found', response?: ErrorResponse) {
    super(message, ErrorCode.NOT_FOUND, { status: 404, response })
    this.name = 'NotFoundError'
  }
}

/**
 * Validation error (422)
 */
export class ValidationErrorClass extends ApiError {
  constructor(message = 'Validation failed', validationErrors?: ValidationError[], response?: ErrorResponse) {
    super(message, ErrorCode.VALIDATION_ERROR, {
      status: 422,
      response,
      validationErrors,
    })
    this.name = 'ValidationError'
  }
}
