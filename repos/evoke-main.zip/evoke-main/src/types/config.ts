/**
 * Evoke API Client Configuration Types
 * Layer 0: Frontend API Service
 */

import type { ApiError } from './errors'

/**
 * Configuration for retry behavior
 */
export interface RetryConfig {
  /** Maximum number of retry attempts (default: 3) */
  maxRetries: number

  /** Initial delay in milliseconds before first retry (default: 1000) */
  baseDelay: number

  /** Maximum delay in milliseconds between retries (default: 30000) */
  maxDelay: number

  /** Multiplier for exponential backoff (default: 2) */
  backoffMultiplier: number

  /** Whether to add random jitter to prevent thundering herd (default: true) */
  jitter: boolean

  /** Custom function to determine if an error should trigger retry */
  retryCondition?: (error: ApiError, attempt: number) => boolean

  /** Callback fired before each retry attempt */
  onRetry?: (error: ApiError, attempt: number, delay: number) => void
}

/**
 * Configuration options for the Evoke API client
 */
export interface EvokeConfig {
  /** Base URL for API requests (e.g., '/api' or 'https://api.example.com') */
  baseURL: string

  /** Request timeout in milliseconds (default: 30000) */
  timeout?: number

  /** Whether to include credentials in cross-origin requests */
  withCredentials?: boolean

  /** Custom headers to include with every request */
  headers?: Record<string, string>

  /** Token storage configuration */
  tokenStorage?: TokenStorageConfig

  /** Retry configuration (set to false to disable retries) */
  retry?: Partial<RetryConfig> | false

  /** Callback when authentication fails (401 response) */
  onAuthError?: (error: ApiError) => void

  /** Callback when a network error occurs */
  onNetworkError?: (error: ApiError) => void

  /** Enable request/response logging in development */
  debug?: boolean
}

/**
 * Token storage configuration
 */
export interface TokenStorageConfig {
  /** Storage type: 'localStorage' | 'sessionStorage' | 'memory' */
  type: 'localStorage' | 'sessionStorage' | 'memory'

  /** Key used to store the access token */
  accessTokenKey?: string

  /** Key used to store the refresh token */
  refreshTokenKey?: string
}

/**
 * Default retry configuration values
 */
export const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxRetries: 3,
  baseDelay: 1000,
  maxDelay: 30000,
  backoffMultiplier: 2,
  jitter: true,
}

/**
 * Default configuration values
 */
export const DEFAULT_CONFIG: Required<Pick<EvokeConfig, 'timeout' | 'withCredentials' | 'debug'>> & {
  tokenStorage: Required<TokenStorageConfig>
  retry: RetryConfig
} = {
  timeout: 30000,
  withCredentials: true,
  debug: false,
  tokenStorage: {
    type: 'localStorage',
    accessTokenKey: 'evoke_access_token',
    refreshTokenKey: 'evoke_refresh_token',
  },
  retry: DEFAULT_RETRY_CONFIG,
}
