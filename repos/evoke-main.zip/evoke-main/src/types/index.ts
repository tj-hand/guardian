/**
 * Type exports for Evoke API Client
 * Layer 0: Frontend API Service
 */

// Configuration types
export type { EvokeConfig, TokenStorageConfig, RetryConfig } from './config'
export { DEFAULT_CONFIG, DEFAULT_RETRY_CONFIG } from './config'

// Request types
export type {
  HttpMethod,
  RequestConfig,
  RequestRetryOptions,
  QueryParams,
  GetRequestOptions,
  MutationRequestOptions,
  UploadRequestOptions,
  DownloadRequestOptions,
} from './request'

// Response types
export type {
  ApiResponse,
  PaginatedResponse,
  ErrorResponse,
  ValidationError,
} from './response'

// Error types
export {
  ErrorCode,
  ApiError,
  NetworkError,
  TimeoutError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ValidationErrorClass,
} from './errors'
