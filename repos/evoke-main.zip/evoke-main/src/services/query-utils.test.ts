/**
 * Query Utilities Tests
 */

import { describe, it, expect } from 'vitest'
import {
  QueryBuilder,
  createQueryBuilder,
  buildQueryString,
  parseQueryString,
  mergeQueryParams,
  cleanQueryParams,
  pickQueryParams,
  omitQueryParams,
  paginationParams,
  sortParams,
  buildUrl,
} from './query-utils'

describe('QueryBuilder', () => {
  it('should build empty params by default', () => {
    const builder = new QueryBuilder()
    expect(builder.build()).toEqual({})
  })

  it('should set string parameters', () => {
    const params = createQueryBuilder()
      .set('name', 'john')
      .set('status', 'active')
      .build()

    expect(params).toEqual({ name: 'john', status: 'active' })
  })

  it('should set numeric parameters', () => {
    const params = createQueryBuilder()
      .set('page', 1)
      .set('limit', 10)
      .build()

    expect(params).toEqual({ page: 1, limit: 10 })
  })

  it('should set boolean parameters', () => {
    const params = createQueryBuilder()
      .set('active', true)
      .set('deleted', false)
      .build()

    expect(params).toEqual({ active: true, deleted: false })
  })

  it('should ignore null and undefined values', () => {
    const params = createQueryBuilder()
      .set('name', 'john')
      .set('empty', null)
      .set('missing', undefined)
      .build()

    expect(params).toEqual({ name: 'john' })
  })

  it('should set array parameters', () => {
    const params = createQueryBuilder()
      .setArray('tags', ['a', 'b', 'c'])
      .setArray('ids', [1, 2, 3])
      .build()

    expect(params).toEqual({ tags: ['a', 'b', 'c'], ids: [1, 2, 3] })
  })

  it('should ignore empty arrays', () => {
    const params = createQueryBuilder()
      .setArray('tags', [])
      .setArray('empty', null)
      .build()

    expect(params).toEqual({})
  })

  it('should add pagination parameters', () => {
    const params = createQueryBuilder()
      .paginate(2, 20)
      .build()

    expect(params).toEqual({ page: 2, pageSize: 20 })
  })

  it('should add sort parameters', () => {
    const params = createQueryBuilder()
      .sort('name', 'desc')
      .build()

    expect(params).toEqual({ sortBy: 'name', sortOrder: 'desc' })
  })

  it('should default sort order to asc', () => {
    const params = createQueryBuilder()
      .sort('createdAt')
      .build()

    expect(params).toEqual({ sortBy: 'createdAt', sortOrder: 'asc' })
  })

  it('should add search parameter', () => {
    const params = createQueryBuilder()
      .search('test query')
      .build()

    expect(params).toEqual({ q: 'test query' })
  })

  it('should support custom search key', () => {
    const params = createQueryBuilder()
      .search('test', 'search')
      .build()

    expect(params).toEqual({ search: 'test' })
  })

  it('should add date range parameters', () => {
    const params = createQueryBuilder()
      .dateRange('created', {
        from: '2024-01-01',
        to: '2024-12-31',
      })
      .build()

    expect(params).toEqual({
      createdFrom: '2024-01-01',
      createdTo: '2024-12-31',
    })
  })

  it('should handle Date objects in date range', () => {
    const from = new Date('2024-01-01T00:00:00.000Z')
    const to = new Date('2024-12-31T23:59:59.999Z')

    const params = createQueryBuilder()
      .dateRange('updated', { from, to })
      .build()

    expect(params).toEqual({
      updatedFrom: from.toISOString(),
      updatedTo: to.toISOString(),
    })
  })

  it('should add numeric range parameters', () => {
    const params = createQueryBuilder()
      .numericRange('price', { min: 10, max: 100 })
      .build()

    expect(params).toEqual({ priceMin: 10, priceMax: 100 })
  })

  it('should handle partial numeric ranges', () => {
    const minOnly = createQueryBuilder()
      .numericRange('price', { min: 10 })
      .build()

    const maxOnly = createQueryBuilder()
      .numericRange('price', { max: 100 })
      .build()

    expect(minOnly).toEqual({ priceMin: 10 })
    expect(maxOnly).toEqual({ priceMax: 100 })
  })

  it('should support conditional building with when()', () => {
    const includeStatus = true
    const includeDeleted = false

    const params = createQueryBuilder()
      .set('name', 'test')
      .when(includeStatus, (b) => b.set('status', 'active'))
      .when(includeDeleted, (b) => b.set('deleted', true))
      .build()

    expect(params).toEqual({ name: 'test', status: 'active' })
  })

  it('should merge QueryParams objects', () => {
    const params = createQueryBuilder()
      .set('existing', 'value')
      .merge({ merged: 'param', another: 123 })
      .build()

    expect(params).toEqual({
      existing: 'value',
      merged: 'param',
      another: 123,
    })
  })

  it('should remove parameters', () => {
    const params = createQueryBuilder()
      .set('keep', 'value')
      .set('remove', 'value')
      .remove('remove')
      .build()

    expect(params).toEqual({ keep: 'value' })
  })

  it('should clear all parameters', () => {
    const params = createQueryBuilder()
      .set('a', 1)
      .set('b', 2)
      .clear()
      .build()

    expect(params).toEqual({})
  })

  it('should check if parameter exists', () => {
    const builder = createQueryBuilder().set('exists', 'value')

    expect(builder.has('exists')).toBe(true)
    expect(builder.has('missing')).toBe(false)
  })

  it('should get parameter value', () => {
    const builder = createQueryBuilder().set('key', 'value')

    expect(builder.getParam('key')).toBe('value')
    expect(builder.getParam('missing')).toBeUndefined()
  })

  it('should convert to string', () => {
    const queryString = createQueryBuilder()
      .set('name', 'john')
      .set('page', 1)
      .toString()

    expect(queryString).toBe('name=john&page=1')
  })
})

describe('buildQueryString', () => {
  it('should build empty string for empty params', () => {
    expect(buildQueryString({})).toBe('')
  })

  it('should build query string from params', () => {
    const result = buildQueryString({
      name: 'john',
      age: 30,
      active: true,
    })

    expect(result).toBe('name=john&age=30&active=true')
  })

  it('should handle array values', () => {
    const result = buildQueryString({
      tags: ['a', 'b', 'c'],
    })

    expect(result).toBe('tags=a&tags=b&tags=c')
  })

  it('should skip null and undefined values', () => {
    const result = buildQueryString({
      name: 'john',
      empty: null,
      missing: undefined,
    })

    expect(result).toBe('name=john')
  })
})

describe('parseQueryString', () => {
  it('should parse empty string', () => {
    expect(parseQueryString('')).toEqual({})
  })

  it('should parse simple params', () => {
    const result = parseQueryString('name=john&age=30')

    expect(result).toEqual({ name: 'john', age: 30 })
  })

  it('should parse boolean values', () => {
    const result = parseQueryString('active=true&deleted=false')

    expect(result).toEqual({ active: true, deleted: false })
  })

  it('should parse array values', () => {
    const result = parseQueryString('tags=a&tags=b&tags=c')

    expect(result).toEqual({ tags: ['a', 'b', 'c'] })
  })

  it('should handle mixed numeric arrays', () => {
    const result = parseQueryString('ids=1&ids=2&ids=3')

    expect(result).toEqual({ ids: [1, 2, 3] })
  })
})

describe('mergeQueryParams', () => {
  it('should merge multiple param objects', () => {
    const result = mergeQueryParams(
      { a: 1 },
      { b: 2 },
      { c: 3 }
    )

    expect(result).toEqual({ a: 1, b: 2, c: 3 })
  })

  it('should override with later values', () => {
    const result = mergeQueryParams(
      { a: 1 },
      { a: 2 }
    )

    expect(result).toEqual({ a: 2 })
  })

  it('should skip null and undefined objects', () => {
    const result = mergeQueryParams(
      { a: 1 },
      null,
      undefined,
      { b: 2 }
    )

    expect(result).toEqual({ a: 1, b: 2 })
  })
})

describe('cleanQueryParams', () => {
  it('should remove null and undefined values', () => {
    const result = cleanQueryParams({
      keep: 'value',
      removeNull: null,
      removeUndefined: undefined,
      keepFalse: false,
      keepZero: 0,
    })

    expect(result).toEqual({
      keep: 'value',
      keepFalse: false,
      keepZero: 0,
    })
  })
})

describe('pickQueryParams', () => {
  it('should pick specified keys', () => {
    const result = pickQueryParams(
      { a: 1, b: 2, c: 3 },
      ['a', 'c']
    )

    expect(result).toEqual({ a: 1, c: 3 })
  })

  it('should ignore missing keys', () => {
    const result = pickQueryParams(
      { a: 1 },
      ['a', 'b', 'c']
    )

    expect(result).toEqual({ a: 1 })
  })
})

describe('omitQueryParams', () => {
  it('should omit specified keys', () => {
    const result = omitQueryParams(
      { a: 1, b: 2, c: 3 },
      ['b']
    )

    expect(result).toEqual({ a: 1, c: 3 })
  })
})

describe('paginationParams', () => {
  it('should return pagination params', () => {
    expect(paginationParams(1, 10)).toEqual({ page: 1, pageSize: 10 })
  })
})

describe('sortParams', () => {
  it('should return sort params', () => {
    expect(sortParams('name', 'desc')).toEqual({ sortBy: 'name', sortOrder: 'desc' })
  })

  it('should default to asc', () => {
    expect(sortParams('name')).toEqual({ sortBy: 'name', sortOrder: 'asc' })
  })
})

describe('buildUrl', () => {
  it('should return base path for empty params', () => {
    expect(buildUrl('/api/users')).toBe('/api/users')
    expect(buildUrl('/api/users', {})).toBe('/api/users')
  })

  it('should append query string', () => {
    expect(buildUrl('/api/users', { page: 1 })).toBe('/api/users?page=1')
  })

  it('should use & for existing query string', () => {
    expect(buildUrl('/api/users?active=true', { page: 1 })).toBe('/api/users?active=true&page=1')
  })
})
