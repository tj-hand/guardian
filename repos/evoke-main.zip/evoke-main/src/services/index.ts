/**
 * Service Layer Exports
 * Layer 0: Frontend API Service
 */

// CRUD Service
export {
  CrudService,
  ExtendedCrudService,
  createCrudService,
  createExtendedCrudService,
} from './crud-service'

export type {
  Entity,
  CrudServiceOptions,
  PaginationParams,
  FilterParams,
  ListOptions,
} from './crud-service'

// Query Utilities
export {
  QueryBuilder,
  createQueryBuilder,
  buildQueryString,
  parseQueryString,
  mergeQueryParams,
  cleanQueryParams,
  pickQueryParams,
  omitQueryParams,
  paginationParams,
  sortParams,
  buildUrl,
} from './query-utils'

export type { DateRange, NumericRange } from './query-utils'
