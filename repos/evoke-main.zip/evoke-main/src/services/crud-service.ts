/**
 * CRUD Service Factory
 * Layer 0: Frontend API Service
 *
 * Provides a type-safe, reusable service layer for CRUD operations
 * with built-in pagination and query parameter support.
 */

import type { EvokeClient } from '../client/client'
import type {
  ApiResponse,
  PaginatedResponse,
  GetRequestOptions,
  MutationRequestOptions,
  QueryParams,
} from '../types'

/**
 * Entity with an ID (base constraint for resources)
 */
export interface Entity {
  id: string | number
}

/**
 * Options for configuring a CRUD service
 */
export interface CrudServiceOptions {
  /** Base path for the resource (e.g., '/users', '/products') */
  basePath: string

  /** Custom headers for all requests to this resource */
  headers?: Record<string, string>

  /** Whether to skip auth for this service (default: false) */
  skipAuth?: boolean
}

/**
 * Pagination parameters for list requests
 */
export interface PaginationParams {
  /** Page number (1-indexed) */
  page?: number

  /** Number of items per page */
  pageSize?: number

  /** Sort field */
  sortBy?: string

  /** Sort direction */
  sortOrder?: 'asc' | 'desc'
}

/**
 * Filter parameters for list requests
 */
export type FilterParams = Record<string, string | number | boolean | null | undefined | Array<string | number>>

/**
 * Combined list options (pagination + filters + custom params)
 */
export interface ListOptions extends PaginationParams {
  /** Filter parameters */
  filters?: FilterParams

  /** Additional query parameters */
  params?: QueryParams
}

/**
 * Generic CRUD service for a resource type
 *
 * @category Services
 * @template T - The entity type
 * @template CreateDTO - Data transfer object for creating entities
 * @template UpdateDTO - Data transfer object for updating entities
 */
export class CrudService<
  T extends Entity,
  CreateDTO = Omit<T, 'id'>,
  UpdateDTO = Partial<Omit<T, 'id'>>,
> {
  protected readonly client: EvokeClient
  protected readonly basePath: string
  protected readonly serviceHeaders: Record<string, string> | undefined
  protected readonly serviceSkipAuth: boolean | undefined

  constructor(client: EvokeClient, options: CrudServiceOptions) {
    this.client = client
    this.basePath = options.basePath.replace(/\/+$/, '') // Remove trailing slashes
    this.serviceHeaders = options.headers
    this.serviceSkipAuth = options.skipAuth
  }

  /**
   * Build default request options
   */
  protected getDefaultOptions(): GetRequestOptions {
    return {
      ...(this.serviceHeaders && { headers: this.serviceHeaders }),
      ...(this.serviceSkipAuth !== undefined && { skipAuth: this.serviceSkipAuth }),
    }
  }

  /**
   * Get all entities (non-paginated)
   */
  async getAll(options?: GetRequestOptions): Promise<ApiResponse<T[]>> {
    return this.client.get<T[]>(this.basePath, {
      ...this.getDefaultOptions(),
      ...options,
    })
  }

  /**
   * Get paginated list of entities
   */
  async list(options?: ListOptions): Promise<ApiResponse<PaginatedResponse<T>>> {
    const params = this.buildListParams(options)

    return this.client.get<PaginatedResponse<T>>(this.basePath, {
      ...this.getDefaultOptions(),
      params,
    })
  }

  /**
   * Get a single entity by ID
   */
  async get(id: string | number, options?: GetRequestOptions): Promise<ApiResponse<T>> {
    return this.client.get<T>(`${this.basePath}/${id}`, {
      ...this.getDefaultOptions(),
      ...options,
    })
  }

  /**
   * Create a new entity
   */
  async create(data: CreateDTO, options?: MutationRequestOptions<CreateDTO>): Promise<ApiResponse<T>> {
    return this.client.post<T, CreateDTO>(this.basePath, data, {
      ...this.getDefaultOptions(),
      ...options,
    })
  }

  /**
   * Update an existing entity
   */
  async update(
    id: string | number,
    data: UpdateDTO,
    options?: MutationRequestOptions<UpdateDTO>
  ): Promise<ApiResponse<T>> {
    return this.client.put<T, UpdateDTO>(`${this.basePath}/${id}`, data, {
      ...this.getDefaultOptions(),
      ...options,
    })
  }

  /**
   * Partially update an existing entity
   */
  async patch(
    id: string | number,
    data: UpdateDTO,
    options?: MutationRequestOptions<UpdateDTO>
  ): Promise<ApiResponse<T>> {
    return this.client.patch<T, UpdateDTO>(`${this.basePath}/${id}`, data, {
      ...this.getDefaultOptions(),
      ...options,
    })
  }

  /**
   * Delete an entity
   */
  async delete(id: string | number, options?: GetRequestOptions): Promise<ApiResponse<void>> {
    return this.client.delete<void>(`${this.basePath}/${id}`, {
      ...this.getDefaultOptions(),
      ...options,
    })
  }

  /**
   * Check if an entity exists
   */
  async exists(id: string | number): Promise<boolean> {
    try {
      await this.get(id)
      return true
    } catch {
      return false
    }
  }

  /**
   * Build query parameters for list requests
   */
  protected buildListParams(options?: ListOptions): QueryParams {
    const params: QueryParams = {}

    if (options?.page !== undefined) {
      params.page = options.page
    }

    if (options?.pageSize !== undefined) {
      params.pageSize = options.pageSize
    }

    if (options?.sortBy) {
      params.sortBy = options.sortBy
    }

    if (options?.sortOrder) {
      params.sortOrder = options.sortOrder
    }

    // Merge filter parameters
    if (options?.filters) {
      for (const [key, value] of Object.entries(options.filters)) {
        if (value !== null && value !== undefined) {
          params[key] = value
        }
      }
    }

    // Merge additional params
    if (options?.params) {
      for (const [key, value] of Object.entries(options.params)) {
        if (value !== null && value !== undefined) {
          params[key] = value
        }
      }
    }

    return params
  }

  /**
   * Get the base path for this service
   */
  getBasePath(): string {
    return this.basePath
  }
}

/**
 * Factory function to create a CRUD service
 *
 * @category Services
 * @example
 * ```typescript
 * interface User extends Entity {
 *   id: string
 *   name: string
 *   email: string
 * }
 *
 * interface CreateUserDTO {
 *   name: string
 *   email: string
 * }
 *
 * const userService = createCrudService<User, CreateUserDTO>(client, {
 *   basePath: '/users',
 * })
 *
 * // Usage
 * const { data: users } = await userService.list({ page: 1, pageSize: 10 })
 * const { data: user } = await userService.get('123')
 * await userService.create({ name: 'John', email: 'john@example.com' })
 * ```
 */
export function createCrudService<
  T extends Entity,
  CreateDTO = Omit<T, 'id'>,
  UpdateDTO = Partial<Omit<T, 'id'>>,
>(client: EvokeClient, options: CrudServiceOptions): CrudService<T, CreateDTO, UpdateDTO> {
  return new CrudService<T, CreateDTO, UpdateDTO>(client, options)
}

/**
 * Extended CRUD service with additional common operations
 *
 * @category Services
 */
export class ExtendedCrudService<
  T extends Entity,
  CreateDTO = Omit<T, 'id'>,
  UpdateDTO = Partial<Omit<T, 'id'>>,
> extends CrudService<T, CreateDTO, UpdateDTO> {
  /**
   * Bulk create multiple entities
   */
  async bulkCreate(
    items: CreateDTO[],
    options?: MutationRequestOptions<CreateDTO[]>
  ): Promise<ApiResponse<T[]>> {
    return this.client.post<T[], CreateDTO[]>(`${this.basePath}/bulk`, items, {
      ...this.getDefaultOptions(),
      ...options,
    })
  }

  /**
   * Bulk update multiple entities
   */
  async bulkUpdate(
    items: Array<{ id: string | number } & UpdateDTO>,
    options?: MutationRequestOptions<Array<{ id: string | number } & UpdateDTO>>
  ): Promise<ApiResponse<T[]>> {
    return this.client.put<T[], Array<{ id: string | number } & UpdateDTO>>(
      `${this.basePath}/bulk`,
      items,
      {
        ...this.getDefaultOptions(),
        ...options,
      }
    )
  }

  /**
   * Bulk delete multiple entities
   */
  async bulkDelete(
    ids: Array<string | number>,
    options?: MutationRequestOptions<{ ids: Array<string | number> }>
  ): Promise<ApiResponse<void>> {
    return this.client.delete<void>(`${this.basePath}/bulk`, {
      ...this.getDefaultOptions(),
      ...options,
      params: { ids },
    })
  }

  /**
   * Search entities
   */
  async search(
    query: string,
    options?: ListOptions
  ): Promise<ApiResponse<PaginatedResponse<T>>> {
    const params = this.buildListParams(options)
    params.q = query

    return this.client.get<PaginatedResponse<T>>(`${this.basePath}/search`, {
      ...this.getDefaultOptions(),
      params,
    })
  }

  /**
   * Count entities matching filters
   */
  async count(filters?: FilterParams): Promise<ApiResponse<{ count: number }>> {
    const params: QueryParams = {}

    if (filters) {
      for (const [key, value] of Object.entries(filters)) {
        if (value !== null && value !== undefined) {
          params[key] = value
        }
      }
    }

    return this.client.get<{ count: number }>(`${this.basePath}/count`, {
      ...this.getDefaultOptions(),
      params,
    })
  }
}

/**
 * Factory function to create an extended CRUD service
 *
 * @category Services
 */
export function createExtendedCrudService<
  T extends Entity,
  CreateDTO = Omit<T, 'id'>,
  UpdateDTO = Partial<Omit<T, 'id'>>,
>(client: EvokeClient, options: CrudServiceOptions): ExtendedCrudService<T, CreateDTO, UpdateDTO> {
  return new ExtendedCrudService<T, CreateDTO, UpdateDTO>(client, options)
}
