/**
 * Query Parameter Utilities
 * Layer 0: Frontend API Service
 *
 * Provides utilities for building, parsing, and manipulating query parameters.
 */

import type { QueryParams } from '../types'

/**
 * Date range for filtering
 */
export interface DateRange {
  from?: Date | string
  to?: Date | string
}

/**
 * Numeric range for filtering
 */
export interface NumericRange {
  min?: number
  max?: number
}

/**
 * Builder class for constructing complex query parameters
 *
 * @category Utilities
 *
 * @example
 * ```typescript
 * const query = createQueryBuilder()
 *   .paginate(1, 20)
 *   .sort('name', 'asc')
 *   .set('status', 'active')
 *   .dateRange('created', { from: '2024-01-01' })
 *   .build()
 * ```
 */
export class QueryBuilder {
  private params: Map<string, string | number | boolean | Array<string | number>> = new Map()

  /**
   * Add a parameter
   */
  set(key: string, value: string | number | boolean | null | undefined): this {
    if (value !== null && value !== undefined) {
      this.params.set(key, value)
    }
    return this
  }

  /**
   * Add an array parameter
   */
  setArray(key: string, values: Array<string | number> | null | undefined): this {
    if (values && values.length > 0) {
      this.params.set(key, values)
    }
    return this
  }

  /**
   * Add pagination parameters
   */
  paginate(page: number, pageSize: number): this {
    return this.set('page', page).set('pageSize', pageSize)
  }

  /**
   * Add sorting parameters
   */
  sort(field: string, order: 'asc' | 'desc' = 'asc'): this {
    return this.set('sortBy', field).set('sortOrder', order)
  }

  /**
   * Add a search query parameter
   */
  search(query: string | null | undefined, key = 'q'): this {
    return this.set(key, query)
  }

  /**
   * Add a date range filter
   */
  dateRange(key: string, range: DateRange | null | undefined): this {
    if (!range) return this

    if (range.from) {
      const fromDate = range.from instanceof Date ? range.from.toISOString() : range.from
      this.set(`${key}From`, fromDate)
    }

    if (range.to) {
      const toDate = range.to instanceof Date ? range.to.toISOString() : range.to
      this.set(`${key}To`, toDate)
    }

    return this
  }

  /**
   * Add a numeric range filter
   */
  numericRange(key: string, range: NumericRange | null | undefined): this {
    if (!range) return this

    if (range.min !== undefined) {
      this.set(`${key}Min`, range.min)
    }

    if (range.max !== undefined) {
      this.set(`${key}Max`, range.max)
    }

    return this
  }

  /**
   * Add a boolean filter
   */
  boolean(key: string, value: boolean | null | undefined): this {
    return this.set(key, value)
  }

  /**
   * Add parameters only if a condition is true
   */
  when(condition: boolean, callback: (builder: this) => void): this {
    if (condition) {
      callback(this)
    }
    return this
  }

  /**
   * Merge another QueryParams object
   */
  merge(params: QueryParams | null | undefined): this {
    if (params) {
      for (const [key, value] of Object.entries(params)) {
        if (value !== null && value !== undefined) {
          if (Array.isArray(value)) {
            this.setArray(key, value)
          } else {
            this.set(key, value)
          }
        }
      }
    }
    return this
  }

  /**
   * Remove a parameter
   */
  remove(key: string): this {
    this.params.delete(key)
    return this
  }

  /**
   * Clear all parameters
   */
  clear(): this {
    this.params.clear()
    return this
  }

  /**
   * Check if a parameter exists
   */
  has(key: string): boolean {
    return this.params.has(key)
  }

  /**
   * Get a parameter value
   */
  getParam(key: string): string | number | boolean | Array<string | number> | undefined {
    return this.params.get(key)
  }

  /**
   * Build the final QueryParams object
   */
  build(): QueryParams {
    const result: QueryParams = {}
    this.params.forEach((value, key) => {
      result[key] = value
    })
    return result
  }

  /**
   * Build as URL search string
   */
  toString(): string {
    return buildQueryString(this.build())
  }
}

/**
 * Create a new QueryBuilder instance
 *
 * @category Utilities
 */
export function createQueryBuilder(): QueryBuilder {
  return new QueryBuilder()
}

/**
 * Build a URL query string from params object
 *
 * @category Utilities
 */
export function buildQueryString(params: QueryParams): string {
  const searchParams = new URLSearchParams()

  for (const [key, value] of Object.entries(params)) {
    if (value === null || value === undefined) continue

    if (Array.isArray(value)) {
      value.forEach((v) => searchParams.append(key, String(v)))
    } else {
      searchParams.append(key, String(value))
    }
  }

  return searchParams.toString()
}

/**
 * Parse a URL query string into a params object
 */
export function parseQueryString(queryString: string): QueryParams {
  const params: QueryParams = {}
  const searchParams = new URLSearchParams(queryString)

  // Group values by key to detect arrays
  const grouped = new Map<string, string[]>()

  searchParams.forEach((value, key) => {
    const existing = grouped.get(key)
    if (existing) {
      existing.push(value)
    } else {
      grouped.set(key, [value])
    }
  })

  // Convert to QueryParams
  grouped.forEach((values, key) => {
    if (values.length === 1 && values[0] !== undefined) {
      params[key] = parseValue(values[0])
    } else if (values.length > 1) {
      params[key] = values.map(parseValue) as Array<string | number>
    }
  })

  return params
}

/**
 * Parse a string value to its appropriate type
 */
function parseValue(value: string): string | number | boolean {
  // Boolean
  if (value === 'true') return true
  if (value === 'false') return false

  // Number
  const num = Number(value)
  if (!isNaN(num) && value.trim() !== '') {
    return num
  }

  // String
  return value
}

/**
 * Merge multiple QueryParams objects
 */
export function mergeQueryParams(...paramsList: Array<QueryParams | null | undefined>): QueryParams {
  const result: QueryParams = {}

  for (const params of paramsList) {
    if (!params) continue

    for (const [key, value] of Object.entries(params)) {
      if (value !== null && value !== undefined) {
        result[key] = value
      }
    }
  }

  return result
}

/**
 * Remove null/undefined values from QueryParams
 */
export function cleanQueryParams(params: QueryParams): QueryParams {
  const result: QueryParams = {}

  for (const [key, value] of Object.entries(params)) {
    if (value !== null && value !== undefined) {
      result[key] = value
    }
  }

  return result
}

/**
 * Pick specific keys from QueryParams
 */
export function pickQueryParams(params: QueryParams, keys: string[]): QueryParams {
  const result: QueryParams = {}

  for (const key of keys) {
    if (key in params && params[key] !== null && params[key] !== undefined) {
      result[key] = params[key]
    }
  }

  return result
}

/**
 * Omit specific keys from QueryParams
 */
export function omitQueryParams(params: QueryParams, keys: string[]): QueryParams {
  const result: QueryParams = {}
  const omitSet = new Set(keys)

  for (const [key, value] of Object.entries(params)) {
    if (!omitSet.has(key) && value !== null && value !== undefined) {
      result[key] = value
    }
  }

  return result
}

/**
 * Build pagination params from common patterns
 */
export function paginationParams(page: number, pageSize: number): QueryParams {
  return { page, pageSize }
}

/**
 * Build sort params from common patterns
 */
export function sortParams(sortBy: string, sortOrder: 'asc' | 'desc' = 'asc'): QueryParams {
  return { sortBy, sortOrder }
}

/**
 * Combine URL path with query parameters
 */
export function buildUrl(basePath: string, params?: QueryParams): string {
  if (!params || Object.keys(params).length === 0) {
    return basePath
  }

  const queryString = buildQueryString(params)
  if (!queryString) {
    return basePath
  }

  const separator = basePath.includes('?') ? '&' : '?'
  return `${basePath}${separator}${queryString}`
}
