/**
 * CRUD Service Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest'
import { CrudService, ExtendedCrudService, createCrudService, createExtendedCrudService } from './crud-service'
import type { EvokeClient } from '../client/client'
import type { ApiResponse, PaginatedResponse } from '../types'

// Mock client type
type MockClient = {
  get: ReturnType<typeof vi.fn>
  post: ReturnType<typeof vi.fn>
  put: ReturnType<typeof vi.fn>
  patch: ReturnType<typeof vi.fn>
  delete: ReturnType<typeof vi.fn>
}

// Test entity type
interface TestEntity {
  id: string
  name: string
  email: string
}

interface CreateTestDTO {
  name: string
  email: string
}

interface UpdateTestDTO {
  name?: string
  email?: string
}

// Helper to create mock response
function mockResponse<T>(data: T): ApiResponse<T> {
  return {
    data,
    status: 200,
    headers: {},
    duration: 100,
  }
}

// Helper to create paginated response
function mockPaginatedResponse<T>(items: T[], total: number): ApiResponse<PaginatedResponse<T>> {
  return mockResponse({
    items,
    total,
    page: 1,
    pageSize: 10,
    totalPages: Math.ceil(total / 10),
    hasMore: total > 10,
  })
}

describe('CrudService', () => {
  let mockClient: MockClient
  let service: CrudService<TestEntity, CreateTestDTO, UpdateTestDTO>

  beforeEach(() => {
    mockClient = {
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
      patch: vi.fn(),
      delete: vi.fn(),
    }

    service = new CrudService<TestEntity, CreateTestDTO, UpdateTestDTO>(
      mockClient as unknown as EvokeClient,
      { basePath: '/users' }
    )
  })

  describe('constructor', () => {
    it('should strip trailing slashes from basePath', () => {
      const svc = new CrudService(mockClient as unknown as EvokeClient, {
        basePath: '/users///',
      })
      expect(svc.getBasePath()).toBe('/users')
    })
  })

  describe('getAll()', () => {
    it('should fetch all entities', async () => {
      const users: TestEntity[] = [
        { id: '1', name: 'John', email: 'john@test.com' },
        { id: '2', name: 'Jane', email: 'jane@test.com' },
      ]
      mockClient.get.mockResolvedValue(mockResponse(users))

      const result = await service.getAll()

      expect(mockClient.get).toHaveBeenCalledWith('/users', expect.any(Object))
      expect(result.data).toEqual(users)
    })

    it('should pass request options', async () => {
      mockClient.get.mockResolvedValue(mockResponse([]))

      await service.getAll({ headers: { 'X-Custom': 'value' } })

      expect(mockClient.get).toHaveBeenCalledWith('/users', expect.objectContaining({
        headers: { 'X-Custom': 'value' },
      }))
    })
  })

  describe('list()', () => {
    it('should fetch paginated list', async () => {
      const response = mockPaginatedResponse<TestEntity>(
        [{ id: '1', name: 'John', email: 'john@test.com' }],
        50
      )
      mockClient.get.mockResolvedValue(response)

      const result = await service.list({ page: 1, pageSize: 10 })

      expect(mockClient.get).toHaveBeenCalledWith('/users', expect.objectContaining({
        params: { page: 1, pageSize: 10 },
      }))
      expect(result.data.items).toHaveLength(1)
      expect(result.data.total).toBe(50)
    })

    it('should include sort parameters', async () => {
      mockClient.get.mockResolvedValue(mockPaginatedResponse([], 0))

      await service.list({ sortBy: 'name', sortOrder: 'desc' })

      expect(mockClient.get).toHaveBeenCalledWith('/users', expect.objectContaining({
        params: { sortBy: 'name', sortOrder: 'desc' },
      }))
    })

    it('should merge filter parameters', async () => {
      mockClient.get.mockResolvedValue(mockPaginatedResponse([], 0))

      await service.list({
        page: 1,
        filters: { status: 'active', role: 'admin' },
      })

      expect(mockClient.get).toHaveBeenCalledWith('/users', expect.objectContaining({
        params: { page: 1, status: 'active', role: 'admin' },
      }))
    })

    it('should skip null/undefined filter values', async () => {
      mockClient.get.mockResolvedValue(mockPaginatedResponse([], 0))

      await service.list({
        filters: { status: 'active', empty: null, missing: undefined },
      })

      expect(mockClient.get).toHaveBeenCalledWith('/users', expect.objectContaining({
        params: { status: 'active' },
      }))
    })
  })

  describe('get()', () => {
    it('should fetch a single entity by ID', async () => {
      const user: TestEntity = { id: '123', name: 'John', email: 'john@test.com' }
      mockClient.get.mockResolvedValue(mockResponse(user))

      const result = await service.get('123')

      expect(mockClient.get).toHaveBeenCalledWith('/users/123', expect.any(Object))
      expect(result.data).toEqual(user)
    })

    it('should handle numeric IDs', async () => {
      mockClient.get.mockResolvedValue(mockResponse({ id: 456, name: 'Test', email: 'test@test.com' }))

      await service.get(456)

      expect(mockClient.get).toHaveBeenCalledWith('/users/456', expect.any(Object))
    })
  })

  describe('create()', () => {
    it('should create a new entity', async () => {
      const newUser: CreateTestDTO = { name: 'John', email: 'john@test.com' }
      const createdUser: TestEntity = { id: '123', ...newUser }
      mockClient.post.mockResolvedValue(mockResponse(createdUser))

      const result = await service.create(newUser)

      expect(mockClient.post).toHaveBeenCalledWith('/users', newUser, expect.any(Object))
      expect(result.data).toEqual(createdUser)
    })
  })

  describe('update()', () => {
    it('should update an existing entity with PUT', async () => {
      const updateData: UpdateTestDTO = { name: 'Updated' }
      const updatedUser: TestEntity = { id: '123', name: 'Updated', email: 'john@test.com' }
      mockClient.put.mockResolvedValue(mockResponse(updatedUser))

      const result = await service.update('123', updateData)

      expect(mockClient.put).toHaveBeenCalledWith('/users/123', updateData, expect.any(Object))
      expect(result.data).toEqual(updatedUser)
    })
  })

  describe('patch()', () => {
    it('should partially update an entity with PATCH', async () => {
      const patchData: UpdateTestDTO = { email: 'new@test.com' }
      const patchedUser: TestEntity = { id: '123', name: 'John', email: 'new@test.com' }
      mockClient.patch.mockResolvedValue(mockResponse(patchedUser))

      const result = await service.patch('123', patchData)

      expect(mockClient.patch).toHaveBeenCalledWith('/users/123', patchData, expect.any(Object))
      expect(result.data).toEqual(patchedUser)
    })
  })

  describe('delete()', () => {
    it('should delete an entity', async () => {
      mockClient.delete.mockResolvedValue(mockResponse(undefined))

      await service.delete('123')

      expect(mockClient.delete).toHaveBeenCalledWith('/users/123', expect.any(Object))
    })
  })

  describe('exists()', () => {
    it('should return true if entity exists', async () => {
      mockClient.get.mockResolvedValue(mockResponse({ id: '123', name: 'Test', email: 'test@test.com' }))

      const result = await service.exists('123')

      expect(result).toBe(true)
    })

    it('should return false if entity does not exist', async () => {
      mockClient.get.mockRejectedValue(new Error('Not found'))

      const result = await service.exists('123')

      expect(result).toBe(false)
    })
  })

  describe('service options', () => {
    it('should apply skipAuth option', async () => {
      const publicService = new CrudService(mockClient as unknown as EvokeClient, {
        basePath: '/public',
        skipAuth: true,
      })
      mockClient.get.mockResolvedValue(mockResponse([]))

      await publicService.getAll()

      expect(mockClient.get).toHaveBeenCalledWith('/public', expect.objectContaining({
        skipAuth: true,
      }))
    })

    it('should apply custom headers', async () => {
      const customService = new CrudService(mockClient as unknown as EvokeClient, {
        basePath: '/custom',
        headers: { 'X-Api-Version': '2' },
      })
      mockClient.get.mockResolvedValue(mockResponse([]))

      await customService.getAll()

      expect(mockClient.get).toHaveBeenCalledWith('/custom', expect.objectContaining({
        headers: { 'X-Api-Version': '2' },
      }))
    })
  })
})

describe('ExtendedCrudService', () => {
  let mockClient: MockClient
  let service: ExtendedCrudService<TestEntity, CreateTestDTO, UpdateTestDTO>

  beforeEach(() => {
    mockClient = {
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
      patch: vi.fn(),
      delete: vi.fn(),
    }

    service = new ExtendedCrudService<TestEntity, CreateTestDTO, UpdateTestDTO>(
      mockClient as unknown as EvokeClient,
      { basePath: '/users' }
    )
  })

  describe('bulkCreate()', () => {
    it('should create multiple entities', async () => {
      const items: CreateTestDTO[] = [
        { name: 'John', email: 'john@test.com' },
        { name: 'Jane', email: 'jane@test.com' },
      ]
      mockClient.post.mockResolvedValue(mockResponse([
        { id: '1', ...items[0] },
        { id: '2', ...items[1] },
      ]))

      const result = await service.bulkCreate(items)

      expect(mockClient.post).toHaveBeenCalledWith('/users/bulk', items, expect.any(Object))
      expect(result.data).toHaveLength(2)
    })
  })

  describe('bulkUpdate()', () => {
    it('should update multiple entities', async () => {
      const items = [
        { id: '1', name: 'Updated 1' },
        { id: '2', name: 'Updated 2' },
      ]
      mockClient.put.mockResolvedValue(mockResponse([
        { id: '1', name: 'Updated 1', email: 'john@test.com' },
        { id: '2', name: 'Updated 2', email: 'jane@test.com' },
      ]))

      const result = await service.bulkUpdate(items)

      expect(mockClient.put).toHaveBeenCalledWith('/users/bulk', items, expect.any(Object))
      expect(result.data).toHaveLength(2)
    })
  })

  describe('bulkDelete()', () => {
    it('should delete multiple entities', async () => {
      const ids = ['1', '2', '3']
      mockClient.delete.mockResolvedValue(mockResponse(undefined))

      await service.bulkDelete(ids)

      expect(mockClient.delete).toHaveBeenCalledWith('/users/bulk', expect.objectContaining({
        params: { ids },
      }))
    })
  })

  describe('search()', () => {
    it('should search entities', async () => {
      mockClient.get.mockResolvedValue(mockPaginatedResponse([], 0))

      await service.search('john')

      expect(mockClient.get).toHaveBeenCalledWith('/users/search', expect.objectContaining({
        params: expect.objectContaining({ q: 'john' }),
      }))
    })

    it('should include pagination in search', async () => {
      mockClient.get.mockResolvedValue(mockPaginatedResponse([], 0))

      await service.search('john', { page: 2, pageSize: 20 })

      expect(mockClient.get).toHaveBeenCalledWith('/users/search', expect.objectContaining({
        params: expect.objectContaining({ q: 'john', page: 2, pageSize: 20 }),
      }))
    })
  })

  describe('count()', () => {
    it('should count entities', async () => {
      mockClient.get.mockResolvedValue(mockResponse({ count: 42 }))

      const result = await service.count()

      expect(mockClient.get).toHaveBeenCalledWith('/users/count', expect.any(Object))
      expect(result.data.count).toBe(42)
    })

    it('should count with filters', async () => {
      mockClient.get.mockResolvedValue(mockResponse({ count: 10 }))

      await service.count({ status: 'active' })

      expect(mockClient.get).toHaveBeenCalledWith('/users/count', expect.objectContaining({
        params: { status: 'active' },
      }))
    })
  })
})

describe('createCrudService factory', () => {
  it('should create a CrudService instance', () => {
    const mockClient = {} as EvokeClient
    const service = createCrudService<TestEntity>(mockClient, { basePath: '/test' })

    expect(service).toBeInstanceOf(CrudService)
    expect(service.getBasePath()).toBe('/test')
  })
})

describe('createExtendedCrudService factory', () => {
  it('should create an ExtendedCrudService instance', () => {
    const mockClient = {} as EvokeClient
    const service = createExtendedCrudService<TestEntity>(mockClient, { basePath: '/test' })

    expect(service).toBeInstanceOf(ExtendedCrudService)
    expect(service.getBasePath()).toBe('/test')
  })
})
