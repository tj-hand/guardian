/**
 * Evoke API Client
 * Layer 0: Frontend API Service
 *
 * Vue3/TypeScript API client library for communicating with
 * backend services through the Bolt API Gateway.
 *
 * @example
 * ```typescript
 * import { createClient } from '@evoke/client'
 *
 * const api = createClient({
 *   baseURL: import.meta.env.VITE_API_URL,
 *   onAuthError: () => router.push('/login'),
 * })
 *
 * // Authenticated request
 * const { data } = await api.get<User[]>('/users')
 *
 * // Public request (no auth token)
 * const { data: config } = await api.publicGet<AppConfig>('/config')
 * ```
 *
 * @packageDocumentation
 */

// Client
export { createClient, EvokeClient } from './client'

// Retry utilities
export {
  withRetry,
  isRetryableError,
  calculateBackoff,
  parseRetryAfter,
  delay,
  shouldRetry,
  getRetryDelay,
  mergeRetryConfig,
  createRetryWrapper,
  DEFAULT_RETRY_CONFIG,
} from './client'

// Types - Configuration
export type { EvokeConfig, TokenStorageConfig, RetryConfig } from './types'
export { DEFAULT_CONFIG } from './types'

// Types - Request
export type {
  HttpMethod,
  RequestConfig,
  RequestRetryOptions,
  QueryParams,
  GetRequestOptions,
  MutationRequestOptions,
  UploadRequestOptions,
  DownloadRequestOptions,
} from './types'

// Types - Response
export type {
  ApiResponse,
  PaginatedResponse,
  ErrorResponse,
  ValidationError,
} from './types'

// Errors
export {
  ErrorCode,
  ApiError,
  NetworkError,
  TimeoutError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ValidationErrorClass,
} from './types'

// Services
export {
  CrudService,
  ExtendedCrudService,
  createCrudService,
  createExtendedCrudService,
  QueryBuilder,
  createQueryBuilder,
  buildQueryString,
  parseQueryString,
  mergeQueryParams,
  cleanQueryParams,
  pickQueryParams,
  omitQueryParams,
  paginationParams,
  sortParams,
  buildUrl,
} from './services'

export type {
  Entity,
  CrudServiceOptions,
  PaginationParams,
  FilterParams,
  ListOptions,
  DateRange,
  NumericRange,
} from './services'

// Vue Composables
export {
  useApi,
  useLazyApi,
  useApiStates,
  useCrud,
  useList,
} from './composables'

export type {
  UseApiOptions,
  UseApiReturn,
  UseLazyApiOptions,
  UseApiStatesOptions,
  UseApiStatesReturn,
  UseCrudOptions,
  UseCrudReturn,
  CrudOperation,
  PaginationState,
  UseListOptions,
  UseListReturn,
} from './composables'
