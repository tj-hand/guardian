# Evoke API Client - Product Backlog

## Initial Requirements (Captured: 2025-11-25)

### Product Vision
Evoke is a Vue3/TypeScript API Client library serving as **Layer 0 of the Frontend Container**. It provides a centralized, type-safe interface for communicating with backend services through the Bolt API Gateway.

### Source
Initial prompt from Product Owner (first development session).

---

## Epic: EVOKE-EPIC-001 - Core API Client

### User Story
As a frontend developer, I need a robust API client library that handles all HTTP communication with the Bolt Gateway, so I can focus on building features instead of managing HTTP requests.

### Acceptance Criteria
- [ ] Centralized axios instance with proper configuration
- [ ] Request interceptors for JWT token injection
- [ ] Response interceptors for error handling (401 redirect, etc.)
- [ ] Type-safe request/response handling
- [ ] Support for requests without authentication (public endpoints)
- [ ] Support for authenticated requests
- [ ] File upload functionality (up to 100MB)
- [ ] File download functionality
- [ ] Configurable base URL and timeouts
- [ ] Comprehensive error handling with custom error types

### Technical Requirements
- Vue 3 + TypeScript
- Axios as HTTP client
- Full TypeScript type coverage
- Integration with Bolt API Gateway
- Environment-based configuration

---

## Epic: EVOKE-EPIC-002 - Authentication Module

### User Story
As a frontend developer, I need the API client to automatically handle authentication tokens, so I don't need to manually add authorization headers to each request.

### Acceptance Criteria
- [ ] Token storage abstraction (localStorage/sessionStorage)
- [ ] Automatic token injection via request interceptor
- [ ] Token refresh handling
- [ ] Logout and token cleanup
- [ ] 401 response handling with redirect

---

## Epic: EVOKE-EPIC-003 - File Operations Module

### User Story
As a frontend developer, I need to upload and download files through the API client, so I can handle media and documents in the application.

### Acceptance Criteria
- [ ] File upload with progress tracking
- [ ] Multi-file upload support
- [ ] File download with proper content-type handling
- [ ] Blob and base64 support
- [ ] Upload cancellation support
- [ ] Size validation (max 100MB per Bolt Gateway)

---

## Epic: EVOKE-EPIC-004 - Error Handling Module

### User Story
As a frontend developer, I need comprehensive error handling, so I can provide meaningful feedback to users and debug issues effectively.

### Acceptance Criteria
- [ ] Custom error classes for different error types
- [ ] Network error detection
- [ ] HTTP status code handling (4xx, 5xx)
- [ ] Request timeout handling
- [ ] Error serialization for logging
- [ ] Retry logic for transient failures

---

## Epic: EVOKE-EPIC-005 - Service Layer Templates

### User Story
As a frontend developer, I need pre-built service templates, so I can quickly create type-safe API services for different resources.

### Acceptance Criteria
- [ ] CRUD service factory
- [ ] Paginated list support
- [ ] Query parameter handling
- [ ] Service composition patterns
- [ ] Documentation and examples

---

## Technology Decisions

### HTTP Client: Axios
**Decision Date:** 2025-11-25
**Rationale:**
- Robust interceptor support for auth token injection
- Strong TypeScript support
- Mature ecosystem with extensive documentation
- Automatic JSON handling and error management
- Well-suited for complex applications
- Previously used in the organization (team familiarity)

**Alternatives Considered:**
- Native Fetch: Requires manual error handling and interceptor implementation
- Ky: Smaller bundle but limited ecosystem and community

---

## References

- [Bolt API Gateway](https://github.com/tj-hand/bolt) - Backend gateway
- [Spark Board Control](https://github.com/tj-hand/spark) - Project management
- [Modular Layered Architecture](../MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md)
- [Vue Agent Guidelines](./agents/vue-agent.md)

---

## Sprint Planning

See `project.yml` for current sprint configuration and feature tracking.
