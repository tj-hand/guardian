# Evoke

[![npm version](https://img.shields.io/npm/v/@evoke/client.svg)](https://www.npmjs.com/package/@evoke/client)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3+-blue.svg)](https://www.typescriptlang.org/)
[![Vue 3](https://img.shields.io/badge/Vue-3.4+-green.svg)](https://vuejs.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Vue3/TypeScript API client library providing pre-configured endpoints for communicating with backend services through Bolt Gateway. Framework-agnostic core with Vue 3 composables for reactive state management.

## Features

- **Type-safe HTTP client** built on Axios with full TypeScript support
- **Vue 3 Composables** for reactive API state management
- **Automatic authentication** with token storage and management
- **CRUD service layer** for common data operations
- **File operations** with upload/download progress tracking
- **Retry logic** with exponential backoff and jitter
- **Query builder** for complex query parameter construction
- **Comprehensive error handling** with typed error classes

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Core API](#core-api)
  - [GET Requests](#get-requests)
  - [Mutation Requests](#mutation-requests-post-put-patch-delete)
  - [Public Requests](#public-requests-no-auth)
- [Authentication](#authentication)
- [File Operations](#file-operations)
- [CRUD Service](#crud-service)
- [Vue Composables](#vue-composables)
  - [useApi](#useapi)
  - [useCrud](#usecrud)
  - [useList](#uselist)
- [Query Builder](#query-builder)
- [Error Handling](#error-handling)
- [Retry Configuration](#retry-configuration)
- [TypeScript Types](#typescript-types)
- [Examples](#examples)
- [Architecture](#architecture)
- [Docker Deployment](#docker-deployment)
  - [Static Server](#static-server)
  - [Health Endpoint](#health-endpoint)
  - [CORS Support](#cors-support)
  - [Environment Configuration](#environment-configuration)
  - [Custom Routes](#custom-routes)
  - [API Proxy](#api-proxy)

## Installation

```bash
# npm
npm install @evoke/client

# yarn
yarn add @evoke/client

# pnpm
pnpm add @evoke/client
```

### Peer Dependencies

```bash
npm install vue@^3.4.0 axios@^1.6.0
```

## Quick Start

```typescript
import { createClient } from '@evoke/client'

// Create the API client
const api = createClient({
  baseURL: 'https://api.example.com',
  onAuthError: () => {
    // Redirect to login on 401
    window.location.href = '/login'
  },
})

// Set authentication token (after login)
api.setToken('your-access-token')

// Make authenticated requests
const { data: users } = await api.get<User[]>('/users')
const { data: user } = await api.post<User>('/users', { name: 'John Doe' })

// Make public requests (no auth token)
const { data: config } = await api.publicGet<AppConfig>('/config')
```

## Configuration

### Full Configuration Options

```typescript
import { createClient, EvokeConfig } from '@evoke/client'

const config: EvokeConfig = {
  // Required: Base URL for all requests
  baseURL: 'https://api.example.com',

  // Optional: Request timeout in milliseconds (default: 30000)
  timeout: 30000,

  // Optional: Include credentials in CORS requests (default: false)
  withCredentials: false,

  // Optional: Custom headers for all requests
  headers: {
    'X-Custom-Header': 'value',
  },

  // Optional: Token storage configuration
  tokenStorage: {
    type: 'localStorage', // 'localStorage' | 'sessionStorage' | 'memory'
    accessTokenKey: 'evoke_access_token',
    refreshTokenKey: 'evoke_refresh_token',
  },

  // Optional: Retry configuration (false to disable)
  retry: {
    maxRetries: 3,
    baseDelay: 1000,
    maxDelay: 30000,
    backoffMultiplier: 2,
    jitter: true,
  },

  // Optional: Callback on authentication errors (401)
  onAuthError: (error) => {
    console.error('Auth error:', error)
    // Handle logout, redirect, etc.
  },

  // Optional: Callback on network errors
  onNetworkError: (error) => {
    console.error('Network error:', error)
    // Show offline notification, etc.
  },

  // Optional: Enable debug logging (default: false)
  debug: false,
}

const api = createClient(config)
```

### Environment-Based Configuration

```typescript
// Using Vite environment variables
const api = createClient({
  baseURL: import.meta.env.VITE_API_URL,
  debug: import.meta.env.DEV,
  onAuthError: () => router.push('/login'),
})
```

## Core API

### GET Requests

```typescript
// Basic GET request
const { data } = await api.get<User[]>('/users')

// GET with query parameters
const { data } = await api.get<User[]>('/users', {
  params: {
    page: 1,
    limit: 20,
    status: 'active',
  },
})

// GET with custom headers
const { data } = await api.get<User>('/users/123', {
  headers: {
    'Accept-Language': 'en-US',
  },
})

// GET with abort signal
const controller = api.createAbortController()
const { data } = await api.get<User[]>('/users', {
  signal: controller.signal,
})
// Later: controller.abort()
```

### Mutation Requests (POST, PUT, PATCH, DELETE)

```typescript
// POST - Create resource
const { data: newUser } = await api.post<User>('/users', {
  name: 'John Doe',
  email: 'john@example.com',
})

// PUT - Full update
const { data: updated } = await api.put<User>('/users/123', {
  name: 'John Smith',
  email: 'john.smith@example.com',
})

// PATCH - Partial update
const { data: patched } = await api.patch<User>('/users/123', {
  name: 'John Smith',
})

// DELETE - Remove resource
await api.delete('/users/123')
```

### Public Requests (No Auth)

For endpoints that don't require authentication:

```typescript
// Public GET
const { data: config } = await api.publicGet<AppConfig>('/config')

// Public POST (e.g., login)
const { data: auth } = await api.publicPost<AuthResponse>('/auth/login', {
  email: 'user@example.com',
  password: 'password123',
})
```

## Authentication

### Token Management

```typescript
// Set access token after login
api.setToken('your-access-token')

// Set both access and refresh tokens
api.setToken('access-token', 'refresh-token')

// Check if token exists
if (api.hasToken()) {
  console.log('User is authenticated')
}

// Get current token
const token = api.getToken()

// Clear tokens (logout)
api.clearToken()
```

### Token Storage Options

```typescript
// LocalStorage (persists across browser sessions)
const api = createClient({
  baseURL: 'https://api.example.com',
  tokenStorage: {
    type: 'localStorage',
    accessTokenKey: 'my_app_token', // custom key
  },
})

// SessionStorage (cleared when tab closes)
const api = createClient({
  baseURL: 'https://api.example.com',
  tokenStorage: {
    type: 'sessionStorage',
  },
})

// Memory only (cleared on page refresh)
const api = createClient({
  baseURL: 'https://api.example.com',
  tokenStorage: {
    type: 'memory',
  },
})
```

## File Operations

### Upload Files

```typescript
// Single file upload
const file = document.querySelector('input[type="file"]').files[0]
const { data } = await api.upload<UploadResponse>('/upload', file, {
  onProgress: (progress) => {
    console.log(`Upload progress: ${progress}%`)
  },
})

// Multiple files upload
const files = document.querySelector('input[type="file"]').files
const { data } = await api.uploadMultiple<UploadResponse>('/upload/batch', files, {
  onProgress: (progress) => {
    console.log(`Upload progress: ${progress}%`)
  },
})

// Upload with additional form fields
const { data } = await api.uploadWithFields<UploadResponse>(
  '/upload',
  { avatar: file },
  { userId: '123', description: 'Profile picture' },
  {
    onProgress: (progress) => console.log(`${progress}%`),
  }
)
```

### Download Files

```typescript
// Download as Blob
const blob = await api.download('/files/document.pdf', {
  onProgress: (progress) => {
    console.log(`Download progress: ${progress}%`)
  },
})

// Download and trigger browser save dialog
await api.downloadAndSave('/files/document.pdf', 'my-document.pdf', {
  onProgress: (progress) => console.log(`${progress}%`),
})
```

## CRUD Service

Create reusable service layers for entity management:

```typescript
import { createCrudService, createExtendedCrudService } from '@evoke/client'

// Define your entity type
interface User {
  id: string
  name: string
  email: string
  createdAt: string
}

// Basic CRUD service
const userService = createCrudService<User>(api, {
  basePath: '/users',
})

// List with pagination, sorting, and filters
const { data: response } = await userService.list({
  page: 1,
  pageSize: 20,
  sortBy: 'createdAt',
  sortOrder: 'desc',
  filters: {
    status: 'active',
    role: ['admin', 'user'],
  },
})
// response: { items: User[], total: number, page: number, pageSize: number, totalPages: number, hasMore: boolean }

// Get single entity
const { data: user } = await userService.get('user-123')

// Create entity
const { data: newUser } = await userService.create({
  name: 'John Doe',
  email: 'john@example.com',
})

// Update entity (full)
const { data: updated } = await userService.update('user-123', {
  name: 'John Smith',
  email: 'john.smith@example.com',
})

// Patch entity (partial)
const { data: patched } = await userService.patch('user-123', {
  name: 'John Smith',
})

// Delete entity
await userService.delete('user-123')
```

### Extended CRUD Service with Custom DTOs

```typescript
interface CreateUserDTO {
  name: string
  email: string
  password: string
}

interface UpdateUserDTO {
  name?: string
  email?: string
}

const userService = createExtendedCrudService<User, CreateUserDTO, UpdateUserDTO>(
  api,
  { basePath: '/users' }
)

// Now create/update use the specific DTO types
await userService.create({ name: 'John', email: 'john@example.com', password: 'secret' })
await userService.update('123', { name: 'John Smith' })
```

## Vue Composables

### useApi

Reactive wrapper for any API call:

```typescript
import { useApi } from '@evoke/client'

// In your component setup
const { data, loading, error, execute, refresh, abort, reset } = useApi(
  (userId: string) => api.get<User>(`/users/${userId}`),
  {
    immediate: false, // Don't execute immediately
    initialData: null,
    onSuccess: (user) => console.log('Loaded user:', user),
    onError: (err) => console.error('Failed to load:', err),
  }
)

// Execute the request
await execute('user-123')

// Refresh (re-execute with same params)
await refresh()

// Abort ongoing request
abort()

// Reset state
reset()
```

### useLazyApi

Same as useApi but always lazy (never executes immediately):

```typescript
import { useLazyApi } from '@evoke/client'

const { data, loading, execute } = useLazyApi(
  (id: string) => api.get<User>(`/users/${id}`)
)

// Must call execute manually
await execute('user-123')
```

### useCrud

Full CRUD operations with reactive state:

```typescript
import { useCrud, createCrudService } from '@evoke/client'

// Create the service
const userService = createCrudService<User>(api, { basePath: '/users' })

// Use in component
const {
  items,        // Ref<User[]>
  item,         // Ref<User | null>
  pagination,   // Ref<PaginationState>
  loading,      // Computed<boolean>
  error,        // Ref<ApiError | null>
  list,         // (options?) => Promise<void>
  read,         // (id) => Promise<void>
  create,       // (data) => Promise<User>
  update,       // (id, data) => Promise<User>
  patch,        // (id, data) => Promise<User>
  remove,       // (id) => Promise<void>
  refresh,      // () => Promise<void>
  reset,        // () => void
} = useCrud(userService, {
  immediate: true,       // Load list immediately
  defaultPageSize: 20,
  onSuccess: (op, data) => console.log(`${op} succeeded`, data),
  onError: (op, error) => console.error(`${op} failed`, error),
})

// In your template
// <div v-if="loading">Loading...</div>
// <div v-for="user in items" :key="user.id">{{ user.name }}</div>
// <button @click="list({ page: pagination.page + 1 })">Next Page</button>
```

### useList

Simplified list fetching:

```typescript
import { useList } from '@evoke/client'

const { items, loading, error, execute, refresh } = useList(
  () => api.get<User[]>('/users'),
  {
    immediate: true,
    onSuccess: (users) => console.log('Loaded', users.length, 'users'),
  }
)
```

## Query Builder

Build complex query strings with a chainable API:

```typescript
import { QueryBuilder, createQueryBuilder, buildQueryString } from '@evoke/client'

// Using QueryBuilder class
const query = new QueryBuilder()
  .paginate(1, 20)
  .sort('createdAt', 'desc')
  .search('john')
  .set('status', 'active')
  .setArray('roles', ['admin', 'user'])
  .dateRange('createdAt', { from: '2024-01-01', to: '2024-12-31' })
  .numericRange('age', { min: 18, max: 65 })
  .build()

// Result: { page: 1, pageSize: 20, sortBy: 'createdAt', sortOrder: 'desc', q: 'john', status: 'active', roles: ['admin', 'user'], createdAt_from: '2024-01-01', createdAt_to: '2024-12-31', age_min: 18, age_max: 65 }

// Factory function
const query = createQueryBuilder()
  .paginate(2, 10)
  .sort('name')
  .build()

// Build URL with query string
import { buildUrl } from '@evoke/client'
const url = buildUrl('/users', { page: 1, status: 'active' })
// Result: '/users?page=1&status=active'

// Parse existing query string
import { parseQueryString } from '@evoke/client'
const params = parseQueryString('?page=1&status=active')
// Result: { page: '1', status: 'active' }

// Merge query params
import { mergeQueryParams } from '@evoke/client'
const merged = mergeQueryParams(
  { page: 1, status: 'active' },
  { page: 2, role: 'admin' }
)
// Result: { page: 2, status: 'active', role: 'admin' }
```

## Error Handling

### Error Types

```typescript
import {
  ApiError,
  NetworkError,
  TimeoutError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ValidationErrorClass,
  ErrorCode,
} from '@evoke/client'

try {
  await api.get('/users')
} catch (error) {
  if (error instanceof AuthenticationError) {
    // 401 - User not authenticated
    router.push('/login')
  } else if (error instanceof AuthorizationError) {
    // 403 - User not authorized
    showNotification('You do not have permission')
  } else if (error instanceof NotFoundError) {
    // 404 - Resource not found
    router.push('/404')
  } else if (error instanceof ValidationErrorClass) {
    // 422 - Validation errors
    console.log(error.validationErrors)
    // [{ field: 'email', message: 'Invalid email format' }]
  } else if (error instanceof NetworkError) {
    // Network connection failed
    showNotification('Please check your internet connection')
  } else if (error instanceof TimeoutError) {
    // Request timed out
    showNotification('Request timed out, please try again')
  } else if (error instanceof ApiError) {
    // Other API errors
    console.log(error.code)    // ErrorCode enum
    console.log(error.status)  // HTTP status code
    console.log(error.message) // Error message
  }
}
```

### Error Codes

```typescript
import { ErrorCode } from '@evoke/client'

// Available error codes
ErrorCode.NETWORK_ERROR
ErrorCode.TIMEOUT
ErrorCode.ABORTED
ErrorCode.BAD_REQUEST          // 400
ErrorCode.UNAUTHORIZED         // 401
ErrorCode.FORBIDDEN            // 403
ErrorCode.NOT_FOUND            // 404
ErrorCode.CONFLICT             // 409
ErrorCode.UNPROCESSABLE_ENTITY // 422
ErrorCode.TOO_MANY_REQUESTS    // 429
ErrorCode.INTERNAL_SERVER_ERROR // 500
ErrorCode.SERVICE_UNAVAILABLE  // 503
ErrorCode.VALIDATION_ERROR
ErrorCode.UNKNOWN_ERROR
```

## Retry Configuration

### Default Retry Behavior

By default, Evoke retries failed requests with exponential backoff:

- Max 3 retries
- Starting delay: 1000ms
- Max delay: 30000ms
- Backoff multiplier: 2x
- Jitter enabled (randomization to prevent thundering herd)

### Custom Retry Configuration

```typescript
import { createClient, DEFAULT_RETRY_CONFIG } from '@evoke/client'

const api = createClient({
  baseURL: 'https://api.example.com',
  retry: {
    maxRetries: 5,
    baseDelay: 500,
    maxDelay: 60000,
    backoffMultiplier: 1.5,
    jitter: true,
    // Custom retry condition
    retryCondition: (error, attempt) => {
      // Only retry network errors and 5xx errors
      return error.code === 'NETWORK_ERROR' || (error.status && error.status >= 500)
    },
    // Callback on each retry
    onRetry: (error, attempt, delay) => {
      console.log(`Retry attempt ${attempt} in ${delay}ms`)
    },
  },
})

// Disable retry globally
const api = createClient({
  baseURL: 'https://api.example.com',
  retry: false,
})

// Disable retry for specific request
await api.get('/users', { retry: false })

// Custom retry for specific request
await api.get('/users', {
  retry: { maxRetries: 5 },
})
```

### Standalone Retry Utility

```typescript
import { withRetry, isRetryableError } from '@evoke/client'

// Wrap any async function with retry logic
const result = await withRetry(
  () => someAsyncOperation(),
  {
    maxRetries: 3,
    baseDelay: 1000,
  }
)

// Check if error is retryable
if (isRetryableError(error)) {
  // Retry the operation
}
```

## TypeScript Types

### Importing Types

```typescript
import type {
  // Configuration
  EvokeConfig,
  TokenStorageConfig,
  RetryConfig,

  // Request types
  HttpMethod,
  RequestConfig,
  QueryParams,
  GetRequestOptions,
  MutationRequestOptions,
  UploadRequestOptions,
  DownloadRequestOptions,

  // Response types
  ApiResponse,
  PaginatedResponse,
  ErrorResponse,
  ValidationError,

  // Service types
  Entity,
  CrudServiceOptions,
  ListOptions,
  PaginationParams,
  FilterParams,

  // Composable types
  UseApiOptions,
  UseApiReturn,
  UseCrudOptions,
  UseCrudReturn,
  UseListOptions,
  UseListReturn,
} from '@evoke/client'
```

### Response Type

All API methods return `ApiResponse<T>`:

```typescript
interface ApiResponse<T> {
  data: T                          // Response data
  status: number                   // HTTP status code
  headers: Record<string, string>  // Response headers
  duration?: number                // Request duration in ms
}
```

### Paginated Response

List endpoints should return `PaginatedResponse<T>`:

```typescript
interface PaginatedResponse<T> {
  items: T[]          // Array of items
  total: number       // Total count
  page: number        // Current page (1-indexed)
  pageSize: number    // Items per page
  totalPages: number  // Total pages
  hasMore: boolean    // More pages available
}
```

## Examples

### Complete Vue 3 Component Example

```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
import { createClient, useCrud, createCrudService } from '@evoke/client'

interface User {
  id: string
  name: string
  email: string
}

// Create API client
const api = createClient({
  baseURL: import.meta.env.VITE_API_URL,
  onAuthError: () => {
    // Handle unauthorized
  },
})

// Create CRUD service
const userService = createCrudService<User>(api, { basePath: '/users' })

// Use CRUD composable
const {
  items: users,
  loading,
  error,
  pagination,
  list,
  create,
  remove,
} = useCrud(userService, { immediate: true })

// Form state
const newUserName = ref('')
const newUserEmail = ref('')

// Actions
const handleCreate = async () => {
  await create({ name: newUserName.value, email: newUserEmail.value })
  newUserName.value = ''
  newUserEmail.value = ''
}

const handleDelete = async (id: string) => {
  if (confirm('Delete this user?')) {
    await remove(id)
  }
}

const nextPage = () => {
  if (pagination.value.hasMore) {
    list({ page: pagination.value.page + 1 })
  }
}
</script>

<template>
  <div>
    <!-- Create Form -->
    <form @submit.prevent="handleCreate">
      <input v-model="newUserName" placeholder="Name" required />
      <input v-model="newUserEmail" type="email" placeholder="Email" required />
      <button type="submit" :disabled="loading">Add User</button>
    </form>

    <!-- Loading State -->
    <div v-if="loading">Loading...</div>

    <!-- Error State -->
    <div v-if="error" class="error">{{ error.message }}</div>

    <!-- User List -->
    <ul>
      <li v-for="user in users" :key="user.id">
        {{ user.name }} ({{ user.email }})
        <button @click="handleDelete(user.id)">Delete</button>
      </li>
    </ul>

    <!-- Pagination -->
    <div>
      Page {{ pagination.page }} of {{ pagination.totalPages }}
      <button @click="nextPage" :disabled="!pagination.hasMore">
        Next Page
      </button>
    </div>
  </div>
</template>
```

### API Service Module Pattern

```typescript
// services/api.ts
import { createClient } from '@evoke/client'

export const api = createClient({
  baseURL: import.meta.env.VITE_API_URL,
  onAuthError: () => {
    localStorage.removeItem('token')
    window.location.href = '/login'
  },
})

// services/userService.ts
import { createCrudService } from '@evoke/client'
import { api } from './api'

export interface User {
  id: string
  name: string
  email: string
}

export const userService = createCrudService<User>(api, {
  basePath: '/users',
})

// Additional custom methods
export const userApi = {
  ...userService,

  async getCurrentUser() {
    return api.get<User>('/users/me')
  },

  async updatePassword(currentPassword: string, newPassword: string) {
    return api.post('/users/me/password', { currentPassword, newPassword })
  },

  async uploadAvatar(file: File) {
    return api.upload<{ url: string }>('/users/me/avatar', file)
  },
}
```

### Authentication Flow

```typescript
// composables/useAuth.ts
import { ref, computed } from 'vue'
import { api } from '@/services/api'

interface LoginCredentials {
  email: string
  password: string
}

interface AuthResponse {
  accessToken: string
  refreshToken: string
  user: User
}

export function useAuth() {
  const user = ref<User | null>(null)
  const loading = ref(false)

  const isAuthenticated = computed(() => api.hasToken())

  async function login(credentials: LoginCredentials) {
    loading.value = true
    try {
      const { data } = await api.publicPost<AuthResponse>('/auth/login', credentials)
      api.setToken(data.accessToken, data.refreshToken)
      user.value = data.user
      return data
    } finally {
      loading.value = false
    }
  }

  async function logout() {
    try {
      await api.post('/auth/logout', {})
    } finally {
      api.clearToken()
      user.value = null
    }
  }

  async function fetchCurrentUser() {
    if (!api.hasToken()) return null
    const { data } = await api.get<User>('/auth/me')
    user.value = data
    return data
  }

  return {
    user,
    loading,
    isAuthenticated,
    login,
    logout,
    fetchCurrentUser,
  }
}
```

## Architecture

This repository represents **Layer 0: Frontend API Service** within the Modular Layered Architecture.

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend Application                      │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                Vue Components                        │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │    │
│  │  │  useApi()   │  │  useCrud()  │  │  useList()  │  │    │
│  │  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  │    │
│  └─────────┼────────────────┼────────────────┼─────────┘    │
│            │                │                │               │
│  ┌─────────▼────────────────▼────────────────▼─────────┐    │
│  │               CRUD Service Layer                     │    │
│  │         createCrudService() / QueryBuilder           │    │
│  └─────────────────────────┬───────────────────────────┘    │
│                            │                                 │
│  ┌─────────────────────────▼───────────────────────────┐    │
│  │                   EvokeClient                        │    │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌────────┐  │    │
│  │  │  Auth   │  │  Retry  │  │ Upload  │  │ Errors │  │    │
│  │  └─────────┘  └─────────┘  └─────────┘  └────────┘  │    │
│  └─────────────────────────┬───────────────────────────┘    │
│                            │                                 │
│  ┌─────────────────────────▼───────────────────────────┐    │
│  │                      Axios                           │    │
│  └─────────────────────────┬───────────────────────────┘    │
└────────────────────────────┼────────────────────────────────┘
                             │ HTTPS
                             ▼
                    ┌─────────────────┐
                    │  Bolt Gateway   │
                    │   (Backend)     │
                    └─────────────────┘
```

For the complete architectural reference, see [MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md](./MODULAR_LAYERED_ARCHITECTURE_CONCEPTUAL.md).

## Docker Deployment

Evoke provides a Docker static server for serving the JavaScript client library and proxying API requests to Bolt Gateway.

### Static Server

Run the static server using Docker Compose:

```bash
# Start the static server (nginx)
docker compose --profile static up -d

# The server is available at http://localhost:8080
```

Or use the pre-built image:

```bash
docker run -p 8080:80 ghcr.io/tj-hand/evoke:static
```

**Available endpoints:**

| Endpoint | Description |
|----------|-------------|
| `/` | Redirects to `/docs/` |
| `/docs/` | API documentation (TypeDoc generated) |
| `/dist/evoke.js` | ES module JavaScript client |
| `/dist/evoke.umd.cjs` | UMD format for Node/CommonJS |
| `/health` | Health check endpoint |
| `/api/*` | Proxy to Bolt Gateway |

### Health Endpoint

The `/health` endpoint returns service status for container orchestration:

```bash
curl http://localhost:8080/health
```

Response:
```json
{
  "status": "healthy",
  "service": "evoke",
  "version": "1.0.0"
}
```

This endpoint is used by Docker's HEALTHCHECK and can be used for:
- Kubernetes liveness/readiness probes
- Load balancer health checks
- Service discovery

### CORS Support

The static server includes full CORS support for browser-based clients:

```bash
# Verify CORS headers
curl -I http://localhost:8080/dist/evoke.js
```

Headers included on all responses:
- `Access-Control-Allow-Origin: *`
- `Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS`
- `Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept, Origin`
- `Access-Control-Expose-Headers: Content-Length, Content-Range`

**Note:** In production, consider replacing `*` with specific allowed origins for security.

### Environment Configuration

The static server supports runtime configuration via environment variables, allowing you to customize the Bolt Gateway connection without rebuilding the image:

| Variable | Default | Description |
|----------|---------|-------------|
| `BOLT_GATEWAY_HOST` | `bolt-gateway` | Hostname of the Bolt Gateway service |
| `BOLT_GATEWAY_PORT` | `80` | Port of the Bolt Gateway service |
| `API_PATH_PREFIX` | `/api` | Path prefix for API proxy routing |

**Example with Docker run:**

```bash
docker run -p 8080:80 \
  -e BOLT_GATEWAY_HOST=my-gateway \
  -e BOLT_GATEWAY_PORT=8088 \
  -e API_PATH_PREFIX=/v1/api \
  ghcr.io/tj-hand/evoke:static
```

**Example with Docker Compose:**

```yaml
services:
  evoke-static:
    image: ghcr.io/tj-hand/evoke:static
    ports:
      - "8080:80"
    environment:
      BOLT_GATEWAY_HOST: bolt-gateway
      BOLT_GATEWAY_PORT: 80
      API_PATH_PREFIX: /api
```

### Custom Routes

You can extend the nginx configuration by mounting additional route files:

```bash
docker run -p 8080:80 \
  -v ./my-routes.conf:/etc/nginx/conf.d/custom-routes/my-routes.conf:ro \
  ghcr.io/tj-hand/evoke:static
```

Custom routes are included automatically and can define additional proxy locations, redirects, or static file serving rules.

### API Proxy

The `/api/` path (configurable via `API_PATH_PREFIX`) proxies requests to Bolt Gateway with client identification:

```bash
# Requests to /api/* are proxied to bolt-gateway:80/
curl http://localhost:8080/api/users
# → Proxied to http://bolt-gateway:80/users
```

The proxy adds these headers to identify the source:
- `X-Client-ID: evoke` - Identifies requests as coming from Evoke
- `X-Real-IP` - Original client IP
- `X-Forwarded-For` - Proxy chain
- `X-Forwarded-Proto` - Original protocol (http/https)

This allows Bolt Gateway to:
- Apply per-client rate limiting
- Log request sources for auditing
- Enforce access control policies

**Docker Compose networking:** When running with Docker Compose, ensure Evoke and Bolt Gateway are on the same network:

```yaml
services:
  evoke-static:
    image: ghcr.io/tj-hand/evoke:static
    ports:
      - "8080:80"
    networks:
      - app-network

  bolt-gateway:
    image: ghcr.io/tj-hand/bolt:latest
    ports:
      - "8088:80"  # Host port 8088 maps to container's internal port 80
    networks:
      - app-network

networks:
  app-network:
    driver: bridge
```

## API Reference

Generate the full API documentation:

```bash
# Generate HTML docs
npm run docs

# Generate JSON API reference
npm run docs:json

# Watch mode for development
npm run docs:watch
```

Documentation will be generated in the `docs/` directory.

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

MIT License - see [LICENSE](LICENSE) for details.
